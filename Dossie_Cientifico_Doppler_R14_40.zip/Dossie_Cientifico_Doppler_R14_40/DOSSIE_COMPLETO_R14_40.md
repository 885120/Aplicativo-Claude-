# Dossiê científico — Calculadora Doppler Obstétrico (R14.40)

Material de 06/10/2026, atualizado em 10/10/2026, para revisão, auditoria ou estudo por outro assistente de IA (ChatGPT, Codex) ou por pessoas. Responsável clínico: Dr. Diogo S. Ribeiro (CRM 5789-AL).

Funde e substitui o dossiê de Claude R14.28 (03/10/2026) e o dossiê consolidado do ChatGPT (06/10/2026), já com a revisão Q1–Q8, a investigação científica, a recuperação documental e o adendo de busca seletiva, todos conferidos no código, e registra as mudanças da R14.33 à R14.40 e os pentes finos de 06/10 e 10/10/2026.

**Versão descrita: R14.40.** `index.html` SHA-256 `d5a9931092acab63cb59f95418f8992d7e9ca0d5591cdd10fb0863d926cfd0f5` (542.589 B), SCHEMA_VERSION 14. Worker `sw.js` R14.23-SW2, SHA-256 `868972f473094deafe00372b44de52f1e35b2ff15a576d6222d5b39f70fcc840`. Última publicação confirmada: R14.35 (07/10/2026). Em 10/10/2026 os arquivos foram excluídos do GitHub e o site ficou em 404; a R14.40 ainda não foi publicada. Se você recebeu outro HTML, confira o hash antes de usar este material. O HTML não está neste pacote.

## Arquivos e ordem de leitura

| Arquivo | Conteúdo |
|---|---|
| `01_ESTADO_CIENTIFICO_R14_40.md` | **Comece aqui.** Correções desta fusão, estado de cada módulo com fonte, DOI, tipo de acesso e conferência no código, mudanças da R14.33, o que ainda falta definir e documentos que faltam. |
| `02_TEORIA_DO_APP_R14_40.md` | Toda a teoria que o app exibe, extraída literalmente do HTML da R14.35, com adendo do que mudou até a R14.40, e os avisos clínicos condicionais do motor que estão em discussão. |
| `03_DECISOES_E_CONTEXTO_R14_40.md` | Decisões fechadas, armadilhas, bugs que não podem voltar e histórico até a R14.40 (é o `CONTEXTO.md` do repositório). |
| `04_REFERENCIAS_BASE_R14_28.md` | Cadeia de proveniência de cada tabela e regra até a R14.28, com adjudicações. Para o que mudou depois, vale o `01`. |
| `05_AUDITORIA_FILA_HERDADA_R14_35.md` | Auditoria de todos os itens herdados do CONTEXTO de 17/09: dois erros demonstrados (corrigidos na R14.34), um suspeito descartado, ajustes de documentação e o que já estava resolvido. |
| `06_PENTE_FINO_R14_35.md` | Pente fino geral da R14.34 (integridade, regressão, exames simulados, textos, fontes, documentação) e o que entrou na R14.35. |
| `07_MUDANCAS_E_PENTE_FINO_10_10_2026.md` | Mudanças de 10/10/2026 (R14.36 a R14.40): uterinas, interface, tamanho do bebê, com hashes, fontes e testes; pente fino da R14.39. |
| `MATRIZ_PENDENCIAS.csv` | Pendências por prioridade, já reconciliadas. |
| `DOSSIE_COMPLETO_R14_40.md` | Os arquivos acima num só, para anexar de uma vez. |
| `anexos/revisoes_chatgpt/` | Revisão Q1–Q8 e adendo de busca seletiva (PDFs originais). |
| `anexos/investigacao/` | Investigação original e recuperação documental: tabelas das fontes em CSV, scripts de cálculo, registro de acesso, PDFs FEBRASGO e SMFM, Table S1 de Ciobanu. |
| `anexos/regras_e_modelos/` | Manual Mestre v2.0, Modelos Aprovados de laudo, contratos do laudo e decisões históricas. |

Precedência em caso de conflito: código da R14.40 > `07` > `01` > `03` > `04` > anexos. Os anexos são registros históricos de cada rodada; onde contradizem o `01`, a correção está na seção 1 do `01`.

## Regras para quem usar este material

1. **Hierarquia de fontes: FEBRASGO → CBR → ISUOG**, confirmada pelo médico em 06/10/2026. SMFM, RCOG, FMF, INTERGROWTH e artigos originais complementam lacunas, com atribuição explícita. Documentos antigos com outra ordem estão superados.
2. **Não reabrir decisões fechadas** sem evidência primária nova: equação de Hadlock 1991 (C0-A); equações de Ciobanu 2019; queda > 50 percentis com intervalo ≥ 21 dias; tamanho fetal por PFE + CA; discordância gemelar com valor bruto e decisão por categoria; cortes de líquido; regra UTD pré-natal.
3. **Separar fato de inferência.** Marcar se a afirmação vem do texto integral, do resumo, de reprodução secundária, de cálculo ou de dedução. Dizer "não acessei" quando for o caso. Relato de outra IA não é fonte científica nem substitui execução.
4. **Proponha, não aplique.** Nenhuma alteração no app sem liberação explícita do médico.
5. **Confirme cada achado no código presente** antes de tratá-lo como defeito. Auditorias anteriores já descreveram bugs inexistentes, e esta fusão corrigiu três afirmações que o código desmentia (`01`, seção 1).
6. **Não há validação clínica formal.** Quantidade de testes ou de artigos não prova ausência de defeitos.
7. **Não alterar sem decisão fundamentada:** `valmm()`, `cmpMedida()`, curvas, operadores clínicos, valores brutos, estados incompletos, schema, worker e interface.

## O que pede atenção primeiro

- **Publicar a R14.40** (site em 404 desde 10/10/2026, 13:56) e testar em iPhone físico.
- D3 (zoom bloqueado): só com teste no aparelho.
- Documentos ainda não obtidos (`01`, seção 4); nenhum muda o app hoje.


---

<!-- ARQUIVO: 07_MUDANCAS_E_PENTE_FINO_10_10_2026.md -->

# Mudanças de 10/10/2026 (R14.36 → R14.40) e pente fino da R14.39

Data: 10/10/2026. Autor: Claude. Responsável clínico: Dr. Diogo S. Ribeiro (CRM 5789-AL).
Cada versão foi liberada pelo médico antes de ser aplicada. Patches `patch_r14_36.py` a `patch_r14_40.py` reconstroem cada versão byte a byte a partir da anterior.

| Versão | SHA-256 do `index.html` | O que entrou |
|---|---|---|
| R14.36 | `ab7a5936b26b3bdd9d4c08fd5c0032b896b42d32b766b0f6ad47737014a18dc1` | Via das uterinas, barrinha por lado, incisura por quadradinho |
| R14.37 | `55e4f80e0d137553aa0ea0e9a7e9504ab4a67263c95313102cf5c34db0816215` | Ergonomia, simetria, campo parado |
| R14.38 | `de9cafcd01f00ffcf2633ffb8d30fb33fd51d474ec0b6f476c588a2cfd0929c2` | Correções da bateria de testes |
| R14.39 | `1a92da24c4dd139df0f3a0ffb1c0f6caf462de557999b7fcae3b1c172b8c1373` | Tamanho do bebê para a paciente; "Próximo pendente" em todas as abas |
| R14.40 | `d5a9931092acab63cb59f95418f8992d7e9ca0d5591cdd10fb0863d926cfd0f5` | Limpeza do pente fino, sem efeito clínico |

SCHEMA_VERSION 14 e `sw.js` R14.23-SW2 (`868972f4…`) inalterados em todas.

## 1. Artérias uterinas (R14.36)

- **Via:** cada exame novo começa com **transabdominal** pré-selecionada (`VIA_UT='ta'`, `VIA_UT_PADRAO=true`), por decisão do médico: é a via de quase todos os exames do serviço. No 1º trimestre (IG < 14 semanas; sem IG, contexto de 1º trimestre), enquanto a via não for tocada, um aviso pede para confirmá-la. As duas vias são usadas nessa fase. Com a curva de Gómez, o aviso acrescenta que ela é transvaginal no 1º trimestre e que, para medida transabdominal, a curva compatível é Cavoretto. A compatibilidade curva × via × IG (`utRefCompativel`) continua decidindo se o app classifica: Gómez <15 sem só TV, 15–41 TA; Cavoretto TA 10–39 (CÓDIGO; fontes no `01`, seção 2.6).
- **Barrinha por lado:** sob cada artéria, uma barrinha de percentil **só de consulta**, colorida e ao vivo, pela mesma curva, via e IG do IP médio. O rótulo nunca contradiz o p95; quem classifica continua sendo o **IP médio** (decisão C0-B2). Sem via, ou com curva/via/IG incompatível, a barrinha não aparece.
- **Incisura:** um quadradinho por lado, marcado só quando presente. Estado por lado (`incSt`): marcado = presente; desmarcado com o IP daquele lado medido = ausente; sem IP = não avaliada. O laudo cita só a presença (uni/bilateral; "à direita; esquerda não avaliada" quando só um lado foi medido). Exame salvo no schema antigo é recuperado com aviso.
- **Efeito no laudo (diferencial R14.35 × R14.39, 300 exames aleatórios):** todas as diferenças vêm da incisura (95 laudos; 48 contadores de aba), como decidido. Nenhuma outra linha mudou.

## 2. Interface (R14.37–R14.38)

Aprovada sobre prints de antes/depois; **botões e fontes mantidos** (o médico recusou essa parte).

- Medidas começa pela biometria (síntese, sequência e guia foram para o fim da aba, onde não empurram os campos).
- Abas fixas no rodapé; somem enquanto se digita.
- "Confira antes de laudar": cada aviso mostra a 1ª frase e o restante abre em "por quê" (`chkParte`). O texto é o mesmo de antes, só dobrado: nunca corta dentro de negrito/itálico nem em abreviação, e aviso com resto curto fica inteiro. O aviso de Hadlock tem resumo próprio. Diferencial R14.36 × R14.37: 2.176 avisos, nenhum perdeu texto.
- Barra fixa **Copiar laudo · Copiar conclusão** na aba Laudo. A conclusão copiada é o trecho do laudo a partir de "CONCLUSÃO".
- Simetria: etiqueta à direita no cabeçalho dos cards; "· opcional" junto do título; unidade centrada no campo; Fíbula na grade; diástole umbilical em linha própria (barras alinhadas); pares de campos nivelados quando um rótulo quebra em 2 linhas (telas < 360 px).
- **Campo parado:** se algo acima do campo em edição cresce ou some, a página rola a mesma diferença (`ancFixa`). Antes, digitar na biometria podia deslocar o campo 140 px. Limite: no fim da página, se o conteúdo abaixo encolher, o navegador recorta a rolagem (até ~13 px).

## 3. Tamanho do bebê (R14.39)

- **Pedido do médico:** informar à paciente o tamanho do bebê, sem entrar no laudo.
- **Fórmula:** comprimento (cm) = 6,18 + 0,59 × fêmur (mm). Vintzileos AM, Campbell WA, Neckles S, Pike CL, Nochimson DJ. *The ultrasound femur length as a predictor of fetal length.* Obstet Gynecol 1984;64(6):779-82, PMID 6390277 (RESUMO: a fórmula está no próprio resumo).
- **Erro:** Milner LL et al., J Clin Ultrasound 1994;22:253-6, DOI 10.1002/jcu.1870220407 (RESUMO): entre seis funções publicadas, a de Vintzileos foi a melhor para gestação única, sem erro sistemático e com erro aleatório de ±6%. Hadlock FP et al., J Ultrasound Med 1984;3:1-3, DOI 10.7863/jum.1984.3.1.1 (RESUMO): relação linear, r² 0,66, desvio-padrão de 2,4 cm.
- **Faixa do fêmur 30–90 mm:** vem da calculadora de perinatology.com (SECUNDÁRIA), não do artigo. Os termos MeSH do artigo indicam 3º trimestre. O app aplica a faixa como limite de exibição e, além dela, respeita a plausibilidade do fêmur.
- **Limitação:** Lim JM et al., UOG 2000;15:131-7, DOI 10.1046/j.1469-0705.2000.00053.x (RESUMO): a relação fêmur × comprimento difere entre populações (até 1,1 cm). A fórmula não foi validada na população brasileira.
- **Hierarquia:** FEBRASGO, ISUOG, Rumack e CBR não trazem fórmula de comprimento fetal. A fonte está **fora da hierarquia** e foi autorizada explicitamente pelo médico em 10/10/2026.
- **Implementação (CÓDIGO):** linha "Para a paciente" sob o peso na aba Medidas, com número redondo e faixa ±6%; só no modo "pela biometria" e com fêmur 3,0–9,0 cm. Nunca no laudo, na conclusão ou na cópia (regra R14.8: o que vai ao laudo tem de estar na interface clínica, e este dado é só informativo). O Modo Paciente já mostrava "Comprimento" pela mesma fórmula desde a R14.5, sem limite de fêmur; passou a seguir a mesma faixa. Teste: 1.001 valores de fêmur (1,00–11,00 cm), nos dois navegadores.

## 4. Correções de interface (R14.38–R14.40)

- "Próximo pendente" ficava dentro da aba Laudo (`#p3`) e, na R14.37, atrás das barras do rodapé. Agora fica no `body`, aparece em todas as abas, acima das barras, e leva ao campo que falta.
- O aviso rápido ("Copiado") ficava sobre as abas; agora fica acima delas.
- "por quê" abre e fecha com Enter ou espaço.
- Em 320 px: nada vaza da tela; as etiquetas do cabeçalho do card descem para a 2ª linha.
- Lição registrada: regras novas com a mesma especificidade das antigas, declaradas antes delas no CSS, **perdem**. Isso aconteceu com `.prox`, `.toast` e `.qr .v`, todas corrigidas com `body` na frente.

## 5. Pente fino da R14.39 → R14.40

| Verificação | Resultado |
|---|---|
| Suíte de regressão (18 grupos), Chromium e WebKit | 63.832 checagens, 0 falhas (R14.39 e R14.40) |
| Diferencial R14.39 × R14.40 (200 exames) | laudo, conclusão, avisos, estado e contadores idênticos |
| Diferencial R14.35 × R14.39 (300 exames) | só a incisura difere, como decidido |
| Bateria de interface A–I (sobreposição, 320–430 px, campo parado, clique em tudo nos contextos A/B/gemelar, 1º tri, recuperação, cópia real, teclado, tema escuro) | sem falhas nos dois navegadores |
| Offline (service worker) e atualização online | abre a versão nova; sem rede, a última válida |
| Exame salvo na R14.36 recuperado na versão nova | laudo idêntico, com aviso de versão |
| Sintaxe (node) e ESLint (erros: no-undef, no-redeclare, no-dupe-keys etc.) | sem erro real; restam `z!==z` (teste de NaN, proposital) e `var` redeclarado em ramos diferentes |
| Cascata de CSS | duas regras novas sem efeito → corrigidas na R14.40 |
| IDs | nenhuma referência a ID inexistente |
| Textos da tela | sem espaço duplo, pontuação solta ou palavra repetida |

**Achado operacional, não do código:** em 10/10/2026, às 13:55, `index.html`, `CONTEXTO.md`, `README.md` e a suíte foram excluídos do GitHub sem reenvio. O site ficou em 404 (o service worker não mascara 404 com a internet ligada). O README passou a orientar: envie primeiro, apague depois.

## 6. Pendências

- Publicar a R14.40 (`index.html`, `CONTEXTO.md`, `README.md`, `suite_regressao_doppler.py`) e conferir o site.
- Testar em iPhone físico: teclado sobre as barras do rodapé, área segura (home indicator), campo parado com teclado aberto, datas, offline e atualização.
- D3 (zoom bloqueado): só com teste no aparelho.
- Tamanho do bebê: sem validação na população brasileira (seção 3).


---

<!-- ARQUIVO: 01_ESTADO_CIENTIFICO_R14_40.md -->

# Estado científico consolidado — Calculadora Doppler Obstétrico R14.40

Data: 06/10/2026, atualizado em 10/10/2026. Responsável clínico: Dr. Diogo S. Ribeiro (CRM 5789-AL).
Baseline atual: `index.html` **R14.40**, SHA-256 `d5a9931092acab63cb59f95418f8992d7e9ca0d5591cdd10fb0863d926cfd0f5` (542.589 B). De R14.36 a R14.40 (10/10/2026): via das uterinas, barrinha por lado, incisura por quadradinho, interface, tamanho do bebê para a paciente e limpeza; detalhes, hashes e testes no `07`. Baseline anterior: `index.html` R14.35, SHA-256 `47b3d14c74c611dd1fc44ee7b2e6a58700d856f6bc13cdb96edcd8d43879dbc4` (528.726 B). A R14.35 corrigiu a exibição de valores perto dos cortes e a citação do colo como achado materno (`06`). Antes dela, R14.34, SHA-256 `4152a23438e546b7588abc760324e8b5733c80399e4fd635ab9fe58c6e26cb74`: a R14.34 corrigiu as janelas de IG do osso nasal e da tricúspide (auditoria da fila herdada, `05`). Antes dela, R14.33, SHA-256 `bef7664b14e26820268055a8c730959b9c92856522f6b2e39759e0867c112a24`. A R14.33 aplicou, com liberação do médico em 06/10/2026, as seis propostas que a versão anterior deste arquivo trazia para a R14.32 (seção 3).

Este arquivo funde e substitui, no que se refere à parte científica:

1. o dossiê de Claude R14.28 (03/10/2026);
2. a revisão Q1–Q8 do ChatGPT (`Revisao_Cientifica_R14_32_Q1_Q8.pdf`) e a investigação com tabelas e scripts (`Investigacao_R14_32`);
3. o dossiê consolidado do ChatGPT (`Dossie_Consolidado_R14_32_2026_10_06`), com a recuperação documental de Ciobanu S1 e dos PDFs FEBRASGO;
4. o adendo de busca seletiva do ChatGPT de 06/10/2026 (`Adendo_Busca_Seletiva_R14_32.pdf`);
5. a conferência de cada achado no código da R14.32 e uma busca própria, feitas por Claude em 06/10/2026;
6. as mudanças da R14.33 e seus testes;
7. as mudanças de 10/10/2026 (R14.36 a R14.40) e o pente fino da R14.39 (`07`).

**Hierarquia de fontes, confirmada pelo médico em 06/10/2026: FEBRASGO → CBR → ISUOG.** SMFM, RCOG, FMF, INTERGROWTH e artigos originais complementam lacunas, com atribuição explícita. Para conferir uma equação vale a publicação que a criou.

Qualquer mudança além do que está descrito como aplicado depende de liberação explícita do médico.

## Legenda do tipo de evidência

| Marca | Significado |
|---|---|
| INTEGRAL | texto completo da fonte primária lido |
| RESUMO | só o resumo ou a página editorial foi lido |
| SECUNDÁRIA | reprodução por terceiros (planilha, outro artigo, contrato interno) |
| CÁLCULO | conta independente feita por Claude ou pelo ChatGPT, com oráculo próprio |
| CÓDIGO | conferido por Claude no HTML (R14.32 para o diagnóstico; R14.33 para o que mudou) |
| RECEBIDO | afirmado em relatório de outra IA e ainda não conferido por Claude |
| INFERÊNCIA | conclusão de quem analisou, não da fonte |

---

## 1. Correções feitas nesta fusão

Estas correções resolvem contradições entre os materiais recebidos. Onde um documento anterior diz outra coisa, vale o que está aqui.

**1.1 Hadlock 1991 não é decisão pendente.** O código registra a **DECISÃO C0-A**: percentil pela equação original em ln(PFE), σ ln = 0,12; a Tabela 1 impressa fica só como referência histórica (CÓDIGO: comentário de `HADLOCK_SD_LN`, ajuda do cartão de peso e aviso exibido quando o percentil é < 20). Ficam corrigidos: o resumo de Claude que dizia que a escolha "nunca foi adjudicada na linha R14", e a `MATRIZ_PENDENCIAS.csv` e a seção 11 do consolidado do ChatGPT, que a listavam como P1. A diferença numérica entre equação e tabela continua documentada (seção 2.2); o que saiu foi a ideia de que exista uma decisão a tomar.

**1.2 Aviso de Hadlock na tela: números corretos, atribuição a conferir.** O resumo de Roberts et al. (AJOG 2025, DOI 10.1016/j.ajog.2025.03.032) confirma os 176.060 exames e o subdiagnóstico de 5,1% citados pelo app (RESUMO). A frase "p10 pela equação ≈ p16–17 da tabela" **não aparece nesse resumo**. Ela é compatível com Adu-Bredu et al. (BJOG 2026, DOI 10.1111/1471-0528.70296), cujo resumo diz que o p10 da equação corresponde ao p17 da tabela, numa coorte de 35+0 a 36+6 semanas e com reanálise funcional da tabela (RESUMO). O cálculo de Claude com interpolação normal da Tabela 1 dá cerca de p14,5 em todas as idades de 10 a 40 semanas (CÁLCULO). Conclusão: o valor depende do método usado para interpolar a tabela. Isso corrige a afirmação de Claude em 06/10 de que "o número da tela pode estar errado": ele é defensável, mas a atribuição está provavelmente no artigo errado.

**1.3 PSV-ACM: o aviso após 35 semanas já existe.** A R14.32 já avisa sobre falso-positivo a partir de 35 semanas, mas só quando a PSV está alta ou limítrofe (CÓDIGO). A proposta anterior de Claude de "criar aviso a partir de 35 semanas" fica substituída pela da seção 3.

**1.4 Colo: parte do problema já estava resolvida.** O rótulo "limítrofe" de 26–30 mm só aparece antes de 24 semanas, e a conduta terapêutica automática foi retirada (C0-C1E-05) (CÓDIGO). Continua em aberto o uso de "curto" e "muito curto" em qualquer IG (seção 2.9).

**1.5 INTERGROWTH: o app já troca fórmula e curva juntas.** Com a curva INTERGROWTH o peso passa a ser o Hadlock de 3 parâmetros, e a faixa é 18–41 semanas, alinhada à política do consórcio de outubro de 2025 (CÓDIGO). A planilha oficial aceita até 294 dias (42+0), o que contradiz a própria instrução; isso não deve ser copiado para o app.

**1.6 Testes da R14.32 e da R14.33 foram executados.** O consolidado do ChatGPT diz que a interface da R14.32 não foi reexecutada. Ela foi, por Claude, em 05–06/10/2026: suíte de regressão com 48.184 checagens e 0 falhas em Chromium e WebKit, e teste dos rótulos com 740 checagens e 0 falhas. A R14.33 passou na mesma suíte (48.184/0 em Chromium e WebKit) e no teste das mudanças (278/0; a R14.32 falha 104 dessas checagens). Continua sem teste o iPhone/Safari físico, com atualização e uso offline. WebKit no Linux não substitui o aparelho.

**1.7 Identificação da FEBRASGO de líquido.** "Nº 43" sozinho é ambíguo. Citar pelo título, "Ultrassonografia obstétrica do terceiro trimestre da gestação", Femina 2025, DOI 10.61622/0100-7254536202507, Tabela 1 p. 833. Os cortes de líquido do app foram corroborados e não mudam.

**1.8 Hierarquia.** Documentos antigos (CONTEXTO de 17/09, REFERENCIAS(5), handoff R14.11) trazem FEBRASGO → ISUOG → Rumack → CBR/SBR. Vale FEBRASGO → CBR → ISUOG, confirmada pelo médico em 06/10/2026.

---

## 2. Estado por módulo

### 2.1 Peso estimado — Hadlock 1985

- **Implementado (CÓDIGO):** `hadlock4` (DBP, CC, CA, F) é o padrão; `hadlock3` (CC, CA, F) é usado com a curva INTERGROWTH. Medidas em cm, peso em g, log10.
- **Fonte:** Hadlock FP, Harrist RB, Sharman RS, Deter RL, Park SK. AJOG 1985;151(3):333–337. DOI 10.1016/0002-9378(85)90298-4. Tabela II, p. 334. INTEGRAL (cópia universitária pública, lida pelo ChatGPT; o download local falhou, então não há hash do PDF).
- **Conferência:** coeficientes iguais aos do artigo; 120 comparações aritméticas sem divergência (CÁLCULO, adendo de 06/10). Claude conferiu os coeficientes no HTML (CÓDIGO).
- **Estado: CONFIRMADO.** Os rótulos "Hadlock 1/2/3/4" variam entre aparelhos; identificar sempre pelas medidas usadas.
- **Nota prática:** "Hadlock de 4 medidas" no aparelho é esta mesma fórmula. Isso não diz qual curva o aparelho usa para o percentil (seção 2.2).

### 2.2 Percentil de peso — Hadlock 1991

- **Implementado (CÓDIGO):** ln(PFE) = 0,578 + 0,332·IG − 0,00354·IG², σ ln = 0,12; Φ de dupla precisão (`phiPreciso`, R14.27); domínio 10 a < 41 semanas. Decisão C0-A.
- **Fonte:** Hadlock FP, Harrist RB, Martinez-Poyer J. Radiology 1991;181:129–133. DOI 10.1148/radiology.181.1.1887021. Equação na p. 131 e Tabela 1 na p. 130. INTEGRAL (investigação do ChatGPT).
- **Conferência:** modelo, σ e medianas (670, 1.210, 1.953, 2.813 e 3.619 g) batem com o artigo. Os percentis da equação **não** reproduzem a Tabela 1. Exemplos: p10 em 32 semanas, 1.674 g pela equação × 1.621 g pela tabela; em 40 semanas, 3.103 × 3.004 g; p3 em 40 semanas, 2.888 × 2.714 g. Comparação de 155 células (CÁLCULO).
- **Anomalia da Tabela 1:** o p97 de 30 semanas (1.649 g) é menor que o p90 (1.824 g). Não copiar a tabela sem revisar consistência.
- **Literatura recente:**
  - Roberts et al., AJOG 2025 (RESUMO): equação e tabela não são a mesma referência; usar a tabela subdiagnosticaria restrição em 5,1% de 78.660 pacientes; se se deseja maior detecção, preferir a equação.
  - Adu-Bredu et al., BJOG 2026 (RESUMO): p3 e p10 da tabela equivalem aproximadamente a p1 e p6 da equação; o p10 da equação equivale ao p17 da tabela. Resumo confirmado por Claude em 06/10/2026: em 21.874 gestações de 35+0 a 36+6 semanas, 7,2% abaixo de p10 pela equação × 4,2% pela tabela. Os números de p3 (2,3% × 0,8%) vieram da revisão do ChatGPT (RECEBIDO).
  - Estudo de Cambridge na AJOG (RESUMO, repositório institucional): perto do termo, o percentil de Hadlock discriminou melhor os extremos de peso ao nascer que o INTERGROWTH.
  - Alerta NHS/RCOG de 10/12/2025 (PRN02254) contra curvas de peso INTERGROWTH, por identificarem menos fetos pequenos (RECEBIDO; Claude não abriu o documento).
  - Revisão comparativa de diretrizes de RCF na AJOG (abril de 2026, RESUMO): a escolha da curva de crescimento continua entre os pontos sem consenso internacional.
- **Aviso na tela (R14.33):** 176.060 exames e 5,1% das pacientes atribuídos a Roberts 2025; p10 da equação ≈ p17 da tabela atribuído a Adu-Bredu 2026, com a ressalva de que depende do método de interpolação. Na tela de referências entrou a nota sobre o alerta do NHS England divulgado pelo RCOG em dezembro de 2025 (verificado por Claude em fontes secundárias: os serviços ingleses deveriam deixar as curvas de peso INTERGROWTH até 31/03/2026, sem curva substituta definida no alerta; parte dessas fontes é do Perinatal Institute, que desenvolve a curva GROW, então há conflito de interesse).
- **Estado: DECIDIDO (C0-A), com diferença entre referências documentada.** A equação é a opção que detecta mais fetos pequenos, e é a escolhida.
- **Teste opcional no aparelho**, só para explicar divergências entre o laudo do aparelho e o app: IG 32+0 com PFE ≈ 1.650 g. Se o aparelho mostrar p8, ele usa a equação, igual ao app; se mostrar p11–12, usa a tabela.

### 2.3 Curva alternativa — INTERGROWTH-21st (2020)

- **Implementado (CÓDIGO):** `ig21Lambda`, `ig21Mu`, `ig21Sigma`, `ig21Z`; IG de 18 a 41 semanas; fórmula de peso trocada para Hadlock de 3 parâmetros; a troca vale só para o exame em curso.
- **Fontes:** Stirnemann J, Salomon LJ, Papageorghiou AT. UOG 2020;56:946–948. DOI 10.1002/uog.22000. Manuscrito aceito, Table S1, script R e planilha oficial: INTEGRAL. Política de idade gestacional do consórcio, outubro de 2025: INTEGRAL (recomenda 18–40 semanas e permite até 41 quando clinicamente justificado).
- **Conferência (CÁLCULO, adendo de 06/10):** 486/486 parâmetros LMS, 162/162 medianas e 810/810 quantis concordam com o HTML; diferença máxima de Z na ordem de 10⁻¹³.
- **Estado: CONFIRMADO** para equações e associação com a fórmula. A Table S2 impressa não foi obtida; não se afirma concordância célula a célula com ela.

### 2.4 Doppler fetal — Ciobanu 2019 (AU, ACM, RCP)

- **Implementado (CÓDIGO):** equações da Table S1, IG em dias; mediana da AU linear no IP; ACM e RCP em polinômio log10; dispersões em log10.
- **Fonte:** Ciobanu A, Wright A, Syngelaki A, et al. UOG 2019;53:465–472. DOI 10.1002/uog.20157. Table 2 p. 468 e Table S1. INTEGRAL; S1 recuperada (DOCX, SHA-256 `462701e98e87380826d9f86e3497636abf3af595a7553e7ac9c9136d2c433ffb`).
- **Conferência:** as linhas da Table 2 são semana + 3 dias, não + 0. Comparando na mesma idade em dias (198 comparações), o app difere da tabela em no máximo 0,0006 (AU), 0,0043 (ACM) e 0,0019 (RCP); todas as diferenças relativas ficam abaixo de 0,25% (CÁLCULO, Claude e ChatGPT). Irrelevante com IP medido com duas casas.
- **Estado: FECHADO — manter as equações.**
- **Pendente (documental):** carta de DeVore (UOG 2021;57:349–350, DOI 10.1002/uog.23578, com Appendix S1 em planilha) e réplica de Wright, Wright e Nicolaides (UOG 2021;57:350–351, DOI 10.1002/uog.23579). Sem acesso ao texto em nenhuma das buscas, inclusive a de Claude em 06/10. Não atribuir aos autores preferência por equação ou tabela.

### 2.5 Crescimento seriado — queda > 50 percentis e intervalo ≥ 21 dias

- **Implementado:** queda > 50 pontos percentílicos é critério contributivo de RCF tardia; o app só a interpreta automaticamente entre exames separados por ≥ 21 dias.
- **Fontes:** Gordijn SJ et al. UOG 2016;48:333–339, DOI 10.1002/uog.15884, Tabela 6 p. 338 (critério > 2 quartis, sem intervalo definido). Salomon LJ et al., ISUOG 2019, UOG 2019;53:715–723, DOI 10.1002/uog.20272, p. 717: intervalo entre exames tipicamente de pelo menos 3 semanas, para reduzir falso-positivo. RCOG Green-top 31 (Morris RK et al., BJOG 2024;131:e31–e80, DOI 10.1111/1471-0528.17814), seção 7.2.1: intervalo mínimo de 14 dias, com preferência de 21–28 dias para velocidade de crescimento. INTEGRAL pelo ChatGPT; RECEBIDO para Claude.
- **Estado: PRESERVADO como APP_POLICY** de comparabilidade, não como texto literal do Delphi e não como frequência de vigilância. A citação da ISUOG 2019 entrou no cartão de velocidade e na tela de referências (R14.33).

### 2.6 Artérias uterinas

- **Implementado (CÓDIGO):** a via é explícita (`VIA_UT`, nunca inferida pela IG); desde a R14.36 cada exame novo começa em **transabdominal** (decisão do médico), com aviso para confirmar a via no 1º trimestre enquanto ela não for tocada. O app recusa classificar quando curva, via e IG são incompatíveis (`utRefCompativel`). Quem classifica é o **IP médio** (C0-B2); a barrinha por lado (R14.36) é só de consulta. Incisura por lado: marcado = presente; desmarcado com IP do lado = ausente; o laudo cita só a presença (`07`, seção 1).
- **Fontes:** Gómez O et al. UOG 2008;32:128–132, DOI 10.1002/uog.5315 (transvaginal 11–14 semanas, transabdominal 15–41). Cavoretto PI et al. UOG 2023;61:474–480, DOI 10.1002/uog.26092, Table 3 p. 478 (transabdominal 10+0–39+0). 42 valores conferidos (CÁLCULO, ChatGPT). Bhide A et al., ISUOG 2021, UOG 2021;58:331–339, DOI 10.1002/uog.23698 (técnica).
- **Estado: CONFORME.** Nenhuma diretriz FEBRASGO, CBR ou ISUOG acessada impõe uma das duas curvas. O destaque editorial da ISUOG de abril de 2023 sobre Cavoretto pede validação externa e não é recomendação normativa.

### 2.7 PSV da artéria cerebral média

- **Implementado (CÓDIGO, R14.33):** mediana `exp(2,31 + 0,046·IG)`; ≥ 1,5 MoM elevada; 1,3 a < 1,5 limítrofe, rotulada como faixa de atenção do app; a partir de 35 semanas, PSV alta ou limítrofe gera aviso de falso-positivo (inclui pós-transfusão) e PSV normal gera aviso de que não exclui anemia; fora de 15+0–40+6 a PSV é registrada, mas não interpretada, e o texto separa o cálculo até 40+6 da validação de 15–36 semanas. Cortes e fórmula não mudaram.
- **Fontes:**
  - Mari G et al. NEJM 2000;342:9–14, DOI 10.1056/NEJM200001063420102: fórmula e limiar confirmados; a coorte diagnóstica foi de **15 a 36 semanas** (INTEGRAL, ChatGPT).
  - Mari G et al. UOG 1995;5:400–405, DOI 10.1046/j.1469-0705.1995.05060400.x: nomograma original com 135 fetos normais (RESUMO; métodos completos não acessados).
  - SMFM Clinical Guideline #8, AJOG 2015;212:697–710, DOI 10.1016/j.ajog.2015.01.059.
  - Maisonneuve E et al. Fetal Diagn Ther 2017;42:225–231, DOI 10.1159/000456661 (RESUMO): 150 gestantes com aloimunização grave avaliadas entre 34 e 37 semanas; sensibilidade da PSV isolada de 69%, e de 94% somando sinais de hidropisia; mais falsos positivos após transfusão prévia.
- **Operador:** o app classifica PSV elevada com ≥ 1,5 MoM; a fonte escreve > 1,5. Sem efeito prático (o MoM calculado nunca é exatamente 1,5); mantido, registrado no pente fino de 06/10/2026.
- **Exibição (R14.35):** perto de 1,3 e 1,5 o MoM ganha casas para nunca parecer igual ao corte com classe diferente.
- **Faixa de 1,3–1,49 MoM:** o valor de 1,29 MoM aparece na literatura associado a anemia leve (Mari 2000, segundo fontes secundárias; Rahimi-Sharbaf, Arch Iran Med 2012, RESUMO), que a PSV não prediz bem. Não é corte diagnóstico; o app agora diz isso. O app usa 1,3, não 1,29 — diferença mantida, sem impacto prático com PSV medida em cm/s.
- **Estado: RESOLVIDO NA R14.33 quanto à redação.** O cálculo do MoM é correto; o desempenho diagnóstico continua não validado depois de 36 semanas, e o app agora informa isso.

### 2.8 Átrio do ventrículo lateral

- **Implementado (CÓDIGO, R14.33):** < 10 mm normal; entre 9 e < 10 mm o cartão pede para confirmar a técnica e correlacionar com o SNC, com seguimento a critério clínico, sem retorno automático e sem menção no laudo; 10 a < 13 leve; 13 a 15 moderada; > 15 grave. Até a R14.32 a faixa de 9–9,9 mm era "No limite superior", com retorno em 3–4 semanas.
- **Fontes:** FEBRASGO morfológico, p. 822 (< 10 mm normal; PDF anexado). Malinger G et al., ISUOG 2020, UOG 2020;56:476–484, DOI 10.1002/uog.22145, Figura 5 (< 10 mm normal). Fox NS et al., SMFM Consult #45, AJOG 2018;219:B2–B9, DOI 10.1016/j.ajog.2018.04.039, p. B7 (10–12 leve, 13–15 moderada, > 15 grave). Sharon-Weiner M et al. Prenat Diagn 2022;42(2):278–286, DOI 10.1002/pd.6076 (RESUMO): 121 fetos com átrio isolado de 9–9,9 mm entre 21 e 24 semanas, comparados a 123 controles < 9 mm; tiveram mais investigação pré-natal, mas taxas semelhantes de sequela no neurodesenvolvimento.
- **Estado: RESOLVIDO NA R14.33.** O retorno em 3–4 semanas, que não tinha respaldo, saiu. A faixa 9–9,9 mm é observação operacional, não categoria de diretriz. Os intervalos decimais da graduação ([10,13), [13,15], > 15) são tradução operacional dos números inteiros da SMFM e devem ser rotulados assim.

### 2.9 Colo uterino

- **Implementado (CÓDIGO, R14.33):** ≤ 25 mm com IG < 24 semanas: "colo curto"; ≤ 25 mm com IG ≥ 24 semanas ou sem IG: "comprimento cervical reduzido" (estado `red`, cor vermelha), sem categoria de risco; sem rótulo separado de 15 mm, mas ≤ 15 mm acrescenta a checagem do sinal do lama; 26–30 mm "limítrofe" só antes de 24 semanas; sem conduta automática. Até a R14.32: ≤ 15 "muito curto" e 16–25 "curto" em qualquer IG.
- **Fontes:** FEBRASGO morfológico, p. 828: corte de 25 mm antes de 24 semanas (PDF anexado). Coutinho CM et al., ISUOG 2022, UOG 2022;60:435–456, DOI 10.1002/uog.26020 (INTEGRAL, ChatGPT): rastreio transvaginal entre 18 e 24 semanas; valores fixos < 15 mm, < 20 mm e ≥ 30 mm aparecem no contexto de gestante **sintomática**. SMFM Consult Series #70, 2024 (PDF anexado): tratamento depende de IG, história, sintomas e gemelaridade.
- **Estado: RESOLVIDO NA R14.33.** As duas escolhas de implementação (fim do rótulo "muito curto" na janela; cor vermelha em "comprimento cervical reduzido") foram mantidas por decisão delegada pelo médico em 06/10/2026. Na R14.35, a conclusão do laudo passou a citar o colo como achado materno, e não morfológico fetal. O operador ≤ 25 mm foi mantido (a FEBRASGO usa o corte de 25 mm; a ISUOG escreve < em outros valores).

### 2.10 Dilatação do trato urinário (UTD)

- **Implementado (CÓDIGO):** `classificaUTD` gera `ST.utd`; qualquer dilatação calicial no pré-natal entra como A2-3; sem cálices, parênquima, ureter, bexiga e oligoâmnio avaliados, o estado fica "incompleto" e lista o que falta. `ST.estr.pel` é só a faixa bruta da pelve.
- **Fonte:** Nguyen HT et al. 2021 update on the urinary tract dilation (UTD) classification system. Pediatr Radiol 2022;52:740–751, DOI 10.1007/s00247-021-05263-w, Figura 1; correção 2023;53:1217 (detalhes em `04_REFERENCIAS_BASE_R14_28.md`, A.5). Texto integral sobre cálice central no pré-natal ainda sem acesso; a regra se apoia na Figura 1.
- **Estado: CONFORME.** A distinção central × periférica é pós-natal e não se aplica ao pré-natal. O caso "pelve 0,5 cm isolada = A1 incompleto" foi resolvido em 05/10/2026: não era regressão.

### 2.11 Líquido amniótico

- **Implementado:** oligoâmnio com MBV < 2 cm ou ILA < 5 cm; polidrâmnio com MBV ≥ 8 cm ou ILA ≥ 24 cm; graduação do polidrâmnio pela SMFM Consult #46, Tabela 2.
- **Fonte:** FEBRASGO, terceiro trimestre (seção 1.7), Tabela 1 p. 833. O texto foi acessado pela web pelo ChatGPT; o download deu HTTP 403, então o PDF não está anexado.
- **Estado: CONFIRMADO E PRESERVADO.**

### 2.12 Datação por CCN — Hadlock 1992

- **Fonte:** Hadlock FP, Shah YP, Kanon DJ, Lindsey JV. Radiology 1992;182(2):501–505. DOI 10.1148/radiology.182.2.1732970. RESUMO: 416 pacientes, CCN de 2 mm a 12 cm.
- **Estado: SOURCE_FREEZE_PENDING.** O contrato interno (verificador 84/84) confirma só a reprodução secundária. O domínio de produto 2–85 mm é escolha do app, não domínio literal do artigo. Não confundir com o peso de Hadlock 1985/1991.

### 2.13 Apresentação (R14.29–R14.32)

Mudanças de interface, sem regra clínica nova: data do exame em cartão próprio (R14.29); datas em dd/mm/aaaa (R14.30); data digitada em dia/mês/ano, com suspensão das dependências quando inválida (R14.31); rótulo de percentil que nunca contradiz a classificação (`rotP`, com espaço fino U+202F depois de < e >) e concordância de número no laudo UTD (R14.32). Casas decimais extras na exibição não representam precisão clínica adicional.

---

### 2.14 Tamanho do bebê para a paciente — Vintzileos 1984 (R14.39)

- **Implementado (CÓDIGO):** comprimento (cm) = 6,18 + 0,59 × fêmur (mm), só com fêmur 3,0–9,0 cm, linha "Para a paciente" na aba Medidas e no Modo Paciente, com número redondo; **nunca no laudo**.
- **Fontes:** Vintzileos AM et al., Obstet Gynecol 1984;64:779-82, PMID 6390277 (RESUMO, com a fórmula). Milner 1994, DOI 10.1002/jcu.1870220407: erro aleatório ±6%, a melhor de seis funções para gestação única (RESUMO). Hadlock 1984, DOI 10.7863/jum.1984.3.1.1: DP 2,4 cm (RESUMO). Lim 2000, DOI 10.1046/j.1469-0705.2000.00053.x: variação entre populações (RESUMO). Faixa de fêmur 30–90 mm: perinatology.com (SECUNDÁRIA).
- **Estado: FORA DA HIERARQUIA, AUTORIZADO** pelo médico em 10/10/2026 (FEBRASGO/ISUOG/Rumack/CBR não trazem fórmula). Sem validação na população brasileira.

## 3. Mudanças aplicadas na R14.33 (liberadas em 06/10/2026)

Patch `patch_r14_33.py` reconstrói a R14.33 byte a byte a partir da R14.32. Sem mudança de cálculo, curva, corte numérico, `valmm()`, `cmpMedida()` ou schema.

1. **Átrio de 9–9,9 mm** normal, sem retorno automático (seção 2.8).
2. **PSV em gestação avançada:** aviso de que PSV normal depois de 35 semanas não exclui anemia; pós-transfusão no aviso de falso-positivo; texto do domínio separando cálculo e validação (seção 2.7).
3. **Colo depois de 24 semanas ou sem IG:** "comprimento cervical reduzido" (seção 2.9).
4. **Aviso de Hadlock:** atribuição corrigida (seção 2.2).
5. **Documentação e tela de referências:** Hadlock 1985 com DOI e tabela; INTERGROWTH com Table S1; Roberts e Adu-Bredu; nota do alerta do NHS England; ISUOG 2019 para os 21 dias; PSV com validação 15–36, Maisonneuve e faixa de atenção; FEBRASGO de líquido pelo título e DOI; átrio pela FEBRASGO, ISUOG 2020 e SMFM #45; linha nova para o colo.
6. **PSV de 1,3–1,49 MoM** identificada como faixa de atenção do app.

## 3.1 Decisões de 06/10/2026 (delegadas a Claude pelo médico)

- **Colo (R14.33):** mantidos o rótulo único "colo curto" na janela (com checagem do sinal do lama em ≤ 15 mm) e a cor vermelha em "comprimento cervical reduzido".
- **Fila herdada:** auditada (`05`). Na R14.34 entraram E1, E2, D1, D2 e D4. Fica de fora o D3 (zoom), que só deve mudar com teste no aparelho.

## 3.2 Mudanças de 10/10/2026 (R14.36 a R14.40, liberadas pelo médico)

Resumo; detalhes, hashes e testes no `07`.

1. **R14.36:** via das uterinas transabdominal por padrão, com aviso no 1º trimestre; barrinha de consulta por lado; incisura por quadradinho.
2. **R14.37:** Medidas começa pela biometria; abas no rodapé; avisos do Laudo dobrados com "por quê"; barra Copiar laudo · Copiar conclusão; simetria; campo em edição não é empurrado. Botões e fontes inalterados.
3. **R14.38:** correções da bateria de testes (flutuantes, teclado, 320 px).
4. **R14.39:** tamanho do bebê para a paciente (2.14); "Próximo pendente" em todas as abas.
5. **R14.40:** limpeza do pente fino, sem efeito clínico.

## 4. Documentos que ainda faltam

| Documento | Para quê |
|---|---|
| DeVore 2021 (10.1002/uog.23578) + Appendix S1 + réplica (10.1002/uog.23579) | Saber a posição dos autores sobre equação × tabela de Ciobanu |
| Corpo de Roberts 2025 (10.1016/j.ajog.2025.03.032) | Confirmar volume e páginas (233:331.e1-11), não verificados |
| Corpo de Mari 1995 (10.1046/j.1469-0705.1995.05060400.x) | Métodos e domínio do nomograma |
| Corpo de Hadlock 1992 (10.1148/radiology.182.2.1732970) | Equação da CCN e fim do SOURCE_FREEZE_PENDING |
| Table S2 do INTERGROWTH 2020 | Conferência célula a célula |
| Fonte nacional (FEBRASGO/CBR) para categorias de colo e átrio | Substituir categorias operacionais por fonte da hierarquia |
| Corpo de Vintzileos 1984 (Obstet Gynecol 64:779) | Confirmar a faixa de fêmur e o erro no texto original (hoje: resumo + fonte secundária) |
| Arquivos do adendo de busca seletiva (CSVs, `conferir_peso_fontes.py`) | Citados no PDF, mas não recebidos |
| Texto do alerta do NHS England/RCOG (2025) | Ler no original, e não só em fontes secundárias |

## 5. Pendências técnicas (não bibliográficas)

- **Publicar a R14.40** como `index.html` e reenviar `CONTEXTO.md`, `README.md` e `suite_regressao_doppler.py` (excluídos do GitHub em 10/10/2026, site em 404).
- Testar a R14.40 em iPhone/Safari físico: teclado numérico nos campos de data, barras do rodapé com teclado aberto, área segura, campo parado, uso offline e atualização.
- Validação clínica formal: nenhuma das conferências acima a substitui.

## 6. Contagens de verificação

São de suítes diferentes. Não somar como número de exames independentes, e não tratar como prova de ausência de defeitos.

| Verificação | Resultado | Quem e quando |
|---|---|---|
| Suíte de regressão R14.39 e R14.40 (18 grupos), Chromium e WebKit | 63.832 checagens, 0 falhas | Claude, 10/10/2026 |
| Diferenciais R14.35/R14.36/R14.37/R14.38/R14.39/R14.40 | até 400 exames aleatórios por par; só as mudanças decididas diferem | Claude, 10/10/2026 |
| Tamanho do bebê, 1.001 valores de fêmur | 0 falhas (Chromium e WebKit) | Claude, 10/10/2026 |
| Suíte de regressão R14.32, Chromium e WebKit | 48.184 checagens, 0 falhas | Claude, 05–06/10/2026 |
| Suíte de regressão R14.33, Chromium e WebKit | 48.184 checagens, 0 falhas | Claude, 06/10/2026 |
| Mudanças da R14.33 (`t33.py`), Chromium e WebKit | 278 checagens, 0 falhas (104 falhas na R14.32); 278/0 também na R14.34 | Claude, 06/10/2026 |
| Mudanças da R14.34 (`t34.py`), Chromium e WebKit | 112 checagens, 0 falhas (66 falhas na R14.33); 112/0 também na R14.35 | Claude, 06/10/2026 |
| Mudanças da R14.35 (`t35.py`), Chromium e WebKit | 630 checagens, 0 falhas (152 falhas na R14.34) | Claude, 06/10/2026 |
| Rótulos de percentil (`t32.py`) na R14.34 e na R14.35 | 740/0 nas duas | Claude, 06/10/2026 |
| Suíte de regressão R14.34, Chromium e WebKit | 48.184 checagens, 0 falhas | Claude, 06/10/2026 |
| Rótulos de percentil R14.32 (`t32.py`) | 740 checagens, 0 falhas (298 falhas na R14.31) | Claude, 06/10/2026 |
| Data do exame R14.31 | 40/40 em Chromium e WebKit | Claude, 05/10/2026 |
| Ciobanu na mesma IG | 198 comparações; diferença ≤ 0,0043 | Claude e ChatGPT, 06/10/2026 |
| Hadlock 1991, equação × tabela | 155 células | ChatGPT, 06/10/2026 |
| Hadlock 1985, duas fórmulas | 120 comparações, 0 falhas | ChatGPT, 06/10/2026 |
| INTERGROWTH: LMS, medianas, quantis | 486 + 162 + 810, 0 falhas | ChatGPT, 06/10/2026 |
| Uterinas | 42 valores | ChatGPT, 06/10/2026 |
| Hadlock 1991: p10 da equação na Tabela 1, por interpolação normal | ≈ p14,5 de 10 a 40 semanas | Claude, 06/10/2026 |
| Contrato CCN Hadlock 1992 | 84/84 (reprodução secundária) | ChatGPT, data do pacote |


---

<!-- ARQUIVO: 06_PENTE_FINO_R14_35.md -->

# Pente fino geral — R14.34 → R14.35

Data: 06/10/2026. Auditor: Claude. Base auditada: R14.34 (`4152a234…`). Versão resultante: R14.35 (`47b3d14c74c611dd1fc44ee7b2e6a58700d856f6bc13cdb96edcd8d43879dbc4`), liberada pelo médico ("Tudo").

## 1. Escopo e método

1. **Integridade:** reconstrução da cadeia de patches, hash, sintaxe, IDs, referências de elementos, schema e worker.
2. **Regressão:** suíte completa e testes dirigidos de cada versão.
3. **Exames simulados:** 1º trimestre com 9 e 12 semanas, morfológico de 22 semanas, 3º trimestre de 30 semanas e troca de feto no gemelar, lendo cartão, síntese e laudo.
4. **Varredura de textos:** frases e citações que sobraram de versões antigas.
5. **Validação de dados clínicos e citações:** completa para tudo o que foi inserido em 06/10/2026.
6. **Coerência documental:** dossiê, CONTEXTO, README e hashes.

## 2. Resultado da R14.34

- **Íntegra:**
  - os patches reconstroem a R14.33 e a R14.34 byte a byte;
  - 332 IDs únicos, nenhuma referência `$()` a ID inexistente;
  - SCHEMA 14; `sw.js` R14.23-SW2 inalterado;
  - publicada como `index.html` + `sw.js`, carrega sem erro e registra o worker em Chromium e WebKit (o 404 visto no servidor de testes era só a ausência do `sw.js` naquela pasta).
- **Testes:** suíte 48.184/0 (Chromium e WebKit); rótulos de percentil (`t32.py`) 740/0; `t33.py` 278/0; `t34.py` 112/0.
- **Exames simulados:** coerentes. Com 12 semanas os marcadores entram no laudo; com 9 semanas, não. Átrio de 9,5 mm é normal e não aparece no laudo; colo de 20 mm com 22 semanas é "colo curto", e com 30 semanas, "comprimento cervical reduzido". No gemelar, o osso nasal é por feto e o colo é compartilhado.
- **Textos antigos:** só sobraram ramos de código que não são mais executados (`atr==='lim'`, `colo==='muito'`). Não aparecem na tela.
- **Dados e citações conferidos:**
  - Maisonneuve 2017 (69% entre 34 e 37 semanas) e Sharon-Weiner 2022 (RESUMO).
  - Roberts 2025: 176.060 exames e 5,1% de 78.660 pacientes (RESUMO). O DOI está correto; o volume e as páginas "233:331.e1-11" não foram confirmados.
  - Adu-Bredu 2026: p10 da equação ≈ p17 da tabela, e 7,2% × 4,2% abaixo de p10 em 21.874 gestações de 35+0 a 36+6 semanas (RESUMO). Isso confirma o que antes estava como RECEBIDO.
  - FEBRASGO morfológico 2025 (PDF anexado): exame entre 20 e 24 semanas; osso nasal ≥ 4,5 mm; átrio < 10 mm; colo ≤ 25 mm antes de 24 semanas; CCN de 45–84 mm para 11 a 13+6 semanas.
  - Nomogramas do osso nasal no 2º trimestre (RESUMOS).
  - Alerta do NHS England divulgado pelo RCOG (fontes secundárias).

## 3. Achados

1. **Valor exibido igual ao corte com classe diferente** (mesma família do rótulo de percentil da R14.32):
   - PSV: "1,50 MoM — Limítrofe" com MoM de 1,4985, em 99 combinações de IG e velocidade.
   - CPR: "0,85 · p5 = 0,85 · abaixo do p5", em cerca de 0,2% das combinações de IP.
   - Umbilical: "IP 1,57 acima do p95", com o p95 exibido também como 1,57.
   - Uterinas: a média de dois lados (ex.: 1,585) aparecia "1,58" acima do p95 de 1,58. Este último caso foi achado pelo teste novo durante a correção.
   - Em todos, a classificação estava correta.
2. **Colo listado como "achado morfológico" na conclusão**, embora seja achado materno. Já vinha de antes da R14.33.
3. **Operador da PSV:** o app usa ≥ 1,5 MoM e a fonte (SMFM #8, Mari 2000) escreve > 1,5. Sem efeito prático, porque o MoM calculado nunca é exatamente 1,5. Mantido, porque operadores clínicos não mudam sem decisão específica; fica registrado.
4. **Documentação desatualizada:**
   - o dossiê ainda dizia que as escolhas do colo aguardavam conferência e que Adu-Bredu estava pendente;
   - a pasta de saída tinha a versão antiga do relatório de auditoria (que ainda chamava a prega nucal de erro provável) e dossiês antigos já superados.

## 4. O que entrou na R14.35

- **Achado 1:** as funções `casasPar`, `fxVal` e `fxCorte` acrescentam casas (até 5) quando valor e corte pareceriam iguais com 2 casas. Aplicadas ao MoM da PSV (no cartão, na barra, no laudo e na síntese), à CPR (valor, p5, cortes de 1,0 e 1,3, laudo e avisos), à faixa p5/p50/p95 dos vasos e das uterinas e ao IP médio das uterinas (na tela e no laudo, 1º e 2º/3º trimestres). Só muda a exibição; a classificação continua no valor bruto.
- **Achado 2:** a função `achadosTxt()` separa achado materno de achado fetal na conclusão. Exemplos: "com achado materno: colo curto"; "com achado(s) morfológico(s): ventriculomegalia e achado materno: colo curto". O título da síntese passa a "Peso adequado, achado materno" quando o colo é o único achado.
- **Achados 3 e 4:** registrados no dossiê e no CONTEXTO; arquivos superados removidos da pasta de saída.

## 5. Testes da R14.35

| Teste | Resultado |
|---|---|
| `t35.py` (mudanças da R14.35), Chromium e WebKit | 630 checagens, 0 falhas; na R14.34, 152 falhas |
| `t34.py`, `t33.py` e `t32.py` na R14.35 | 112/0, 278/0 e 740/0 |
| Suíte de regressão completa, Chromium e WebKit | 48.184 checagens, 0 falhas nos dois |

## 6. Continua pendente

- Teste em iPhone físico (campos de data, uso offline, atualização) e publicação.
- D3 (zoom bloqueado): só com teste no aparelho.
- Documentos não obtidos: carta de DeVore e réplica, corpo de Mari 1995, Hadlock 1992, Table S2 do INTERGROWTH, corpo de Roberts 2025 (para o volume e as páginas) e texto original do alerta do NHS.


---

<!-- ARQUIVO: 05_AUDITORIA_FILA_HERDADA_R14_35.md -->

# Auditoria da fila herdada — R14.33 (com o que entrou na R14.34)

Data: 06/10/2026. Baseline: `index.html` R14.33, SHA-256 `bef7664b14e26820268055a8c730959b9c92856522f6b2e39759e0867c112a24`. Auditor: Claude. Nada foi alterado no código.

**Escopo:** todos os itens das seções 5.1 e 5.4 do `CONTEXTO.md` e a tabela original de pendências do CONTEXTO de 17/09/2026, recuperada do histórico da conversa (inclui itens que a seção 5.4 tinha resumido).

**Método:**
1. Localizar a regra no código da R14.33.
2. Reproduzir o comportamento no navegador (Playwright, Chromium) quando o item tem efeito na tela ou no laudo.
3. Conferir a fonte na hierarquia FEBRASGO → CBR → ISUOG.
4. Classificar como conforme, erro demonstrado, diferença de referência ou ajuste de redação.

## 1. Resultado em uma linha

A maior parte da fila já estava resolvida em versões anteriores ou não era defeito (20 linhas da seção 4). Ficaram dois erros demonstrados, do mesmo tipo: marcador classificado fora da janela de IG da sua fonte. Um terceiro suspeito (prega nucal) foi descartado na conferência. Dois deles vêm de itens herdados resolvidos só em parte ("domínio de 11–14 semanas dos marcadores" e "Doppler antes de 11 semanas": o ducto venoso ganhou janela, o osso nasal e a tricúspide não) e do item "osso nasal de 4,5 mm". Há ainda três ajustes de documentação ou acessibilidade.

## 2. Erros demonstrados e prováveis

### E1 — Osso nasal e regurgitação tricúspide do 1º trimestre sem janela de IG (ERRO DEMONSTRADO)

- **O que acontece:** com IG de 8, 9 ou 10 semanas, modo embrião, osso nasal "ausente" e tricúspide com 70 cm/s em ≥ metade da sístole saem como alterados no cartão. O laudo conclui "marcadores ultrassonográficos alterados — osso nasal ausente/hipoplásico e regurgitação tricúspide" (reproduzido em Chromium).
- **Por que é erro:** o próprio app já aplica ao ducto venoso a janela do rastreio de 11+0 a 13+6 semanas (C0-C1D.1), e a TN depende do CCN de 45–84 mm. Osso nasal e tricúspide ficaram de fora. Antes de 11 semanas o osso nasal ainda não ossificou, então "ausente" é esperado, e não marcador.
- **Fonte:** FEBRASGO, ultrassonografia de 1º trimestre (protocolo citado no app); FMF.
- **Proposta:** dar ao osso nasal e à tricúspide a mesma janela do ducto venoso (IG 11+0 a 13+6, e CCN 45–84 mm quando informado). Fora dela, registrar o achado sem classificar e sem levar à conclusão do laudo.

### E2 — Osso nasal do 2º trimestre: corte fixo de 4,5 mm em qualquer IG (ERRO DEMONSTRADO)

- **O que acontece:** com 17 semanas, osso nasal de 3,8 mm sai como "Osso nasal hipoplásico", com razão de verossimilhança de 6,6 para T21, e o laudo diz "fora dos valores de referência para o segundo trimestre". O mesmo valor com 22 semanas sai igual.
- **Por que é erro:** a FEBRASGO (Protocolo de Obstetrícia nº 43, 2025, Ultrassonografia morfológica do segundo trimestre, PDF anexado) dá "normal ≥ 4,5 mm" dentro de um exame que, segundo o mesmo documento, deve ser feito entre 20 e 24 semanas. O osso nasal cresce com a IG. O p5 fica entre cerca de 2,4 e 3,7 mm entre 16 e 18 semanas em várias populações, e 4,5 mm só se aproxima do p5 por volta de 20 a 23 semanas (Narayani 2013, Índia; série turca de 1.467 fetos; nomograma do norte da Índia, 2025; RESUMOS). Fora da janela, o corte fixo produz falso alarme de aneuploidia antes de 20 semanas e passa a ser permissivo depois de 24.
- **Proposta:** aplicar o corte de 4,5 mm só entre 20+0 e 24+6 semanas. Fora disso, mostrar a medida com a nota "o corte da FEBRASGO vale no morfológico de 20–24 semanas; o osso nasal cresce com a IG", sem rótulo de hipoplasia e sem entrar no laudo como alterado. A razão prega frontonasal/osso nasal (< 0,8) segue a mesma janela.

### E3 — Prega nucal ≥ 6 mm sem janela de IG (CORRIGIDO: NÃO ERA ERRO)

Na primeira leitura, Claude olhou só o ramo de classificação e concluiu que faltava janela. Na verdade, o campo da prega nucal fica oculto e é zerado fora de 16 a 24 semanas (`prgWrap`, `valeP`), então a classificação nunca roda fora da janela. A definição de prega espessada da literatura (≥ 6 mm no meio do 2º trimestre, entre 15 e 24 semanas conforme a série; FEBRASGO: normal < 6,0 mm no morfológico) é compatível. **Conforme.** Observação menor: `g<=24` aceita 24+0 e exclui 24+1 a 24+6, diferente da janela do osso nasal adotada na R14.34 (até 24+6). Sem impacto relevante; mantido.

## 3. Ajustes de documentação e acessibilidade

- **D1 — Intervalos de seguimento na tela de referências.** As linhas "Intervalo de reavaliação (FEBRASGO, Protocolo de RCF 2018)" e "Vigilância com diástole ausente/reversa — a cada 2–3 dias antes de 34 sem" sugerem que o app define intervalos. Ele não define desde a remoção dos intervalos fixos. Proposta: reescrever como "referência para o médico; o app não sugere intervalos".
- **D2 — Número de protocolo FEBRASGO ambíguo.** Cartões de líquido e textos da síntese citam só "Protocolo nº 43 (2025)", e o PDF do morfológico de 2025 também se identifica como nº 43. O checklist cita "Protocolo 78 (Femina, 2025)", mas o 78 é o morfológico de 2018. Proposta: citar pelo título nos textos visíveis.
- **D3 — Zoom bloqueado.** A meta `viewport` tem `maximum-scale=1, user-scalable=no`. O iPhone ignora isso desde o iOS 10, mas o Android respeita, o que prejudica leitura e acessibilidade. Proposta: liberar o zoom e conferir o layout no celular.
- **D4 — Comentário interno desatualizado na FCF.** O comentário do código ainda diz "faixa única usada nos dois trimestres", o que contradiz a implementação atual. Não aparece na tela. Proposta: corrigir junto com qualquer outra mudança.

## 4. Itens conferidos sem defeito

| Item herdado | Situação na R14.33 | Evidência |
|---|---|---|
| Uterina direita/esquerda percentilada isoladamente | Lado isolado só registrado (`utLadoNeutro`); classifica só o IP médio | Código |
| Gómez: tabela híbrida 32–41 sem | Table 2 impressa célula a célula de 11 a 41 sem (C0-B2) | Código |
| PSV 1,29–1,49 MoM | Faixa de atenção do app, explícita (R14.33) | Código e teste |
| Incisura sozinha virando "Doppler alterado" | Achado descritivo; não dispara a conclusão (C0-B2) | Código |
| "Sequência de deterioração" | Virou "Territórios hemodinâmicos avaliados"; texto distingue RCF precoce de tardia | Código |
| Ducto venoso antes de 11 semanas | Janela de 11+0–13+6; fora dela é registrado, sem classificar | Código |
| Atribuição das faixas de FCF | Separadas por segmento: Doubilet e Benson 1995 e Doubilet 2000 (6–7 sem), Silva e Bailão 2000 (6–9+6), Pettersen e Faria 2001 (10–13+6), sem referência de 14 a 19+6, FIGO 2015 a partir de 20 | Código e referências |
| Léxico SRU 2024 | "Ovo cego" aposentado e "gestação anembrionada" mantida; "atividade cardíaca", evitar "viável", "perda gestacional precoce" — conferidos no resumo de Rodgers et al., Radiology 2024;312:e240122 | Código; RESUMO |
| Colo com conduta sem contexto | Conduta removida (C0-C1E-05); rótulo por janela (R14.33) | Código e teste |
| Bordas da ventriculomegalia | R14.33 | Código e teste |
| Gemelar com ambos < p10 | Estado `both-sga-overlap` sinaliza a sobreposição antes de fechar sFGR (GEM-P0-02, ISUOG 2025) | Código |
| Restos ovulares por espessura | Só painel teórico; espessura isolada nunca gera diagnóstico nem conduta | Código |
| Persistência de `CURVA`/`CURVA_TN` | No payload desde o schema v3 | Código |
| Modo Embrião/Só saco dependendo de CSS | Estado semântico `VIAB_MODE` (STATE-P1-02) | Código |
| `eColo`/`ePla` como campos por feto | Compartilhados desde o B5 | Código |
| Persistência sem validade | Exame salvo leva versão do motor e do schema, mostra a idade e só é recuperado se o médico aceitar. Sem prazo de expiração, por escolha de desenho | Código |
| Reentrância `run()` → `ctxAuto()` → `setCtx()` | `setCtx` só é chamado quando o contexto muda; o ciclo termina | Código (leitura estática) |
| Cadência de seguimento da RCF | Intervalos fixos removidos; o app não automatiza vigilância (ver D1) | Código |
| Órbitas: biocular alto no laudo | Entra no laudo ("acima do p90… Sukonpan 2008") | Código |
| Cinco "falsos negativos" da suíte de 17/09 | Reproduzidos; todos seguem o Delphi (tabela abaixo) | Navegador |

### Os cinco "falsos negativos", reproduzidos na R14.33

| Cenário | Resultado | Leitura |
|---|---|---|
| 28 sem, PFE p8, uterinas > p95 | RCF (PFE < p10 + uterinas > p95) | Correto: critério da RCF precoce |
| 28 sem, PFE p8, diástole zero | RCF (diástole ausente) | Correto |
| 28 sem, PFE p50, diástole zero | RCF (diástole ausente) | Correto: critério isolado antes de 32 sem |
| 34 sem, PFE p8, uterinas > p95 | Peso < p10 com Doppler incompleto; pede o IP da umbilical | Correto: uterina não é critério da RCF tardia |
| 34 sem, PFE p50, diástole reversa | Tamanho incompleto (sem CA) + achado de alta gravidade, encaminhamento especializado | Correto: depois de 32 sem a diástole não é critério isolado, e o achado não foi silenciado |

A suíte de 17/09 esperava outra coisa porque foi escrita antes de o app exigir PFE + CA e de adotar o Delphi literal. Não é regressão.

## 5. Prioridade proposta

## 6. Aplicado na R14.34 (06/10/2026)

O médico delegou a escolha a Claude. Aplicado: **E1**, **E2**, **D1**, **D2** e **D4**. Não aplicado: **D3** (zoom), porque no iPhone, o aparelho de uso, a meta já é ignorada pelo Safari, e liberar o zoom pode desarrumar as barras fixas sem teste no aparelho; e E3, que não era erro.

- **E1:** osso nasal e tricúspide do 1º trimestre só classificados entre 11+0 e 13+6 semanas; fora disso, ou sem IG, o cartão registra o achado sem classificar e o laudo não o inclui.
- **E2:** osso nasal do 2º trimestre com o corte de 0,45 cm só entre 20+0 e 24+6 semanas (a razão prega frontonasal/osso nasal segue a mesma janela); fora dela, medida registrada com nota, sem rótulo de hipoplasia.
- **D1:** linhas de intervalo e vigilância da tela de referências deixam claro que o app não sugere intervalos.
- **D2:** cartões de líquido citam "FEBRASGO, Ultrassonografia obstétrica do 3º trimestre (2025), Tabela 1"; checklist e osso nasal citam o morfológico do 2º trimestre pelo título (nº 43, 2025; antes nº 78, 2018). A frase sobre o desempenho do ILA no polidrâmnio continua como "Protocolo nº 43, 2025", porque não foi possível confirmar de qual dos dois documentos ela vem.
- **D4:** comentário interno da FCF corrigido.

**Colo (R14.33):** mantidas as duas escolhas: um só rótulo "colo curto" na janela, com a checagem do sinal do lama em ≤ 15 mm, e vermelho em "comprimento cervical reduzido". Motivo: a medida exata continua no laudo, e o vermelho evita suavizar um colo muito curto no 3º trimestre.

Testes da R14.34: mudanças (`t34.py`) 112/112 em Chromium e WebKit, com 66 falhas na R14.33; teste da R14.33 (`t33.py`) 278/278; suíte completa 48.184 checagens, 0 falhas, em Chromium e WebKit.


---

<!-- ARQUIVO: 02_TEORIA_DO_APP_R14_40.md -->

# Teoria embutida no aplicativo — Calculadora Doppler Obstétrico R14.40

> **Adendo de 10/10/2026 (R14.36 a R14.40).** O corpo abaixo é a extração literal da R14.35. Textos novos ou alterados desde então:
> - **Uterinas (aba Doppler):** "Só consulta: barrinhas pela curva do IP médio. Incisura: marque só se presente." Quadradinho "Incisura" por lado. Aviso no 1º trimestre: "Confirme a via. Transabdominal vem pré-selecionada; no 1º trimestre as duas vias são usadas. Toque na via usada para confirmar." Com Gómez, acrescenta: "A curva de Gómez no 1º trimestre é transvaginal; para medida transabdominal, a curva compatível é Cavoretto.".
> - **Doppler fetal:** campo "Umbilical — diástole" em linha própria.
> - **Medidas:** "Para a paciente: tamanho do bebê ≈ N cm (faixa ≈ a–b cm) · pelo fêmur (Vintzileos 1984) · não entra no laudo".
> - **Laudo:** cada aviso do "Confira antes de laudar" mostra a 1ª frase e o resto em "por quê ›"; o de Hadlock resume-se a "Este app usa a equação de Hadlock 1991; calculadoras com a tabela impressa dão percentil maior." Botões "Copiar laudo" e "Copiar conclusão".
> - **Referências:** linha nova "Tamanho do bebê (só para a paciente)" com Vintzileos 1984, Milner 1994 e o aviso de fonte fora da hierarquia.
>
> O texto dos avisos e do laudo não mudou (diferenciais no `07`).

Texto extraído literalmente do `index.html` R14.35 (SHA-256 `47b3d14c74c611dd1fc44ee7b2e6a58700d856f6bc13cdb96edcd8d43879dbc4`): explicações dos blocos expansíveis, dicas de técnica, painel teórico e painel de referências. Campos de formulário omitidos. A seção 5 reúne, também literalmente, os avisos clínicos condicionais que o motor só exibe com certos dados.

## 1. Explicações dos blocos expansíveis

### 1.1 Calcular a IG por exame anterior ou DUM

Usa a data do exame atual, definida no topo desta aba.

### 1.2 Velocidade de crescimento · opcional

Preenchida com a data do exame usado na datação. Altere se o exame de crescimento foi outro.
Na RCF tardia, queda de CA ou PFE superior a 2 quartis (>50 percentis) é um dos três critérios contributivos do Delphi — e vale mesmo com o peso ainda acima do p10. Quedas menores são sinal de alerta, não critério. O intervalo ideal entre exames é de 21 a 28 dias.

### 1.3 Líquido amniótico · opcional

A FEBRASGO recomenda o uso preferencial do maior bolsão pela simplicidade, e o considera mais acurado para oligoâmnio. Na suspeita de polidrâmnio, porém, trabalhos recentes indicam desempenho superior do ILA. Critérios (FEBRASGO nº 43, 2025): oligoâmnio ILA < 5 cm ou MBV < 2 cm · polidrâmnio ILA ≥ 24 cm ou MBV ≥ 8 cm. Quando os dois métodos divergem, o app mostra os dois e não escolhe um vencedor.
Na comparação randomizada, o ILA diagnosticou significativamente mais oligoâmnio (RR 2,39), com mais induções e mais cesáreas por sofrimento fetal, sem melhora demonstrada dos desfechos perinatais.
FEBRASGO, Ultrassonografia obstétrica do 3º trimestre (2025) · Cochrane CD006593 (Nabhan & Abdelmoula 2008).

### 1.4 Achados morfológicos · opcional

Preencha só o que medir. Cada valor é interpretado para a idade gestacional e sugere o que checar junto.

### 1.5 Marcadores qualitativos

Marque presente ou ausente. Sem medida, mas contam para saber se o achado é isolado — por isso "não avaliado" também importa aqui.

### 1.6 Checklist anatômico — órgãos-alvo

FEBRASGO 77: a avaliação anatômica no 1º trimestre é dirigida aos órgãos-alvo. Não identificar alteração aqui não dispensa o morfológico de 2º trimestre.
• DBP abaixo do p5 pede atenção redobrada à coluna.
• Não diagnostique placenta prévia no 1º trimestre — a migração ocorre na maioria dos casos.
Gemelar: corionicidade entre 8 e 15 semanas — sinal do lambda indica dicoriônica; sinal do T, monocoriônica.

### 1.7 Tabela completa dos critérios

Os quatro critérios acima são transvaginais — o título da Table 2 é "Guidelines for Transvaginal Ultrasonographic Diagnosis". Em exame apenas transabdominal a fonte descreve uma exceção: embrião com CCN ≥ 1,5 cm sem atividade cardíaca. Achados suspeitos devem, em geral, ser reavaliados em 7 a 10 dias.
Documente a ausência de atividade cardíaca por modo M (ou modo B). Meça o CCN em corte sagital, com o embrião em posição neutra, sem incluir a vesícula vitelina — a partir de ~7 semanas o embrião flete, e medir o maior eixo qualquer superestima.
A ISUOG orienta não usar rotineiramente Doppler espectral, mapeamento colorido ou power Doppler antes de 11 semanas — a saída acústica é bem maior e o alvo é pequeno. Modo B e modo M não têm indício de dano nessa fase. Se o Doppler for clinicamente indicado, mantenha o índice térmico ≤ 1,0 e o tempo de exposição no mínimo.
Os cortes antigos (CCN 0,5 cm, SG 1,6 cm) vinham de séries pequenas e produziam falso-positivo — por isso foram elevados.

### 1.8 Tabela rápida e aviso sobre as referências

Antes de laudar: tabelas de referência publicadas divergem entre si de forma clinicamente relevante (até ~37% no p5 da ACM). Use sempre a mesma, cite-a no laudo, e confira qual está carregada no seu aparelho.

### 1.9 Técnica — o que falseia o valor

- Filtro de parede alto apaga a diástole real e simula diástole zero. Baixe ao mínimo antes de cravar AEDF/reversa.
- PRF/escala alta comprime a diástole contra o zero — mesmo erro.
- Ganho excessivo preenche a janela espectral com ruído e simula fluxo inexistente.
- Fora da FC basal (110–160): bradicardia sobe o IP, taquicardia desce.
- Movimento respiratório fetal distorce a onda — espere apneia, registre 3+ ciclos.
- ACM: não comprima o polo cefálico. Ângulo 0° para PSV.
- AU: padronize alça livre — o IP muda entre inserção fetal e placentária.
- Peso: o erro aleatório do método é de ~10%, e piora nos fetos pequenos — justamente os que importam.

## 2. Dicas de técnica e interpretação

**2.1** Critérios da SRU/Doubilet (NEJM 2013). A Table 2 do artigo é explicitamente transvaginal. Por via transvaginal, CCN ≥ 0,7 cm sem atividade cardíaca, ou DMSG ≥ 2,5 cm sem embrião, fecham o diagnóstico de perda gestacional precoce. Em exame apenas transabdominal, a única exceção descrita pela fonte é embrião com CCN ≥ 1,5 cm sem atividade cardíaca — os cortes de 0,7 cm e 2,5 cm não são transportáveis para a via transabdominal. Foram escolhidos para especificidade de 100% — na dúvida, o certo é repetir, nunca antecipar. Documente a ausência de atividade cardíaca por modo M.

**2.2** Duas curvas disponíveis, alternáveis no botão ao lado do título. Hadlock: peso por Hadlock 1985 com quatro parâmetros, percentil por Hadlock 1991 — equação original em ln(EFW), SD=0,12 (escala log); é a referência populacional recomendada pela SMFM. INTERGROWTH-21st: padrão prescritivo internacional que inclui sítio brasileiro (Pelotas); usa o Hadlock de três parâmetros (CC, CA, F), sem DBP, e o percentil de Stirnemann 2020 — faixa recomendada 18–40 sem, extensão até 41 sem quando clinicamente justificada. Trocar a curva troca a fórmula junto — o peso em gramas também muda.

**2.3** Cada medida tem sua idade equivalente por Hadlock 1984, mostrada junto ao próprio campo (DBP, CC, CA, CF) — é descritiva: não há corte automático de 1, 1,5, 2 ou 3 semanas associado a ela, e ela nunca redata uma gestação já estabelecida (a datação oficial usa só HC+FL, método separado e validado — ver o cartão de IG).

**2.4** Relações entre as medidas — cada uma com sua própria adjudicação (auditoria 2026-09), não "faixas do aparelho": CF/CA — Hadlock 1983, faixa normal 20–24%, a partir de 22+0 sem (gate = política do app); CF/DBP — Hohler & Quetel 1981, faixa publicada 71–87% (a estatística do ±8% não é especificada no resumo), a partir de 23+0 sem (gate = política do app); CF/CC — descritiva, sem faixa auditável (Hadlock 1984 confirma a amostra, não uma tabela verificável); CC/CA — descritiva, reprodução secundária de Campbell (Br J Obstet Gynaecol 1977), estatística indeterminada no resumo original.

**2.5** Chitty & Altman, BJOG 2002 — percentis 3, 50 e 97 (cm) por semana dos ossos longos. O percentil de cada um aparece embaixo do próprio campo; aqui fica só a faixa, para quem quiser conferir.

**2.6** A FEBRASGO recomenda o uso preferencial do maior bolsão pela simplicidade, e o considera mais acurado para oligoâmnio. Na suspeita de polidrâmnio, porém, trabalhos recentes indicam desempenho superior do ILA. Critérios (FEBRASGO nº 43, 2025): oligoâmnio ILA < 5 cm ou MBV < 2 cm · polidrâmnio ILA ≥ 24 cm ou MBV ≥ 8 cm. Quando os dois métodos divergem, o app mostra os dois e não escolhe um vencedor. Na comparação randomizada, o ILA diagnosticou significativamente mais oligoâmnio (RR 2,39), com mais induções e mais cesáreas por sofrimento fetal, sem melhora demonstrada dos desfechos perinatais. FEBRASGO, Ultrassonografia obstétrica do 3º trimestre (2025) · Cochrane CD006593 (Nabhan & Abdelmoula 2008).

**2.7** Umbilical: mede a resistência da placenta — sobe quando a área de troca cai. Aqui o alto é que preocupa (IP acima do p95). Alça livre, sem contração fetal, ângulo próximo de zero. Cerebral média: mede a vasodilatação cerebral. Aqui o baixo é que preocupa (IP abaixo do p5 = centralização). Terço proximal, ângulo zero, sem comprimir o polo cefálico — a compressão falseia para baixo. Ciobanu et al. 2019 (FMF) — mesma coorte pras duas.

**2.8** Compartimento materno — reflete a placentação. Alto preocupa: IP médio acima do p95 — a referência ativa (Gómez ou Cavoretto, veja o botão no título do card) foi construída pro IP médio das duas artérias, não para cada lado isolado; os campos por lado servem de conferência de medida, sem classificação clínica própria. Confirme velocidade acima de 60 cm/s para garantir que é o tronco, não ramo colateral. Discordância importante entre os lados deve motivar revisão da técnica e do ponto de amostragem. A incisura protodiastólica pode ser marcada por lado, mas fica registrada como achado descritivo — CBR/FEBRASGO orienta não valorizar isoladamente presença ou ausência de incisura. Gómez 2008 · 11–41 semanas, citada pela ISUOG. 11–14 sem por via transvaginal, 15–41 sem por via transabdominal — valores não intercambiáveis entre vias.

**2.9** Território venoso de vigilância em fetos com comprometimento placentário. Onda ‘a’ ausente ou reversa representa alteração hemodinâmica de alta gravidade. A interpretação deve ser integrada à vitalidade fetal, idade gestacional e condição materna. Não é critério diagnóstico de restrição.

**2.10** Sem campo de incisura aqui, de propósito: entre 11 e 14 semanas ela é fisiológica — está presente em 46–64% das gestações normais — e não entra no modelo de risco da Fetal Medicine Foundation, que usa o IP médio. A incisura pode ser registrada no 2º/3º trimestre como achado descritivo, mas sua presença ou ausência isolada não modifica a classificação Doppler do app — a interpretação formal das artérias uterinas usa o IP médio das duas artérias. Se desejar registrá-la nessa fase, use o card de artérias uterinas da aba Doppler. Gómez 2008 mediu por via transvaginal entre 11–14 semanas e por via transabdominal entre 15–41 semanas — os valores de referência não são automaticamente intercambiáveis entre as duas vias. O app usa a mesma tabela para ambas as janelas por não ter campo de via; informe-se de que a medida foi feita pela técnica compatível com a fase do exame.

## 3. Painel teórico — Restos ovulares

Restos ovulares
A hierarquia do que prediz
1
Massa ecogênica intracavitária
Melhor desempenho diagnóstico entre os achados ultrassonográficos.
2
Vascularização ao Doppler
Aumenta a suspeita quando associada a massa. Isolada, pouco específica.
3
Espessura endometrial
Dado objetivo útil, mas inespecífico isoladamente.
Restos ovulares/RPOC são diagnóstico pós-evento gestacional que deve integrar história, sintomas e ultrassom; não devem ser definidos apenas pela espessura endometrial nem equiparados automaticamente a abortamento incompleto. Não há recomendação formal padronizada para o diagnóstico ultrassonográfico (Blyth et al., 2025 — revisão de 17 estudos).
1 · Massa ecogênica intracavitária
Na metanálise de Sundararajan et al. (AJOG 2024 — 11 estudos, 1.567 participantes) foi o marcador de maior acurácia: sensibilidade de cerca de 91,5% e especificidade de cerca de 84,3%. Os estudos são heterogêneos, e o achado não equivale a diagnóstico histológico automático.
2 · Espessura endometrial
Os cortes variam entre os estudos — 10 mm e 15 mm aparecem com frequência — e não existe corte isolado validado que determine diagnóstico ou tratamento. Na mesma metanálise, com corte de 10 mm, a sensibilidade foi de cerca de 66,7% e a especificidade de cerca de 86,6%, com intervalos de confiança amplos e desempenho inferior ao da massa ecogênica. A revisão de 2025 também encontrou grande heterogeneidade de limiares.
A espessura isolada nunca deve produzir "restos presentes" nem indicação de conduta. Reporte-a como dado objetivo.
3 · Doppler colorido
- A vascularização aumenta a suspeita quando associada a massa.
- Ausência de fluxo não exclui restos ovulares.
- Isolado, tem baixa especificidade — cerca de 85,0% de sensibilidade e 40,6% de especificidade na metanálise de 2024 — e não confirma RPOC sozinho.
- Não equipare qualquer fluxo endometrial a tecido retido; avalie a distribuição do fluxo e o miométrio quando pertinente.
Leitura combinada
Achado — Leitura
Massa ecogênica com vascularização — Fortalece a suspeita
Massa ecogênica avascular — RPOC permanece possível; coágulo é diferencial
Espessamento isolado — Achado inespecífico
Cavidade sem massa focal e endométrio fino — Reduz a probabilidade; não constitui regra universal isolada. Em Durfee et al. (2005), ausência de massa ou fluido complexo com endométrio < 10 mm tornou RPOC muito improvável — resultado de estudo, não regra diagnóstica.
Para o laudo: descreva a morfologia (massa, ecogenicidade, vascularização) e reporte a espessura como dado objetivo. Diferenciar tecido de coágulo é reconhecidamente difícil.
A decisão terapêutica depende do quadro clínico, estabilidade, sangramento, sinais infecciosos, evolução e preferência da paciente, além dos achados de imagem.
Considere sempre diagnósticos alternativos e correlacione com a clínica e com a queda do hCG. Fontes: Sundararajan et al., AJOG 2024 (DOI 10.1016/j.ajog.2023.11.1243) · Blyth et al., Hum Fertil 2025 (DOI 10.1080/14647273.2025.2522054) · Durfee et al., 2005 (estudo complementar).
</div

## 4. Painel de referências do app (como exibido)

Referências
Hierarquia adotada: FEBRASGO → CBR → ISUOG. FMF e demais fontes complementam os parâmetros não cobertos por essa ordem. Os consensos Delphi entram onde a FEBRASGO não detalha o critério operacional. Quando um critério vem de fora dessas fontes, está identificado como tal.
Biometria e crescimento
Peso fetal estimado — Curva selecionável no cartão de peso. Hadlock: Hadlock 1985, 4 parâmetros (DBP, CC, CA, F) — a fórmula do Rumack. INTERGROWTH-21st: Hadlock 1985, 3 parâmetros (CC, CA, F), que é a fórmula pressuposta pelo padrão. Fonte das duas fórmulas: Hadlock et al., AJOG 1985;151:333-337, Tabela II
Percentil de peso — Hadlock: Hadlock 1991, equação original em ln(EFW), SD=0,12 (escala log) — referência populacional recomendada pela SMFM; a Tabela 1 impressa do mesmo artigo é mantida só como referência histórica, por não ser matematicamente equivalente à equação (Roberts et al., AJOG 2025; Adu-Bredu et al., BJOG 2026). INTERGROWTH-21st: Stirnemann, Salomon & Papageorghiou, UOG 2020;56:946-948, equações da Table S1; faixa recomendada 18–40 semanas, extensão até 41 semanas quando clinicamente justificada (política INTERGROWTH 2025)
Idade por parâmetro — Hadlock 1984
Relação CC/CA — Campbell S. & Thoms A. Br J Obstet Gynaecol 1977;84:165-174 — domínio publicado 17 a 41 semanas. Fora dessa faixa o app não calcula a relação (a extrapolação para 13–16 e 42 sem foi removida em 2026-09). O abstract usa simultaneamente "95 per cent confidence limits" e "95th centile limit" — construção estatística indeterminada; os números da tabela só estão disponíveis por reprodução secundária (não no artigo original). Classificação automática removida em 2026-09 (auditoria R14) — a relação aparece só como referência descritiva, por bloco de 2 semanas, sem interpolação fracionária
Relações CF/CA, CF/DBP, CF/CC — Auditoria independente 2026-09 (R14) — cada uma com fonte e status próprios, não "faixas do equipamento": CF/CA — Hadlock et al. 1983 (AJR 141:979-984), faixa normal 20–24% (mean ± 2 SD), a partir de 22+0 sem (gate = política do app, pois "after 21 weeks" não define o primeiro dia no resumo). CF/DBP — Hohler & Quetel 1981 (AJOG 141:759-762), faixa publicada 71–87% (79 ± 8%; o resumo não especifica o que ±8 representa estatisticamente — "90% IC", usado em manuais de equipamento, não é confirmável na fonte), a partir de 23+0 sem (gate = política do app). CF/CC — Hadlock et al. 1984 (JUM 3:439-442) confirma a amostra (n=361, 15-42 sem), mas a tabela semanal de limites só foi vista em manuais de equipamento — sem faixa auditável, descritiva
Comprimento fetal — Vintzileos et al. 1984 — auxiliar, fora da hierarquia; informativo — exibido só no Modo Paciente, não entra no laudo
Por que Hadlock é o padrão — É a curva da tabela de referência da Fetalmed e a recomendação de referência populacional do protocolo de medicina fetal da FEBRASGO. O INTERGROWTH-21st fica disponível como alternativa prescritiva, selecionável no cartão de peso — não como padrão. Em dezembro de 2025, o NHS England (alerta de segurança divulgado pelo RCOG) orientou os serviços ingleses a deixar de usar as curvas de peso INTERGROWTH-21st, por identificarem menos fetos pequenos
Definição de RCF: duas leituras — A FEBRASGO caracteriza RCF suspeita já com PFE ou CA abaixo do p10. O consenso Delphi é mais restritivo e exige critério adicional. Quando as duas divergem, o app mostra as duas em vez de escolher por você
Critérios de RCF — Consenso Delphi (Gordijn, UOG 2016) · ISUOG Practice Guidelines 2020
Restrição seletiva em gemelar — Consenso Delphi gemelar (Khalil, UOG 2019;53:47-54). Solitário em qualquer corionicidade: PFE de um feto abaixo do p3. Monocoriônica: 2 de 4 contributivos (PFE < p10, CA < p10, discordância ≥ 25%, IP-AU do menor > p95). Dicoriônica: 2 de 3, sem a CA. Aplicado sobre curvas de feto único. ISUOG 2025 (UOG 2025, DOI 10.1002/uog.29166): se os dois fetos têm PFE abaixo do p10, ambos devem ser descritos como SGA — nomenclatura que pode sobrepor os critérios Delphi acima; o app não resolve essa sobreposição automaticamente
Percentil da circunferência abdominal — INTERGROWTH-21st (Papageorghiou, Lancet 2014;384:869-79) — tabela de centis, 14 a 40 semanas. Com a curva de peso em Hadlock, CA e peso vêm de referências diferentes e o app sinaliza a limitação; com a curva em INTERGROWTH-21st, as duas ficam na mesma fonte
Queda >2 quartis — RCOG Green-top 31 (2024) — equivale a 50 percentis. Intervalo mínimo de 21 dias entre os exames comparados: política do app, apoiada na ISUOG 2019 (Salomon et al., UOG 2019;53:715-723 — intervalo tipicamente de pelo menos 3 semanas)
Intervalo de reavaliação — O app não sugere intervalos de seguimento. Referência para o médico: FEBRASGO, Protocolo de RCF (Martinelli, Zugaib, Francisco, Bittar, 2018)
Doppler
Artéria umbilical — Ciobanu et al. Ultrasound Obstet Gynecol 2019;53:465-472 (FMF), 20+0–41+6 sem
Cerebral média — IP — Ciobanu et al. Ultrasound Obstet Gynecol 2019;53:465-472 (FMF), 20+0–41+6 sem
Cerebral média — PSV — Mari G et al. N Engl J Med 2000;342:9-14 — fórmula e corte de 1,5 MoM; validação diagnóstica entre 15 e 36 semanas. O app calcula de 15+0 a 40+6. Após 35 semanas: Maisonneuve E et al., Fetal Diagn Ther 2017;42:225-231. Faixa de atenção de 1,3 a 1,49 MoM: critério do app, não corte diagnóstico
Artérias uterinas — Duas referências selecionáveis (IP médio das duas artérias, nunca cada lado isolado) — nenhuma é tratada como "padrão internacional" ou substituta da outra; o próprio Cavoretto 2023 declara ausência de padrão internacionalmente endossado e necessidade de validação externa.
Gómez et al. Ultrasound Obstet Gynecol 2008;32:128-132 — transversal, 620 gestantes, 11–41 sem, p5/p50/p95, citada nas ISUOG Practice Guidelines. 11–14 sem via transvaginal, 15–41 sem via transabdominal — valores não intercambiáveis entre vias.
Cavoretto et al. Ultrasound Obstet Gynecol 2023;61:474-480 — longitudinal, 476 gestantes (2045 exames), população saudável de baixo risco, 10–39 sem, p3/p5/p10/p25/p50/p75/p90/p95/p97, 100% via transabdominal. Table 3 publicada usada como referência direta (não o modelo MEN contínuo — ver Oviedo-Cruz et al. 2024/Cavoretto et al. 2024, DOI 10.1002/uog.27550 e 27552)
Relação cerebroplacentária — critério ISUOG é < p5, incorporado desde 2026-09 via Ciobanu 2019/FMF (20+0–41+6 sem, mesma família agora usada pra AU e MCA) como via alternativa ao IP-AU no 3º componente da RCF tardia. O corte absoluto de 1,0 permanece como radar informativo adicional, não formal
Ducto venoso — IP (2º/3º tri) — Tongprasert F, Srisupundit K, Luewan S, Wanapirak C, Tongsong T. Gynecol Obstet Invest 2012;73:32-37 (14–40 sem) — origem dos percentis exibidos. Papel clínico conforme ISUOG 2020: vigilância, não critério diagnóstico de RCF
Vigilância com diástole ausente/reversa — ISUOG Practice Guidelines 2020 — a cada 2–3 dias antes de 34 sem (referência para o médico; o app não automatiza a vigilância)
Manejo da RCF — Protocolos de manejo de RCF definem vigilância e momento de resolução combinando Doppler, vitalidade fetal, idade gestacional e condição materna; este app não automatiza esses marcos.
Territórios do Doppler — FEBRASGO, Ultrassonografia obstétrica do 3º trimestre
Primeiro trimestre
Perda gestacional precoce — Doubilet PM et al., painel SRU, N Engl J Med 2013 · léxico multissociedades 2024
Datação pelo CCN — Hadlock 1992 · Robinson & Fleming permanece como comparação histórica
FCF — prognóstico precoce — Doubilet & Benson, JUM 1995 (limite inferior 100/120 bpm) e resumo autoral de Doubilet (faixa "poor")
FCF — FC rápida — Doubilet, Benson & Chow, AJR 2000 (≥135/≥155 bpm; bom prognóstico)
FCF — fisiologia 6–9+6 sem — Silva & Bailão, RBGO 2000, Tab. 2 (−2DP/M/+2DP por meia semana)
FCF — fisiologia 10–13+6 sem — Pettersen & Faria, RBGO 2001 (p5/p95 por semana completa)
FCF — 14–19+6 sem — Sem referência ultrassonográfica pontual validada: só registro
FCF — a partir de 20 sem — 110–160 bpm como alerta: faixa basal de CTG (FIGO 2015; Pildner von Steinburg 2013)
Translucência nucal — Faria 2004 — população brasileira · técnica FEBRASGO (Protocolo 63)
Osso nasal, ducto, tricúspide, uterinas — FEBRASGO, Protocolo 77 — Ultrassonografia no 1º trimestre. Osso nasal, ducto venoso e tricúspide são classificados só entre 11+0 e 13+6 semanas
Ducto venoso — IP (1º tri) — Pruksanusak et al., Gynecol Obstet Invest 2014;78:22-25, Tabela 2 (p. 24), lida no texto integral: PIV p5 0,69 · p50 0,92 · p95 1,13, constantes para CCN 45,9–75,5 mm (faixa observada). Onda A interpretada à parte.
Corte de 60 cm/s na tricúspide — Fetal Medicine Foundation
Cálculo de risco combinado — não realizado no app — a FEBRASGO remete ao software da FMF
Morfológico e estruturas
Checklist e valores de referência — FEBRASGO, Ultrassonografia morfológica do segundo trimestre (Protocolo de Obstetrícia nº 43, 2025; antes nº 78, 2018). O corte de osso nasal (≥ 4,5 mm) é aplicado só de 20 a 24 semanas, a janela do exame
Líquido amniótico — FEBRASGO — Ultrassonografia obstétrica do terceiro trimestre (Femina 2025, DOI 10.61622/0100-7254536202507), Tabela 1 — diagnóstico formal · SMFM Consult Series #46 (AJOG 2018), Tabela 2 — graduação do polidrâmnio · FEBRASGO nº 82 (2018) — referência histórica e técnica · Cochrane CD006593 (Nabhan & Abdelmoula 2008) — preferência do maior bolsão para oligoâmnio
Átrio do ventrículo lateral — Normal abaixo de 10 mm em qualquer IG: FEBRASGO (morfológico, 2025) e ISUOG 2020 (Malinger et al., UOG 2020;56:476-484). Graduação leve/moderada/grave: SMFM Consult Series #45 (10–12, 13–15 e > 15 mm; as faixas decimais são tradução operacional do app). Snijders & Nicolaides, UOG 1994 — referência histórica
Colo uterino — FEBRASGO (morfológico, 2025) — corte de 25 mm antes de 24 semanas · ISUOG 2022 (Coutinho et al., UOG 2022;60:435-456) — rastreio transvaginal entre 18 e 24 semanas; valores fixos como < 15 mm são do contexto de gestante sintomática · SMFM Consult Series #70 (2024) — a conduta depende do contexto clínico, e o app não a automatiza. Fora da janela de rastreio o app descreve "comprimento cervical reduzido", sem categoria de risco
Órbitas — Sukonpan & Phupong, J Med Assoc Thai 2008;91(9):1318-22, Tabelas 1 e 2 (p10/p50/p90, 15–40 sem, 595 medidas; conferidas célula a célula). Fora de p10–p90 = alerta, não diagnóstico.
Placenta — espessura — Bonilla-Musoles F. Diagnóstico con Ultrasonidos en Obstetricia y Ginecología. Valencia, 1972 — valores reproduzidos pelo Fetalmed, 16 a 38 sem. São média e variação, não percentis, e derivam da regra de bolso "espessura em mm ≈ IG em semanas, até ~4 cm". Nenhum guideline (FEBRASGO/ISUOG) adota corte diagnóstico para espessura placentária — por isso o app apenas descreve a medida e não emite laudo assertivo de placenta espessa ou fina
Ossos longos — Chitty & Altman, BJOG 2002 (percentis 3, 50 e 97)
Cerebelo — diâmetro transverso — Snijders RJ, Nicolaides KH. Ultrasound Obstet Gynecol 1994;4(1):34-48 — 14 a 38 semanas, percentis conferidos contra a tabela do Fetalmed. Fora dessa faixa o app não classifica (a versão anterior extrapolava até 40 sem)
Dilatação urinária — UTD Classification System — consenso multidisciplinar
Marcadores de aneuploidia — SMFM Consult Series #57
Restos ovulares — Sundararajan et al., AJOG 2024 (DOI 10.1016/j.ajog.2023.11.1243) · Blyth et al., Hum Fertil 2025 (DOI 10.1080/14647273.2025.2522054) · Durfee et al. 2005, complementar
Limitações assumidas
- Percentil da CA incorporado (INTERGROWTH-21st, p10 conferido linha a linha). A ISUOG define o critério (< p3 isolado, < p10 combinado). Um resultado negativo do app vale apenas para os parâmetros avaliados.
- Percentil da CPR incorporado desde 2026-09 (Ciobanu 2019/FMF, 20+0–41+6 sem) — usado como via alternativa ao IP-AU no 3º componente da RCF tardia. Desde o C0-B1, IP-AU e IP-ACM isolados também usam essa mesma família (Ciobanu 2019/FMF) — Acharya 2005 e Arduini & Rizzo 1990 ficam só como referência histórica, fora do motor ativo.
- Curvas de peso são de feto único — não há ajuste para gemelar.
- O percentil satura nas caudas; nesses casos o app mostra a distância do limiar.
As classificações são apoio à decisão. A conduta, o seguimento e o momento do parto são do obstetra, integrando vitalidade fetal e contexto materno.
</div

## 5. Avisos clínicos condicionais do motor

Estes textos não aparecem na tela estática: o motor só os mostra quando certos dados são preenchidos. Copiados literalmente do JavaScript da R14.35 (aspas e marcação HTML removidas). A análise de cada um está em `01_ESTADO_CIENTIFICO_R14_35.md`.

### 5.1 Peso — aviso Hadlock equação × tabela (percentil de peso < 20)

A equação original de Hadlock 1991 classifica mais fetos como pequenos do que a tabela impressa do mesmo artigo. Em 176.060 exames, usar a tabela em vez da equação subdiagnosticaria restrição em 5,1% das pacientes (Roberts AW et al., Am J Obstet Gynecol 2025;233:331.e1-11). Outra reanálise encontrou o p10 da equação equivalente a cerca do p17 da tabela, entre 35 e 36 semanas (Adu-Bredu TK et al., BJOG 2026); o número exato depende de como a tabela é interpolada. Este app usa a equação (decisão C0-A) — se você compara com uma calculadora que usa a tabela impressa clássica, a diferença acima explica a divergência. Perto do limiar, correlacione com a tendência de crescimento, não só o valor isolado.

### 5.2 Curva de peso selecionável (comentário do código)

'hadlock' — peso por Hadlock 1985 (4 parâmetros) e percentil por Hadlock 1991. 'ig21' — padrão INTERGROWTH-21st para o peso de Hadlock (Stirnemann, Salomon e Papageorghiou, UOG 2020;56:946-948). Esse padrão pressupõe o Hadlock de três parâmetros (CC, CA, F) — trocar a curva troca também a fórmula, senão o percentil sai enviesado. Faixa recomendada 18–40 sem; uso até 41 sem como extensão condicional (política INTERGROWTH 2025). Hadlock é sempre o ponto de partida de cada exame; a troca para INTERGROWTH vale só para o exame em curso.

### 5.3 PSV-ACM

- Texto de base: "A interpretação da PSV-ACM para anemia fetal pressupõe feto em risco para anemia; não é rastreio universal (SMFM Clinical Guideline #8)."
- ≥ 1,5 MoM: "Acima de 1,5 — risco de anemia moderada/grave". Com IP-ACM < p5: a velocidade elevada pode refletir o estado hiperdinâmico da centralização, e não anemia.
- 1,3 a < 1,5 MoM: "Limítrofe — acompanhar tendência", com a nota: "A faixa de 1,3 a 1,49 MoM é critério de atenção deste app, não corte diagnóstico: o corte validado é 1,5 MoM (Mari 2000), e abaixo dele a PSV não prediz de forma confiável a anemia leve."
- < 1,3 MoM: "Dentro da normalidade".
- IG ≥ 35 sem com PSV alta ou limítrofe: "PSV-ACM elevada após 35 semanas: a taxa de falso-positivo para anemia sobe nessa faixa e também após transfusão intrauterina prévia. Valorize mais a tendência entre exames do que um valor isolado aqui."
- IG ≥ 35 sem com PSV normal (novo na R14.33): "PSV-ACM dentro da normalidade após 35 semanas não exclui anemia fetal: nessa fase a sensibilidade da PSV isolada é menor (69% entre 34 e 37 semanas em aloimunização grave — Maisonneuve 2017). Em feto de risco, valorize sinais de hidropisia, a tendência entre exames e o contexto clínico."
- Fora de 15+0–40+6: "Este app calcula o MoM da PSV-ACM de 15+0 a 40+6 semanas (nomograma de Mari); a validação diagnóstica do estudo original foi feita entre 15 e 36 semanas (Mari 2000; SMFM Clinical Guideline #8)." A medida é registrada, mas não interpretada.

### 5.4 Átrio do ventrículo lateral

- > 15 mm: "Ventriculomegalia grave".
- 13 a 15 mm: "Ventriculomegalia moderada".
- 10 a < 13 mm: "Ventriculomegalia leve".
- 9 a < 10 mm (alterado na R14.33): "Normal" — "Abaixo de 1,0 cm é normal em qualquer idade gestacional. Valor próximo do limite: confirme a técnica de medida e correlacione com os demais achados do SNC; seguimento a critério clínico."
- < 9 mm: "Normal abaixo de 1,0 cm em qualquer idade gestacional."
- Técnica: corte transventricular, medida no glomo do plexo coroide, perpendicular ao eixo do ventrículo.

### 5.5 Colo uterino (alterado na R14.33)

- Técnica: "Medida por via transvaginal, bexiga vazia, três aquisições — anotar a menor. O corte de 25 mm vale antes de 24 semanas."
- ≤ 25 mm com IG < 24 sem: "Colo curto", com o contexto: "Comprimento cervical reduzido. A interpretação de risco e a conduta dependem da idade gestacional, sintomas, história obstétrica, gestação única ou múltipla e demais achados clínicos. Correlacionar com avaliação obstétrica." Laudo: "colo curto".
- ≤ 25 mm com IG ≥ 24 sem ou sem IG: "Comprimento cervical reduzido" — "Fora da janela de rastreio, o corte de 25 mm não tem o mesmo significado prognóstico" (ou "Sem IG informada, não é possível saber se o exame está na janela de rastreio"), seguido do mesmo contexto clínico. Laudo: "comprimento cervical reduzido; interpretação conforme a idade gestacional e o contexto clínico."
- ≤ 15 mm: sem rótulo próprio; o cartão acrescenta "Checar: afunilamento, sinal do lama, dinâmica ao esforço."
- 26 a 30 mm com IG < 24 sem: "Limítrofe".
- Acima disso: "Adequado". Sem conduta terapêutica automática (C0-C1E-05).

### 5.6 Osso nasal e tricúspide do 1º trimestre (R14.34)

- Classificados só entre 11+0 e 13+6 semanas, como o ducto venoso. Fora disso: "Fora da janela do rastreio de primeiro trimestre — O protocolo deste módulo se aplica entre 11+0 e 13+6 semanas." Para osso nasal ausente: "Antes de 11 semanas o osso nasal pode ainda não estar ossificado; registro sem classificação como marcador." Para a tricúspide: "Pico de X cm/s registrado, sem classificação por este protocolo." Sem IG: "Informe a idade gestacional para interpretar…". Fora da janela, nada disso entra no laudo.

### 5.7 Osso nasal do 2º trimestre (R14.34)

- Entre 20+0 e 24+6 semanas: "FEBRASGO, Ultrassonografia morfológica do segundo trimestre (Protocolo nº 43, 2025; antes nº 78, 2018): normal a partir de 0,45 cm no exame de 20 a 24 semanas." Abaixo disso, "Osso nasal hipoplásico"; razão prega frontonasal/osso nasal ≥ 0,80, "Razão prega/ON aumentada".
- Fora da janela: "Fora da janela do corte de 0,45 cm — O corte de 0,45 cm da FEBRASGO vale no exame morfológico de 20 a 24 semanas (IG atual: …). O osso nasal cresce com a idade gestacional; aqui a medida fica registrada, sem classificação de hipoplasia."

### 5.8 Exibição de valores perto dos cortes (R14.35)

- Quando o valor medido e o corte arredondados a 2 casas pareceriam iguais com brutos diferentes, os dois são exibidos com mais casas (até 5). Exemplos: "1,499 MoM — Limítrofe" em vez de "1,50 MoM — Limítrofe"; CPR "0,846 · p5 = 0,848 · abaixo do p5"; IP médio uterino "1,585" acima do p95 "1,580". Vale para PSV, CPR, faixa de referência dos vasos e IP médio das uterinas. A classificação não mudou.

### 5.9 Colo na conclusão do laudo (R14.35)

- "Feto com peso adequado para a idade gestacional (percentil X), com achado materno: colo curto." Com achado fetal junto: "com achado(s) morfológico(s): ventriculomegalia e achado materno: colo curto." Título da síntese quando o colo é o único achado: "Peso adequado, achado materno".


---

<!-- ARQUIVO: 03_DECISOES_E_CONTEXTO_R14_40.md -->

# CONTEXTO — Calculadora Doppler Obstétrico

**Leia este arquivo inteiro antes de alterar qualquer coisa.**
Substitui o `CONTEXTO v2026-09-17.md`, que descrevia uma versão anterior (`v2026-09-17-audit2`,
SHA `cd19896a…`, 341.769 bytes) e ficou desatualizado em pontos importantes (ver §7).

Atualizado em 10/10/2026 · versão atual **R14.40**
`index.html` SHA-256 `d5a9931092acab63cb59f95418f8992d7e9ca0d5591cdd10fb0863d926cfd0f5` (542.589 bytes)
(A R14.35 foi publicada como `index.html` em 07/10/2026. Em 10/10/2026, às 13:55, `index.html`, `CONTEXTO.md`, `README.md` e a suíte foram **excluídos** do GitHub sem reenvio — site em 404. Publique a R14.40 como `index.html` e confira que os quatro arquivos estão no repositório.)
`sw.js` R14.23-SW2 SHA-256 `868972f473094deafe00372b44de52f1e35b2ff15a576d6222d5b39f70fcc840`
Autor e único responsável clínico: Dr. Diogo S. Ribeiro (obstetrícia/medicina fetal, CRM 5789-AL).

Fonte da verdade para referências e adjudicações: **`REFERENCIAS_R14_28.md`** (seções A–H).
Este arquivo resume; quando divergir, vale o `REFERENCIAS` e, acima dele, o código.

---

## 0. Como trabalhar neste repositório

1. **Rode a suíte antes de começar** — `python3 suite_regressao_doppler.py index.html`. Se já começa falhando, descubra por quê antes de escrever uma linha.
2. **Proponha antes de aplicar.** O autor exige liberação explícita para qualquer alteração — inclusive correção de bug encontrado por conta própria.
3. **Rode a suíte antes de entregar**, e de novo depois de qualquer ajuste.
4. **Confirme cada achado no código presente.** Auditorias externas já descreveram bugs inexistentes, ou de outra base.
5. **Confira o SHA-256** antes de mandar para reauditoria: o hash acima é a versão corrente.
6. **Publicação:** o HTML precisa se chamar exatamente `index.html` na raiz (ver `README.md`). Em 02/10/2026 o site deu 404 porque o arquivo estava como `Calculadora.html`.
7. **Construção reproduzível:** cada versão R14.x foi gerada por `patch.py` a partir da anterior, byte a byte; o pacote `testes_R14_xx.zip` de cada entrega contém o script, os testes e os resultados.

---

## 1. Referências em uso na R14.40 (resumo da tabela "Referências" do app)

**Hierarquia: FEBRASGO → CBR → ISUOG.** FMF e demais fontes complementam o que essa ordem não cobre; consensos Delphi entram onde a FEBRASGO não detalha o critério operacional. É a instrução do autor de 30/09/2026, registrada no app e no `REFERENCIAS`. *(O CONTEXTO de 17/09 registrava FEBRASGO → ISUOG → Rumack → CBR/SBR; para este app prevalece a instrução mais recente.)*

| Parâmetro | Referência na R14.40 |
|---|---|
| PFE | Hadlock 1985 — 4 parâmetros (curva Hadlock) ou 3 parâmetros (curva INTERGROWTH) |
| Percentil de peso | Hadlock 1991, ln(EFW), **SD = 0,12** (`HADLOCK_SD_LN`); Φ de dupla precisão (`phiPreciso`, R14.27) |
| Percentil da CA | INTERGROWTH-21st (Papageorghiou 2014), colunas oficiais p10 e p90 (`T_CA_P10`, `T_CA_P90`) |
| Artéria umbilical, ACM (IP), CPR | **Ciobanu 2019 (FMF)**, 20+0–41+6 sem; o p5 da CPR vem da **equação** (`ciobanuCPRref`), não da tabela `T_CPR` |
| PSV-ACM | Mari 2000 |
| Uterinas | duas referências selecionáveis (Gómez 2008: TV 11–14, TA 15–41 / Cavoretto 2023: TA 10–39), sempre o IP **médio** das duas; via transabdominal pré-selecionada, com aviso para confirmar no 1º tri (R14.36); barrinha por lado só de consulta |
| Ducto venoso | 2º/3º tri: Tongprasert 2012 · 1º tri: Pruksanusak 2014 |
| Critérios de RCF | Delphi (Gordijn 2016) · ISUOG 2020; FEBRASGO mostrada em paralelo quando diverge |
| Restrição seletiva (gemelar) | Delphi gemelar (Khalil 2019): solitário PFE < p3 **em qualquer corionicidade**; MC 2 de 4, DC 2 de 3 |
| Queda longitudinal | RCOG 2024 (> 2 quartis = 50 percentis) |
| Líquido amniótico | FEBRASGO nº 43 (2025) Tabela 1 (diagnóstico) · SMFM #46 Tabela 2 (graduação do polidrâmnio) |
| TN | Faria 2004 (padrão, população brasileira); FMF carta 1998 alternável |
| UTD | Nguyen 2021 (*Pediatr Radiol* 2022) — ureter/parênquima/bexiga só contam com pelve ≥ 4 mm ou cálices dilatados |
| Órbitas | Sukonpan & Phupong 2008 (p10/p50/p90) — fora de p10–p90 é alerta, não diagnóstico |
| Ossos longos | Chitty & Altman 2002 (p3/p50/p97) |
| Cerebelo, átrio | Snijders & Nicolaides 1994 |
| Placenta | Bonilla-Musoles 1972 via Fetalmed — informativo (média e variação, não percentis) |
| Tamanho do bebê (só para a paciente) | Vintzileos 1984 (6,18 + 0,59 × fêmur em mm; fêmur 30–90 mm) — **fora da hierarquia**, autorizado pelo médico em 10/10/2026; nunca no laudo |

---

## 2. Decisões fechadas vigentes — NÃO reabrir sem decisão do autor

| Tema | Decisão (conferida na R14.28) |
|---|---|
| Queda longitudinal | `DEC-LONG-001`: estritamente **queda > 50 percentis e intervalo ≥ 21 dias**. Os 21 dias são política de comparabilidade do serviço, não texto literal do Delphi. |
| Tamanho fetal | Classificado por **PFE + CA** (R14.20–R14.22). Sem CA: não fecha AIG ("classificação de tamanho incompleta"); CA isolada pode fechar o que a regra permite. |
| Líquido | Oligoâmnio MBV < 2 / ILA < 5; polidrâmnio MBV ≥ 8 / ILA ≥ 24 (FEBRASGO, "Ultrassonografia obstétrica do terceiro trimestre", Femina 2025, DOI 10.61622/0100-7254536202507, Tabela 1 — "nº 43" sozinho é ambíguo); graduação SMFM #46. |
| Comparações nos cortes | Igualdade nunca é "abaixo/acima": `cmpMedida(a,b)` (tolerância `16 × EPSILON × max(1,|a|,|b|)`, só neutraliza ruído de ponto flutuante) em 26 comparações. **Não arredondar medidas nem alterar `valmm()`** — as tabelas têm literais com ruído próprio. |
| Percentil de peso | `phiPreciso()` só em `pctPesoFromZ()`; o `phi()` genérico (Doppler, CA, uterinas) foi mantido de propósito. Ponto nominal neutralizado em `|z − Z| < 1e-10`. |
| Discordância gemelar | Valor **bruto** preservado (ex.: 24,999999999999996); categoria por `discCat()`; exibição por `discFmt()` (inteiro → 2 → 3 → 4 casas, aceita só se o número exibido ficar na categoria do bruto; senão "<20%"/"<25%"). |
| Outro feto | `fetoOutro()` aplica o mesmo gate de PFE de `peso()` (finito, 50–7000 g inclusive). |
| IG ausente/inválida + AEDF/REDF | Estado próprio `aedf-ig-desconhecida`: mantém o achado de gravidade, não presume forma precoce/tardia, pede IG. |
| Terminologia | "Restrição do crescimento fetal" (FEBRASGO). Não usar "CIUR". |
| Worker | `sw.js` R14.23-SW2 mantido byte a byte desde a R14.23; HTML e worker têm versões independentes. |
| Rótulo de percentil (R14.32) | Função única `rotP()`: perto de um corte, se o número arredondado cairia no corte ou do lado errado, mostra o lado (`< p10`, `> p90`), a partir da **mesma comparação que decide a classe** (peso por q; CA por valor bruto × cortes oficiais; Doppler e cerebelo por valor × p5/p95; uterinas por `cmpMedida`). Vale em cartões, barras, barra do topo, síntese, conclusão e laudo. Depois de `<`/`>` vai espaço fino U+202F — sem ele, `<p10` dentro de `innerHTML` vira etiqueta e some. |
| Data do exame (R14.31) | Três campos numéricos dia/mês/ano, sem seletor nativo. `dtHoje` virou campo oculto em ISO, lido por todos os consumidores; data inválida ou incompleta deixa `dtHoje` vazio e suspende datas, IG por DUM/exame anterior e velocidade. Datas exibidas em dd/mm/aaaa (R14.30); a concepção na tela da paciente continua por mês, de propósito. |
| Átrio (R14.33) | < 10 mm é normal em qualquer IG; 9–9,9 mm deixou de ser "limite superior" com retorno em 3–4 semanas (sem fonte). Leve [10,13), moderada [13,15], grave > 15 mm — tradução operacional da SMFM #45. |
| Colo (R14.33) | Corte de 25 mm só na janela (IG < 24 sem): "colo curto". Fora dela ou sem IG: estado `red`, "comprimento cervical reduzido", sem categoria de risco. Sem rótulo separado de 15 mm (na ISUOG, < 15 mm é de gestante sintomática). 26–30 mm "limítrofe" só na janela. Sem conduta automática. |
| PSV-ACM (R14.33) | MoM calculado de 15+0 a 40+6; validação diagnóstica de Mari 2000 foi 15–36 sem (o texto diz isso). ≥ 35 sem: PSV alta → aviso de falso-positivo (inclui pós-transfusão); PSV normal → aviso de que não exclui anemia (Maisonneuve 2017). 1,3–1,49 MoM é faixa de atenção do app, não corte diagnóstico. |
| Hadlock 1991 (C0-A) | Equação em ln(PFE), σ ln 0,12; Tabela 1 só histórica. Não é decisão pendente. Aviso na tela: 5,1%/176.060 → Roberts 2025; p10 da equação ≈ p17 da tabela → Adu-Bredu 2026 (atribuição corrigida na R14.33). |
| Janelas de marcadores (R14.34) | Osso nasal, ducto venoso e tricúspide do 1º trimestre: classificados só de 11+0 a 13+6; fora disso, registro sem classificar e fora do laudo. Osso nasal do 2º trimestre: corte de 4,5 mm (FEBRASGO, morfológico) só de 20+0 a 24+6, junto com a razão PFN/ON. Prega nucal: campo só de 16 a 24 sem (já era assim). |
| Valor × corte exibidos (R14.35) | `casasPar`/`fxVal`/`fxCorte`: quando valor e corte arredondados a 2 casas pareceriam iguais com brutos diferentes, ambos ganham casas (até 5). Vale para MoM da PSV (cortes 1,3 e 1,5), CPR (p5, 1,0 e 1,3), faixa p5/p50/p95 dos vasos e IP médio das uterinas (3 casas da média de dois lados). Classificação inalterada. Operador da PSV: o app usa ≥ 1,5 e a fonte escreve > 1,5 — sem efeito prático (o MoM nunca é exatamente 1,5); mantido. |
| Colo na conclusão (R14.35) | `achadosTxt()`: colo curto e comprimento cervical reduzido aparecem como "achado materno", separados dos achados morfológicos fetais; o título da síntese vira "Peso adequado, achado materno" quando é o único achado. |
| Via das uterinas (R14.36) | Decisão do médico (10/10/2026): cada exame novo começa com **transabdominal pré-selecionada** (`VIA_UT='ta'`, `VIA_UT_PADRAO=true`), em vez de via vazia. No 1º trimestre (IG < 14 sem; sem IG, contexto de 1º tri) aparece aviso para confirmar a via, que some no primeiro toque em qualquer via. Não bloqueia o cálculo: `utRefCompativel()` continua decidindo — Gómez < 15 sem só aceita transvaginal, então Gómez + transabdominal no 1º tri não classifica e o aviso indica Cavoretto. O laudo cita a via. Exame recuperado sem o campo `VIA_UT_PADRAO` = via escolhida; via `null` recuperada continua `null`. |
| Barrinha por lado das uterinas (R14.36) | Pedido do médico (10/10/2026): sob cada artéria uterina (cartão do 1º e do 2º/3º trimestre) uma barrinha de percentil **só de consulta**, colorida e ao vivo, pela **mesma curva, via e IG do IP médio** (`utLadoBar()`; mesma regra de `utRefCompativel()`; cor e rótulo pelo p95 como `rotUt`). Some sem via ou com curva incompatível. Não escreve em `ST`, não entra em laudo, síntese, checklist nem classificação — quem classifica continua sendo só o IP médio (decisão C0-B2). Um lado vermelho com IP médio normal é esperado (o lado sem placenta costuma ser mais alto). |
| Incisura (R14.36) | Decisão do médico (10/10/2026): um **quadradinho "Incisura" por lado**, marcado só quando presente. Estado por lado (`incSt`): marcado = presente; desmarcado com o IP **daquele lado** medido = ausente (a onda foi vista para medir o IP); desmarcado sem IP = não avaliada. O select oculto `incD`/`incE` guarda só `pres`/`na`; um `aus` de exame antigo cai na mesma regra. Substitui os três botões por lado e o "Ambas ausentes" da R14.12. O laudo continua citando **só a presença** — nenhuma frase de laudo nasce da ausência deduzida. Limite aceito: com IP medido não dá para marcar "não avaliada" de propósito; nesse caso a tela diz "Sem incisura" e o laudo fica em silêncio. |
| Ergonomia (R14.37) | Aprovada pelo médico em 10/10/2026 sobre prints de antes/depois. Medidas começa pela biometria (síntese, sequência e guia no fim da aba); abas fixas no rodapé, somem enquanto se digita (`body.dig`); avisos do "Confira antes de laudar" mostram a 1ª frase e o resto abre em "por quê" (`chkParte`: nunca corta dentro de negrito/itálico nem em abreviação; resto < 50 letras fica inteiro; o de Hadlock tem resumo próprio); barra fixa **Copiar laudo · Copiar conclusão** só na aba Laudo (`textoConclusao` = trecho do laudo a partir de "CONCLUSÃO"); legenda única nas uterinas. **Botões e fontes NÃO mudam** (o médico recusou essa parte). |
| Simetria e campo parado (R14.37) | Pedido do médico: app simétrico e o campo em edição nunca empurrado por aviso. Pílula colada à direita no cabeçalho dos cards; "· opcional" junto do título; unidade centrada no campo (o rótulo de IG saiu de dentro de `.unit`); Fíbula na grade dos ossos; diástole umbilical em linha própria (barras da umbilical e da cerebral alinhadas). Âncora: na captura do `input`/`change` guarda a posição do campo; depois de todos os listeners, rola a mesma diferença (`ancFixa`). Limite: no fim da página, se o conteúdo abaixo encolher, o navegador recorta a rolagem (até ~13 px). |
| Correções da bateria (R14.38) | Bateria de 10/10/2026 (diferencial R14.36×R14.37×R14.38 em 550+ exames aleatórios, larguras 320–430, clique em tudo, recuperação, cópia real, offline). Corrigido com liberação do médico: "Próximo pendente" (vive dentro do Laudo) e aviso rápido acima das barras do rodapé; "por quê" abre com Enter/espaço; em telas < 360 px as etiquetas do cabeçalho do card descem para a 2ª linha, a tabela rápida quebra o valor e os pares de campos ficam nivelados (`nivelaDuo`: quando um rótulo quebra em 2 linhas, o vizinho ganha a mesma altura). |
| Tamanho do bebê (R14.39) | Autorizado pelo médico (10/10/2026), **fonte fora da hierarquia** (FEBRASGO/ISUOG/Rumack/CBR não trazem fórmula): Vintzileos AM et al., *Obstet Gynecol* 1984;64:779-82 — comprimento (cm) = 6,18 + 0,59 × fêmur (mm), conferido no PubMed (PMID 6390277); erro ~±6% (Milner 1994). Só para informar a paciente: linha "Para a paciente" sob o peso, na aba Medidas, número redondo + faixa ±6%; só com fêmur 3,0–9,0 cm e aceito pela plausibilidade; nunca no laudo, na conclusão ou na cópia (regra R14.8). O Modo Paciente (que já mostrava "Comprimento" desde a R14.5) passou a seguir a mesma faixa do fêmur. |
| Próximo pendente (R14.39) | Estava dentro de `#p3` e só aparecia no Laudo; agora vive no `body` e aparece em todas as abas, acima das barras do rodapé. As regras de posição de `.prox`/`.toast` levam `body` na frente (na R14.38 perdiam para as originais fora da aba Laudo). |
| Limpeza do pente fino (R14.40) | Pente fino de 10/10/2026 (lint de JS, cascata de CSS, referências de IDs, diferencial R14.35×R14.39 em 300 exames — só a incisura difere, como decidido). Aplicado com liberação: regra de quebra da tabela rápida passa a valer (`body .qr .v`); removida regra de `summary` sem efeito; `Z_P10`/`Z_P90` declarados uma só vez; transição das caixas de marcação (`.chk-l`) restaurada; removido o CSS dos antigos botões de incisura (`.incRow`, `.incL`, `.incSeg`, `.incAmb`). Restam, de propósito: `z!==z` (teste de NaN) e `var li`/`var det` redeclarados em ramos diferentes. |

---

## 3. Armadilhas — parece bug, não é

- **Discordância bruta 24,999999999999996 no caso 2000,20 / 1500,15 g:** representação binária; a decisão por categoria está correta (346.417/346.417). Um teste que exija `ST.disc.v ≥ 25` no bruto falha por contrato, não por defeito.
- **44 "falhas" residuais da bateria numérica de pesos:** todas no recorte de 6 casas de grama, a até **≈ 47,4 ng** do corte (Hadlock, 39+0, p97, 4304,237291 g). É a neutralização nominal preexistente, não erro de Φ.
- **CPR:** o corte p5 é irracional (equação de Ciobanu). Uma razão de dois IPs digitados nunca é exatamente igual a ele (menor distância 7,3e-8 em 13,1 milhões de pares).
- **Worker 8/10 no Playwright 1.56 com `set_offline`:** artefato da simulação de offline do driver. Com transporte realmente interrompido o worker passa 10/10.
- **WebKit no Linux não é Safari/iPhone.** Resultado de WebKit não substitui teste no aparelho.
- **Teste falhando com o app certo:** já aconteceu muitas vezes (expectativa desatualizada, texto de interface que mudou, cenário sem CA). Ver §5.

---

## 4. Bugs corrigidos que não podem voltar (linha R14)

Cobertos pela `suite_regressao_doppler.py` (grupos 2–18; 63.832 checagens na R14.40) ou pelos pacotes de teste das entregas.

- **Igualdade decimal virando "abaixo/acima" do corte** (CA p3/p10/p90/p97, ossos p3, DIO p10/p90, gemelar CA, TN p5/p95, razões CF/CA e CF/DBP, uterinas, PFN/ON, CT/CA, diferença saco–CCN). Ex.: 24+0 com CA 17,33 cm fechava "RCF por CA < p3". R14.24–R14.26.
- **F01** PFE inválido do outro feto chegava a discordância/sFGR. **F02** `phi()` aproximado trocava o lado do corte (até 2,1e-5 pontos percentuais). **F03** IG ausente tratada como "tardia". **F04** `var outroId` só no ramo biométrico → escopo errado da AU do outro feto. **F05** discordância exibida cruzando o corte (19,996% como "20,00%"). R14.27–R14.28.
- **Rótulo de percentil contradizendo a classe** (R14.31 e anteriores): "p10 · PIG" com q = 9,996; no laudo, "(p10) — pequeno" já com q = 9,5, porque lá o arredondamento era inteiro. Ocorria em cerca de 2% dos exames, em peso, CA, Doppler, uterinas, cerebelo e ossos. R14.32.
- **Padrão sistêmico "não avaliado ≠ normal"** — princípio geral do app; qualquer campo nunca tocado deve permanecer "não avaliado" no estado, no cartão e no laudo.

---

## 5. Pendências abertas

**5.1 Suíte de 17/09 (legado — renomeie o arquivo antigo `suite regressao doppler.py` para `suite_legado_2026-09-17.py`; não use como critério de aprovação):** na R14.28 passa **47/62**. Classificação das 15 falhas (Claude, 02/10/2026):

| Falha | Classificação |
|---|---|
| UTD "pelve 0,5 isolada = A1 incompleto" → teste lê `ST.estr.pel` | **Resolvida (05/10/2026): não é regressão.** `ST.estr.pel` é só a faixa bruta da pelve; a classificação formal (`ST.utd`) fica `incompleto` e lista o que falta até cálices, parênquima, ureter, bexiga e oligoâmnio serem avaliados. Tela e laudo dizem "Avaliação UTD incompleta". |
| Órbitas: "biocular alto registrado no laudo" | **Conferido (06/10/2026):** biocular acima do p90 entra no laudo (Sukonpan 2008); o teste antigo procurava outro texto. |
| UTD "pelve normal + ureter dilatado = A2-3" e "laudo registra A2-3" | Mudança documentada: Nguyen 2021 (REFERENCIAS A.5). |
| UTD "[neg] pelve normal = ok" | Teste incompatível: o estado na R14 se chama `normal`. |
| TN "FMF p95 em CCN 84 = 2,8 mm" (app: 3,116) | Mudança documentada: carta FMF 1998 (equação log10, MoM 1,57). |
| 5 casos de "falsos negativos" (PFE p8 + uterinas/AEDF; PFE p50 + AEDF; uterinas na tardia) | **Conferido (06/10/2026):** os cinco cenários foram reproduzidos e todos seguem o Delphi; não é regressão. |
| Gemelar "sem corionicidade não conta" | Mudança documentada no próprio app: critério solitário vale em qualquer corionicidade (Khalil 2019). |
| Gemelar "MC exige 2 de 4" / "DC exige 2 de 3" | Teste procura texto que mudou no cartão; a lógica é coberta pelas matrizes gemelares da auditoria (235.224 casos). |
| 1 grupo aborta (elemento de interface inexistente) | Incompatibilidade do teste com a interface da R14. |

**5.2 Científicas (06/10/2026):** o estado módulo a módulo está no `01_ESTADO_CIENTIFICO_R14_35.md` do dossiê científico R14.35. Ciobanu equações × tabela: fechado. Hadlock 1985 e INTERGROWTH 2020: conferidos no original. Átrio, colo, PSV e aviso de Hadlock: resolvidos na R14.33. Faltam só documentos: carta DeVore 2021 e réplica, corpo de Mari 1995, Hadlock 1992 (CCN), Table S2 do INTERGROWTH, corpo de Roberts 2025 e Adu-Bredu 2026.

**5.3 Validação:** iPhone/Safari físico, atualização e uso offline no aparelho, validação clínica formal.

**5.4 Herdadas do CONTEXTO de 17/09 — auditadas em 06/10/2026** (relatório `05_AUDITORIA_FILA_HERDADA_R14_35.md` do dossiê científico; pente fino geral em `06_PENTE_FINO_R14_35.md`). Erros E1 e E2 corrigidos na R14.34; E3 (prega nucal) não era erro. Fica em aberto só o **D3**: zoom bloqueado na meta viewport (sem efeito no iPhone; só alterar com teste no aparelho). A frase da FEBRASGO sobre o desempenho do ILA no polidrâmnio segue citada como "nº 43 (2025)" até confirmar de qual documento vem.

---

## 6. Escopo e preferências do autor

- Este HTML é o aplicativo **em produção**, independente do projeto Flutter/Codex — não herda governança de lá, nem o inverso. Auditorias vindas de lá podem descrever outro código.
- Português brasileiro; análise crítica (contraponto antes de concordar; se o autor estiver errado, dizer diretamente); nunca aplicar alteração sem liberação; respostas curtas (uso no celular); modo de teste silencioso; perguntar o escopo antes de "revisar tudo" — validação de fonte e de dado clínico é sempre completa.

---

## 7. O que mudou em relação ao CONTEXTO de 17/09 (para não reabrir por engano)

| Antes (17/09) | Agora (R14.28) |
|---|---|
| AU por Acharya 2005; ACM por Arduini & Rizzo | AU, ACM e CPR por Ciobanu 2019 (FMF) |
| Percentil de peso por motor híbrido, `DP_HADLOCK = 0,1329` | Hadlock 1991 ln(EFW), `HADLOCK_SD_LN = 0,12`, Φ preciso |
| Órbitas por Jeanty (desvio fixo) | Sukonpan & Phupong 2008 |
| Líquido FEBRASGO nº 82 | FEBRASGO nº 43 (2025) + SMFM #46 |
| UTD Nguyen 2014 com estado `a1-inc` | Nguyen 2021; completude exigida em `ST.utd` (estado `incompleto`) |
| Hierarquia FEBRASGO → ISUOG → Rumack → CBR/SBR | FEBRASGO → CBR → ISUOG |
| Suíte de 62 casos | `suite_regressao_doppler.py` da linha R14 + pacotes de teste por versão |

Histórico R14 recente (SHA-256 do HTML): R14.24 `fd6b301d…` · R14.25 `0d7b9c8f…` · R14.26 `e2775edb…` · R14.27 `bd54755a…` · R14.28 `3e9aee8b…` · R14.29 `c54a1b0a…` (data do exame no topo) · R14.30 `2a6c0173…` (datas dd/mm/aaaa) · R14.31 `c1369b9a…` (data digitada em dia/mês/ano) · R14.32 `f93989ff…` (rótulo de percentil; "falta/faltam" no UTD) · R14.33 `bef7664b…` (átrio, colo, PSV, aviso de Hadlock e referências) · R14.34 `4152a234…` (janelas de IG do osso nasal e da tricúspide; citações FEBRASGO) · R14.35 `47b3d14c…` (valor × corte exibidos; colo como achado materno) · R14.36 `ab7a5936…` (via das uterinas transabdominal por padrão; aviso no 1º tri; barrinha de consulta por lado; incisura por quadradinho) · R14.37 `55e4f80e…` (ergonomia: biometria primeiro, abas no rodapé, avisos dobrados, barra de cópia; simetria; campo parado) · R14.38 `de9cafcd…` (correções da bateria: flutuantes acima do rodapé, teclado, telas de 320 px) · R14.39 `1a92da24…` (tamanho do bebê para a paciente; Próximo pendente em todas as abas) · R14.40 `d5a99310…` (limpeza do pente fino, sem efeito clínico).


---

<!-- ARQUIVO: 04_REFERENCIAS_BASE_R14_28.md -->

# REFERÊNCIAS — cadeia de proveniência das tabelas e regras do motor

Calculadora Doppler Obstétrico · baseline de saída **R14 (corrigida; schema 13 no handoff)** · versão vigente **R14.28** (SCHEMA_VERSION=14)
Última auditoria: 2026-09-26 (C3b.2a + R14 inicial + correções pós-revisão externa); 2026-09-30 (integração R14.25: comparação numérica estável e reconciliação documental; R14.26: PFN/ON, CT/CA, saco–CCN e revisão estática dos comparadores derivados); 2026-10-01 (R14.28: exibição da discordância e correções documentais); 2026-10-01 (R14.27: auditoria profunda PIG/GIG/RCF gemelar — gate de PFE do outro feto, Φ preciso no peso, IG ausente com AEDF/REDF, escopo do outro feto e discordância).
Cumulativo: mantém o detalhamento de C3b.2a (órbitas, DV1, FCF, TN, UTD) e adiciona as 10 adjudicações da R14. Nenhum PDF de editora está neste repositório — PDFs licenciados ficam em armazenamento privado do responsável, fora da pasta de deploy (o Vercel serve publicamente tudo que está na pasta de deploy).

Níveis de evidência: PRIMARY_FULLTEXT · PRIMARY_TABLE · PRIMARY_FIGURE · PRIMARY_ABSTRACT · GUIDELINE_CONSENSUS · AUTHORIAL_REPRODUCTION · SECONDARY_REPRODUCTION · SECONDARY_REVIEW · EQUIPMENT_REPRODUCTION · APP_POLICY (decisão do app, não dos autores) · APP_HEURISTIC (heurística interna, sem validação publicada) · UNKNOWN_ORIGIN.

---
---

# PARTE A — Módulos já auditados no C3b.2a (base congelada, não reaberta na R14)

## A.1 Órbitas — distância interocular (DIO) e binocular (DBO)

- **Referência:** Sukonpan K, Phupong V. Fetal ocular distance in normal pregnancies. *J Med Assoc Thai* 2008;91(9):1318-1322. PMID 18843858.
- **Local:** Tabela 1 (interocular) e Tabela 2 (binocular).
- **Como foi conferido:** imagem das duas tabelas extraída do PDF publicado (servidor de figuras da Semantic Scholar). 156/156 células de p10/p50/p90 idênticas ao motor; soma dos n = 595, igual ao artigo.
- **Domínio:** 15–40 semanas; linha da semana **completa**, sem interpolar (APP_POLICY_COMPLETED_WEEK).
- **Estatística:** p10/p50/p90 empíricos por semana. A fonte **não** publica p5/p95: fora de p10–p90 é alerta amarelo, não diagnóstico.
- **Status:** CONFIRMADO — PRIMARY_TABLE.
- **Fonte anterior descartada:** tabela "Jeanty 1982" da Fetalmed, identificada como reconstrução com bandas fixas ±5,0/±3,0 mm — não é transcrição do artigo original.

## A.2 Ducto venoso — PIV no 1º trimestre

- **Referência:** Pruksanusak N, Kor-anantakul O, Suntharasaj T, Suwanrath C, Hanprasertpong T, Pranpanus S, Geater A. A reference for ductus venosus blood flow at 11–13+6 weeks of gestation. *Gynecol Obstet Invest* 2014;78(1):22-25. DOI 10.1159/000362273.
- **Local:** p. 24, Tabela 2 ("Values of S/a, PIV, PLI, and PVIV with CRL 45.9–75.5 mm"), lida no texto integral.
- **Valores no motor:** PIV p5 **0,69** (IC95% 0,64–0,73) · p50 **0,92** (0,90–0,94) · p95 **1,13** (1,08–1,19).
- **Domínio:** CCN **45,9–75,5 mm** (faixa observada). Fora disso: IP registrado, sem classificação. Sem percentil intermediário.
- **Não usar:** Sachin et al. 2025 (IJCPR 17(3), Tab. 7) atribui 0,64/0,84/1,01 ao PIV — é a linha do **PVIV**.
- **Status:** CONFIRMADO — PRIMARY_TABLE.
- **Comportamento congelado (verificado por regressão, 200 cenários, 0 divergências em toda a R14):** onda A interpretada à parte do PIV; onda A positiva + IP acima do p95 → cartão amarelo com "IP acima do p95" (não "Normal"); IP abaixo do p5 → neutro; sem IP → "Normal".

## A.3 Frequência cardíaca fetal (FCF)

- **Prognóstico precoce (6+0–7+0):** Doubilet PM, Benson CB. *J Ultrasound Med* 1995;14:431-434 — limite inferior 100/120 bpm — e faixa "poor" do resumo autoral de Doubilet (<90/<110).
- **FC rápida (6+0–7+0):** Doubilet, Benson & Chow. *AJR* 2000;175:67-69 — ≥135/≥155 bpm, bom prognóstico isolado.
- **Mapeamento de tempo:** `DOUBILET_TIME_MAPPING`: 6+0/6+1 = 1º grupo; 6+3–7+0 = 2º grupo; **6+2 = zona indeterminada** — APP_POLICY.
- **Fisiologia 6+0–9+6:** Silva & Bailão, *RBGO* 2000;22(9), Tab. 2 — colunas −2DP/M/+2DP **publicadas**, por meia semana. Alocação dos dias nas meias semanas não definida no artigo — o app testa as duas alocações plausíveis (APP_POLICY) e só classifica quando concordam.
- **Fisiologia 10+0–13+6:** Pettersen & Faria, *RBGO* 2001;23:567 — p5/p50/p95 por semana completa (1.078 fetos).
- **14+0–19+6:** sem referência ultrassonográfica pontual validada — descritivo.
- **≥20+0:** 110–160 bpm como alerta, faixa basal de CTG (FIGO 2015; Pildner von Steinburg 2013).
- **Status:** CONFIRMADO (todas as camadas, PRIMARY_TABLE/PRIMARY_ABSTRACT conforme o trecho).

## A.4 Translucência nucal (TN)

- **Curva FMF:** Nicolaides KH, Snijders RJM, Cuckle HS, carta *Prenatal Diagnosis* 1998. Equação log10 TN = −0,3599+0,0127·CCN−0,000058·CCN²; MoM 0,62/1,57; CCN 45–84. 40 CCNs recalculados em Python fora do app, idênticos ao motor.
- **Curva Faria:** Pettersen & Faria, *RBUS* 2010 — reprodução autoral da tabela de Faria 2004. 119/119 células conferidas. Só <p5/p5–p95/>p95, sem zona limítrofe reconstruída.
- **Status:** CONFIRMADO (PRIMARY para a carta FMF; AUTHORIAL_REPRODUCTION para Faria).

## A.5 Dilatação do trato urinário (UTD)

- **Referência:** Nguyen HT et al. 2021 update on the urinary tract dilation (UTD) classification system. *Pediatr Radiol* 2022;52:740-751. DOI 10.1007/s00247-021-05263-w. Correção 2023;53:1217 (só o APRPD do P3 = 15mm).
- **Local:** Fig. 1, lida diretamente. Antenatal A2-3: cálices "*Any Dilation*"; ureter/parênquima/bexiga/oligoâmnio só contam "*with APRPD ≥4mm or calyceal dilation*". "Central/Peripheral Dilation" só no pós-natal.
- **Status:** Fig. 1 CONFIRMADA — PRIMARY_FIGURE. Texto integral (para o trecho sobre cálice central) permanece pendente de acesso institucional — não bloqueia a regra vigente, apoiada na figura.

## A.6 Outros módulos citados no motor, não reauditados neste ciclo

Ciobanu et al. 2019 (CPR/FMF), INTERGROWTH-21st (CA/PFE), Hadlock PFE (4/3 parâmetros), Hadlock 1991 (percentil de peso), Vintzileos 1984 (comprimento fetal, auxiliar), RPOC descritivo, placenta descritiva, DMSG +30 informativo — mantidos como estavam, sem alteração nesta rodada.

---
---

# PARTE B — As 10 adjudicações da R14 (com as correções da revisão externa)

## B.1 CC/CA — Campbell & Thoms 1977

- **Referência:** Campbell S, Thoms A. Ultrasound measurement of the fetal head to abdomen circumference ratio in the assessment of growth retardation. *Br J Obstet Gynaecol* 1977;84(3):165-174. DOI 10.1111/j.1471-0528.1977.tb12550.x · PMID 843490.
- **Nível:** PRIMARY_ABSTRACT (resumo) + SECONDARY_REPRODUCTION (tabela, vista em Joshi BR, *J Inst Med Nepal* 2017, Tab. 2 — rótulos de coluna invertidos nessa reprodução; o artigo original está em paywall).
- **Dado original:** n=568 gestações normais, 17–41 semanas. O próprio resumo mistura "95 per cent confidence limits" e "95th centile limit" para os mesmos limites — construção estatística **indeterminada**. Em 31 fetos pequenos para a idade, 22 (71%) ficaram acima do limite do percentil 95.
- **Domínio:** 17–41 semanas, em blocos de 2 semanas (17-18, 19-20, ..., 39-40; 41 isolada) — sem evidência de regressão contínua que sustente interpolação fracionária.
- **Decisão:** REBAIXADO PARA DESCRITIVO. `T_CCAC[Math.floor(g)]` lida por bloco real (pares 17-18/19-20/.../39-40; 41 isolada — corrigido na revisão: o rótulo do bloco antes usava `[floor(g), floor(g)+1]`, que ficava errado nas semanas pares; agora usa a lógica de pares corretos). Exibida como "referência de Campbell 1977 (bloco X–Y sem)", sem cor de normal/anormal, fora da lista "fora da faixa"/critério de RCF.
- **Status:** PARCIALMENTE CONFIRMADO (valores) / INDETERMINADO (estatística e legitimidade de interpolação fracionária).
- **Documentação sincronizada (correção pós-revisão):** o comentário de código de `T_CCAC` e a linha do overlay de Referências foram reescritos para não afirmarem mais "o artigo publica média com IC95%; os rótulos p5/p95 são aproximação" — agora registram a indeterminação estatística real e que a tabela vem de reprodução secundária, não do artigo original.

## B.2 CF/CC — Hadlock et al. 1984

- **Referência:** Hadlock FP, Harrist RB, Shah Y, Park SK. The femur length/head circumference relation in obstetric sonography. *J Ultrasound Med* 1984;3(10):439-442. DOI 10.7863/jum.1984.3.10.439 · PMID 6387166.
- **Nível:** PRIMARY_ABSTRACT (amostra e domínio); a tabela semanal de limites só foi localizada em manuais de equipamento (GE Voluson/LOGIQ) — EQUIPMENT_REPRODUCTION, nunca confirmada no artigo original nem em reprodução autorizada.
- **Dado original:** n=361 fetos normais, 15–42 semanas.
- **Decisão:** REMOVIDO o classificador. A faixa fixa "13,30–23,90% em toda a janela" do baseline anterior era, na prática, o menor limite inferior e o maior limite superior de linhas semanais diferentes de uma tabela nunca verificada — não uma faixa única legítima.
- **Status:** UNKNOWN_ORIGIN / APP_LEGACY para o classificador. CF/CC agora é só numérico, sem normal/anormal.
- **Não migrado para OMS/Kiserud:** a tabela corrigida (Kiserud et al., *PLOS Med* 2017, com duas erratas em 2017 e 2021) não foi extraída e conferida célula a célula nesta rodada — migrar sem essa conferência violaria a mesma regra que está sendo aplicada aqui. Pendente para ciclo futuro.

## B.3 CF/DBP — Hohler & Quetel 1981

- **Referência:** Hohler CW, Quetel TA. Comparison of ultrasound femur length and biparietal diameter in late pregnancy. *Am J Obstet Gynecol* 1981;141(7):759-762. DOI 10.1016/0002-9378(81)90700-6 · PMID 7315902.
- **Nível:** PRIMARY_ABSTRACT.
- **Dado original:** "linear relationship... after 22 weeks' gestation"; FL/BPD = 79 ± 8% (71–87%).
- **Estatística:** o resumo **não define** o que ±8 representa. O rótulo "90% CI" é de manuais de equipamento — **REFUTADO** como citação do autor.
- **Decisão:** MANTIDO 71–87% como **faixa publicada** (nunca "normal" — correção pós-revisão, ver B.9), com gate real em **≥23+0 semanas** (APP_POLICY). Abaixo do gate, o valor é só descritivo.
- **Status:** PARCIALMENTE CONFIRMADO (79±8% = 71-87%) / REFUTADO (rótulo "90% CI").

## B.4 CF/CA — Hadlock et al. 1983

- **Referência:** Hadlock FP, Deter RL, Harrist RB, Park SK. A date-independent predictor of intrauterine growth retardation: femur length/abdominal circumference ratio. *AJR* 1983;141(5):979-984. PMID 6605074.
- **Nível:** PRIMARY_ABSTRACT + fragmentos de PRIMARY_FULLTEXT.
- **Dado original:** n=361, 15–42 semanas; após 21 semanas a razão independe da idade gestacional; normal (mean ± 2SD) 22±2% = 20–24%; corte de rastreio 23,5% = **p90**, sensibilidade de 63% para RCIU (30 casos).
- **Decisão:** MANTIDO 20–24% como **faixa normal** (Hadlock publica explicitamente como "normal range" — por isso, diferente de CF/DBP, esta é a única das três razões onde a palavra "normal" é usada na UI). Gate real em **≥22+0 semanas** (APP_POLICY). Frase causal "típico de insuficiência placentária" REMOVIDA, substituída por linguagem descritiva citando a sensibilidade de 63%.
- **Status:** CONFIRMADO (amostra, domínio, 20–24%, corte de 23,5%=p90, sensibilidade 63%).

## B.5 Razão úmero/fêmur (U/F) 0,90–1,10

- **Busca dedicada:** Krakow D et al. Guidelines for the prenatal diagnosis of fetal skeletal dysplasias. *Genet Med* 2009;11(2):127-133. PMCID PMC2832320. SMFM/AJOG 2018. FEBRASGO nº 43 (2025).
- **Achado:** nenhuma fonte valida a razão U/F 0,90–1,10 nem "úmero curto"/"fêmur curto"/"rizomélico". O que está validado é o percentil/escore z **individual** de cada osso — e as duas sociedades usam limiares **diferentes entre si**: Krakow 2009 (avaliação especializada com medida ≤p5 ou >3 DP abaixo da média) e SMFM 2018 (<p5 ou >2 DP abaixo da média para "curto").
- **Decisão:** REMOVIDO. U/F é só valor numérico. **Correção pós-revisão:** o texto anterior citava incorretamente "abaixo do p3" (não corresponde a nenhuma das duas fontes, que usam p5, com DP diferente entre si) — reescrito para não misturar p3/p5/−2DP/−3DP numa única regra; cada sociedade citada separadamente, com o limiar que lhe pertence.
- **Status:** UNKNOWN_ORIGIN / APP_LEGACY.
- **Fora do escopo (deliberadamente não adicionado):** CF/pé, CF/CA<0,16, CT/CA, índices de letalidade.

## B.6 igBio() e heurísticas de divergência biométrica

- **Busca dedicada:** nenhuma fonte publicada valida a ponderação cerebelo×3/DBP×2/CC×2/FL×2, nem os cortes de 1/1,5/2/3 semanas usados para classificar a comparação.
- **Decisão original da R14:** removidos a classificação "compatível/aceitável/discordância importante" em `peso()`, o alerta agregado em `coer()` para ≥3 semanas, a cor clínica das IGs individuais em ≥1/≥2 semanas, e o alerta de dispersão ≥1,5 semana.
- **BLOQUEADOR encontrado na revisão externa e corrigido nesta rodada:** mesmo com a cor e o texto "compatível/discordância" neutralizados, o bloco `if(ad>=1){...}` dentro de `peso()` (ramo `!datando`, ou seja, quando a IG já está estabelecida e a biometria só é comparada) continuava usando `ad=|gbComp−g|` para **acionar decisões clínicas reais** no cartão `igbRes`: "Isto é crescimento, não data", "a discordância é alteração do crescimento", "mudar a data aqui apagaria a restrição", comparação com `limiarRedata()` sugerindo ou não redatação, e a recomendação "meça o cerebelo". Isso violava o próprio critério da R14 (zero decisão clínica automática sem proveniência) porque a heurística não validada continuava decidindo.
- **Correção:** neste ramo (`!datando`), o cartão `igbRes` agora é **sempre oculto** (`hide(eb)`), incondicionalmente — `gbComp` nunca mais aciona `limiarRedata()`, nunca mais declara crescimento alterado, nunca mais sugere (ou nega) redatação, nunca mais recomenda medir o cerebelo. `gbComp` continua calculado e exibido só como diferença numérica neutra no cartão `igRes` (texto acima do `igbRes`).
- **Preservado, sem alteração:** o cartão `igbRes` no ramo `datando===true` (quando a IG está sendo estabelecida por HC+FL/`igBioHCFL()`, validado, ISUOG grau B) — ali `gb=gbDat`, não `gbComp`, e o aviso de "gestação subotimamente datada" (ACOG, quando `gb>=22`) permanece intacto, porque não deriva da heurística não validada.
- **`limiarRedata()` e o fluxo de redatação por DUM/US/CCN:** continuam existindo, mas **não recebem mais `gbComp` como gatilho** em nenhum caminho — o gatilho de `ad>=1` que os acionava só existia dentro do bloco removido. Este mecanismo (por dias, ISUOG/ACOG) segue como um sistema válido e à parte, mas **a formulação anterior de que ele era "separado" da heurística não validada estava incompleta** enquanto seu gatilho ainda era `gbComp` — isso foi corrigido removendo o gatilho, não apenas reformulando o texto.
- **Também preservados:** as IGs equivalentes individuais por parâmetro (exibidas de forma descritiva, sem corte clínico) e o texto do laudo "Idade equivalente por parâmetro" (puramente informativo).
- **Status:** APP_HEURISTIC / NÃO VALIDADA — agora sem nenhuma via de acionar decisão clínica.

## B.7 Oligoâmnio — diagnóstico e gravidade por MBV

- **Diagnóstico (corrigido na R14.21):** FEBRASGO, Protocolo nº 43 (2025), *Ultrassonografia obstétrica do terceiro trimestre da gestação* (Femina 2025;53(6):831-5), Tabela 1: oligoâmnio **MBV <2,0 cm** ou **ILA <5 cm** (normal: MBV ≥2 e <8; ILA ≥5 e <24). *Correção:* até a R14.20 este item dizia "MBV ≤2,0 cm" e atribuía o corte ao nº 43 — a Tabela 1 diz "<2".
- **Graduação removida:** "<1 acentuado / 1–2 moderado" sem sustentação em diretriz contemporânea. Chamberlain PF et al. *Am J Obstet Gynecol* 1984;150(3):245-249 usa "decreased"(<1cm)/"marginal"(1-2cm), não "acentuado"/"moderado". FEBRASGO nº 82 (2018, mais antiga) chama de "severo" o MBV ≤1cm — fronteira diferente do baseline antigo (<1).
- **Decisão:** diagnóstico binário mantido; grau automático REMOVIDO.
- **Status:** diagnóstico CONFIRMADO contra a Tabela 1 do nº 43 (R14.21); graduação histórica REMOVIDA por não ser padrão contemporâneo.

## B.8 Polidrâmnio — diagnóstico e gravidade

- **Diagnóstico (corrigido na R14.21):** FEBRASGO nº 43 (2025), Tabela 1: **MBV ≥8,0 cm** ou **ILA ≥24 cm**. A SMFM Consult Series #46 (*AJOG* 2018;219(4):B2–B8, DOI 10.1016/j.ajog.2018.07.016) define do mesmo modo (DVP ≥8 cm ou AFI ≥24 cm): **não há divergência** em 8,00 cm. *Correção:* até a R14.20 o app usava MBV >8 e ILA >25, atribuídos por engano ao nº 43 (que também foi citado com o título errado, "morfológica no segundo trimestre"); a "divergência documentada com a SMFM" registrada aqui deixou de existir.
- **Graduação (R14.22):** SMFM Consult #46, Tabela 2 — MBV 8–11 leve · 12–15 moderado · ≥16 grave; ILA 24,0–29,9 leve · 30,0–34,9 moderado · ≥35 grave (limites inferiores inclusivos: 12,00 já é moderado; 16,00 já é grave; 30,0 já é moderado; 35,0 já é grave). **Fonte autorizada explicitamente pelo usuário** por estar fora da ordem FEBRASGO > CBR > ISUOG (hierarquia atual explicitada pelo responsável em 30/09/2026). A FEBRASGO nº 82 (2018) permanece só como referência histórica: sua tabela de gravidade do ILA começa em 25 cm, portanto **não** sustenta ILA 24,0–24,9 como "leve".
- **Status:** diagnóstico CONFIRMADO (Tabela 1 do nº 43); graduação pela SMFM #46 (fonte autorizada).

## B.9 CF/DBP não pode ser chamado de "normal" (correção de renderer)

- **Achado da revisão externa:** o renderer genérico das taxas escrevia "normal" na frente de toda faixa exibida, inclusive CF/DBP — mas Hohler & Quetel 1981 nunca usa essa palavra, e a estatística do ±8% é indeterminada (ver B.3).
- **Correção:** o array de taxas agora carrega um 6º campo com o rótulo que a própria fonte sustenta: "normal" para CF/CA (Hadlock 1983 publica "normal range" explicitamente) e "faixa publicada" para CF/DBP (sem essa palavra na fonte). O renderer usa esse rótulo em vez de escrever "normal" para todas.
- **Status:** implementação corrigida; nenhuma mudança de dado ou de classificação, só de rótulo.

## B.10 Sequência de deterioração Doppler

- **Referências:** ISUOG Practice Guidelines — diagnosis and management of SGA fetus and FGR. *Ultrasound Obstet Gynecol* 2020. DOI 10.1002/uog.22134. FIGO — best practice advice for FGR. *Int J Gynaecol Obstet* 2021. DOI 10.1002/ijgo.13522.
- **Achado:** as duas diretrizes descrevem **dois fenótipos com padrões diferentes**, não uma escada obrigatória. RCF tardia: "alterations in UA Doppler and venous districts are RARE...MCA-PI...the most important Doppler parameters in the surveillance of late FGR" (ISUOG 2020). RCF precoce: progressão "typically precedes a cascade", como tendência, não regra individual.
- **Decisão:** `sequencia()` reescrita. "Onde está na sequência" → "Territórios hemodinâmicos avaliados". Classe/semântica "pulou" REMOVIDA (achado de ACM/CPR alterado com AU normal é o padrão esperado na RCF tardia, não uma etapa saltada). Frases de precedência obrigatória em `dopplerIntegrado()` suavizadas.
- **Limpeza pós-revisão:** CSS morto da classe `.seq-e.pulou`/`.seq-e.pulou .seq-p` removido; comentário de cabeçalho do bloco CSS atualizado (antes dizia só "sequência de deterioração", sem contexto da renomeação).
- **Status:** CONFIRMADO que não há sequência universal obrigatória, com fonte primária (texto integral das duas diretrizes).

## B.11 Ureter fetal — cortes de 4 e 7 mm

- **Corte de 4 mm:** busca dedicada não encontrou fonte primária para diâmetro ureteral fetal >4mm como corte antenatal. UNKNOWN_ORIGIN.
- **Corte de 7 mm:** BAPU. Farrugia MK et al. Consensus statement on the management of primary obstructive megaureter. *J Pediatr Urol* 2014;10(1):26-33. DOI 10.1016/j.jpurol.2013.09.018. Define ureter >7mm como anormal, mas no **manejo pós-natal** — não transportável para rastreio antenatal.
- **Decisão:** classificação numérica automática REMOVIDA para os dois cortes. Medida em mm agora só descritiva. UTD qualitativo (`eUreUTD`) continua sendo a única classificação clínica formal — intocado.
- **Status:** 4mm UNKNOWN_ORIGIN (removido). 7mm PARCIALMENTE CONFIRMADO (pós-natal/pediátrico) — não transportável, também removido do classificador antenatal.

---
---

# PARTE C — APP_POLICY explícitas (resumo)

| Política | O quê | Por quê |
|---|---|---|
| Gate CF/CA ≥22+0 sem | Hadlock 1983 não define o primeiro dia de "after 21 weeks" | Operacionalização conservadora |
| Gate CF/DBP ≥23+0 sem | Hohler 1981 não define o primeiro dia de "after 22 weeks" | Idem |
| Hierarquia geral de referências | FEBRASGO → CBR → ISUOG; demais fontes complementam lacunas, com atribuição explícita | Instrução atual do responsável; preserve adjudicações e exceções autorizadas |
| Zona 6+2 sem indeterminada (FCF) | Notação semana decimal vs semana+dia ambígua nesse ponto | Doubilet não define |
| Alocação dupla de meia-semana (Silva & Bailão) | Artigo não define arredondamento dos dias | Classifica só quando as duas alocações concordam |
| Bloco de Campbell por `Math.floor(g)`, sem interpolar | Tabela é em blocos de 2 semanas, sem regressão contínua publicada | Evita inventar continuidade |

---
---

# PARTE D — Limitações residuais (declaradas)

- PDFs originais de Campbell 1977, Hadlock 1984 (JUM), Hadlock 1983 (texto completo além dos fragmentos), Hohler 1981 (texto completo) e BAPU 2014 (Tabela 1) não foram obtidos — auditoria feita com resumos e fragmentos de busca.
- Tabela corrigida da OMS/Kiserud para CF/CC não extraída e conferida célula a célula — por isso CF/CC permanece descritivo em vez de migrado.
- Protocolo FEBRASGO específico de Doppler/RCF (se existir) não localizado — a posição do item B.10 apoia-se em ISUOG 2020 e FIGO 2021.
- Posição atual do ACOG sobre graduação de oligoâmnio e a diretriz ISUOG 2024 de esqueleto fetal não obtidas nesta rodada.
- Texto integral de Nguyen 2022 (UTD) sobre cálice central antenatal permanece pendente de acesso institucional (não bloqueia a regra vigente, apoiada na Fig. 1).

# PARTE E — Regras removidas ou rebaixadas nesta R14 (resumo para handoff)

| Regra anterior | Origem alegada | Status real | Ação |
|---|---|---|---|
| CC/CA normal/anormal via interpolação fracionária | "Campbell 1977" | Estatística indeterminada; interpolação não sustentada | Descritivo, por bloco |
| CF/CC faixa fixa 13,30–23,90% | "Hadlock 1984" | Tabela nunca vista fora de manual de equipamento | Removido |
| CF/DBP rotulado "normal" e "90% IC" | "Hohler 1981" | Fonte não usa "normal" nem define a estatística do ±8% | Rótulo corrigido, mantida a faixa |
| CF/CA "típico de insuficiência placentária" | "Hadlock 1983" | Linguagem causal não encontrada na fonte | Descritivo, com sensibilidade citada |
| U/F 0,90–1,10, "rizomélico" | Desconhecida | Sem fonte | Removido |
| igBio 1/2/3/1,5 semanas — cores e alertas clínicos | Desconhecida | Sem fonte; **ainda acionava `igbRes`/`limiarRedata()` até esta correção** | Removido, incluindo o gatilho residual |
| Oligo "acentuado"/"moderado" (MBV) | "convenção histórica" | Fronteiras e rótulos não batem com nenhuma fonte atual | Removido, diagnóstico binário mantido |
| Poli "Manning" 8-12/12-16/>16 | Atribuição nunca auditada | Números batem com SMFM #46, não confirmados em Manning | Atribuição e fronteiras corrigidas |
| Sequência Doppler obrigatória, classe "pulou" | Uso interno do app | ISUOG 2020/FIGO 2021 refutam sequência universal | Reescrita para territórios paralelos |
| Ureter >4mm / >7mm | Convenção auxiliar do app | Sem fonte antenatal (4mm); pós-natal/pediátrica (7mm) | Removidos; UTD qualitativo é a única autoridade |

Este arquivo é a base para o próximo handoff científico (Codex ou outro).

---

# PARTE F — Ciclo R14.1 a R14.11 (pós-freeze da R14)

Esta parte é autocontida: pode ser anexada a qualquer versão consolidada deste documento.
Nenhuma curva, tabela, fonte ou limiar das Partes A–E foi alterado neste ciclo. As mudanças
são de **semântica de saída** (o que pode ou não virar achado, conclusão ou laudo), de
**apresentação** e de **persistência**. Cada item abaixo foi verificado no código antes de
ser implementado, e várias alegações de auditorias externas foram refutadas por não
corresponderem ao arquivo vigente (registradas em F.4).

## F.1 Histórico de versões e integridade

| Versão | SHA-256 | Bytes | Conteúdo |
|---|---|---|---|
| R14 (freeze) | `4821d7fb828b5c5e0f987b0fb2f7115a36f230f142bc4b551f3f093109608cf6` | 448.306 | Baseline científica congelada |
| R14.1 | `c71d4e36c63eb4aafbaee0d03c22dfa8bd65349280af9bda61a51b5003f2af12` | 448.976 | Cartão neutro legível no modo escuro; foco no toque |
| R14.2 | `5c26641d194e86c7dfa24f3feef40f7d3d4eae223136a060e810a1ede75a5399` | 450.142 | Pendências clicáveis; foco do "Próximo pendente" |
| R14.3 | `52260c516e8a836fab0c6bee1b87d3eb1c83566319dc3141e86280dd9e8b04c5` | 451.482 | Mapa das abas; painéis ancestrais; confirmação de troca de referência; data/hora na recuperação |
| R14.4 | `52949077cf665d90b1acf29e801ac217e216dda02bbe2345b29f90298707400a` | 452.010 | Cabeçalho rola; faixa IG/peso/pendências fixa |
| R14.5 | `85dd6708a66e1d4ffdd2a250b1ebadf0121e1e6d906e3b05e777ac9f7dea377e` | 449.700 | Bloco de seguimento morto removido; "Positiva"; comprimento fora da tela clínica |
| R14.6 | `a0e7740c782b749afc51cdace8d7e39e00dae74efbe36aee98dba6124f7cc7a8` | 450.713 | Sem cor por diferença de IG (2º local); sem-referência fora dos achados |
| R14.7 | `ea5deb31815abd3105c8d1270b3a5cae4c9d5b5b835d490b0e3a5f4d203a245d` | 449.421 | Lista morta da leitura biométrica removida; U/F fora da interface |
| R14.8 | `d23aebe5c56312e3524dac8cc8f14d07880a948993f786f2254bc1ac66fabcff` | 450.981 | Doppler grave não mascarado por anemia; comprimento fora do laudo |
| R14.9 | `5c915f8fa21446b61d205450e64a7e4669ccb7db09070e379e97b6d6b3131c36` | 455.570 | Modo Paciente ampliado |
| R14.10 | `8a59841de44f88ef7b5d15c9b2e37e290cbea081bd7a9d4fa9864b9e735a3ba9` | 455.634 | Revisão final: concordância, CSS morto, tabela de referências |
| **R14.11 (histórica)** | `d1ba54b7b39ea87aec30eebc89cf453dcd582ae527dc6463f541002accc5bc85` | 457.627 | Exame salvo carimbado com a versão do motor |

`SCHEMA_VERSION` permaneceu **13** em todo o ciclo (ver F.2.7). Regressão ao fim do ciclo:
golden R14 80/80; suíte histórica sem regressão nova; DV1 200/200 cenários sem divergência;
estado clínico + laudo idênticos à versão anterior em 231 cenários a cada passo sem mudança
clínica intencional.

## F.2 Decisões semânticas e de política (valem para qualquer reimplementação)

### F.2.1 SEM_REFERÊNCIA ≠ achado (R14.6)
Medida existente porém não classificável pela referência ativa (ex.: artérias uterinas
medidas sem via informada, ou fora do domínio da curva) **nunca** entra na síntese de
achados ("achados associados") nem aumenta gravidade. Continua contando só para
**cobertura** ("Doppler foi tentado"). Mesmo princípio de "não avaliado ≠ normal", no
sentido inverso: não classificável ≠ alterado.

### F.2.2 Idade equivalente por parâmetro: nenhuma cor em lugar nenhum (R14.6)
A decisão B.6 (idade equivalente é descritiva, sem corte de 1/1,5/2/3 semanas) só tinha sido
aplicada a um dos dois renderizadores. O segundo, que exibe a idade ao lado de cada campo de
biometria, ainda coloria por limiares escalonados pela IG — removido. A seta ↑/↓ é só
direção. **Exceção legítima:** a linha da CA pode ter cor, mas só pelo percentil validado da
CA (INTERGROWTH-21st): abaixo do p3 → grave; abaixo do p10 ou acima do p97 → atenção. A CA
acima do p97 só aparecia colorida "de carona" na heurística removida; foi religada
explicitamente à fonte validada.

### F.2.3 Gravidade não depende da ordem de avaliação (R14.8)
Na síntese de feto com peso adequado, a anemia (PSV-ACM > 1,5 MoM) era avaliada antes de
diástole zero/reversa na umbilical e ducto venoso alterado, com retorno imediato: quando os
dois coexistiam, a conclusão citava só a anemia. Agora o achado hemodinâmico grave é
sempre avaliado primeiro, e a coexistência gera uma classe própria que **nomeia os dois**
na síntese e na conclusão do laudo. Os casos isolados permaneceram idênticos. A escalada
de gravidade máxima (frase "alta gravidade hemodinâmica") nunca foi afetada, porque lê os
achados brutos.

### F.2.4 Regra do laudo (R14.8)
**Nenhuma informação entra automaticamente no laudo se não estiver visível na interface
clínica.** Aplicação: o comprimento fetal estimado (Vintzileos et al. 1984, auxiliar) saiu
da tela clínica na R14.5 e continuava entrando sozinho no laudo — removido do laudo; segue
calculado apenas para o Modo Paciente.

### F.2.5 Modo Paciente (R14.9–R14.10)
Tela de comunicação. Nada dela entra no laudo ou na síntese.
- **Mostra:** tempo de gestação (meses + semanas e dias), FCF em bpm, peso, comprimento,
  "completa o mês em", data provável do parto com contagem regressiva, concepção.
- **Nunca mostra:** percentil, Doppler, líquido amniótico — números que exigem
  interpretação presencial.
- **Precisão:** peso arredondado a 50 g (erro do método ~10–15%), comprimento ao cm inteiro,
  sempre com "cerca de".
- **Concepção:** estimada como DUM + 14 dias (ciclo de 28 dias presumido); o ultrassom não
  determina a data. **Nunca o dia exato.** Início/meados/fim do mês quando a IG vem de CCN
  ou DUM; só o mês nas demais origens (biometria tardia, exame anterior de trimestre
  desconhecido, IG digitada).
- **Gemelares:** peso, comprimento e FCF por bebê (A/B), sempre na ordem A→B. No 1º
  trimestre a FCF não é registrada por feto → linha oculta em gestação gemelar.
- Linha sem dado fica oculta.

### F.2.6 Proteções de uso (R14.3)
- Troca de referência (curva de peso Hadlock↔INTERGROWTH, TN FMF↔Faria, uterinas
  Gómez↔Cavoretto) **pede confirmação somente se já houver resultado** calculado com a
  referência atual.
- Recuperação de exame com mais de 1 h mostra sempre data e hora explícitas — defesa contra
  confundir com o exame da paciente anterior.

### F.2.7 Versão do motor ≠ versão do formato (R14.11)
`SCHEMA_VERSION` protege o **formato** do exame salvo (incompatível → só descartar). Ele não
muda quando só as **regras** mudam — e as regras mudaram várias vezes com o schema em 13.
O exame salvo agora leva o carimbo da versão do app (`motorV`, fonte única `APP_VERSAO`,
que também alimenta o rodapé). Recuperação em versão diferente: aviso explícito ("salvo na
X · app atualizado para Y — resultados recalculados, revise antes de assinar"), recuperação
**permitida**. Campo opcional e retrocompatível: payload v13 sem carimbo = "versão
anterior"; por isso o schema continua 13.

## F.3 Removidos ou alterados na apresentação

| Item | Versão | Motivo | O que continua existindo |
|---|---|---|---|
| Bloco "seguimento sugerido" | R14.5 | Nunca renderizava (DOM/CSS mortos) | Estado interno, usado na frase de alta gravidade do laudo |
| "Positiva (normal)" na onda A do DV 1º tri | R14.5 | Onda A e IP são leituras independentes | "Positiva" |
| Comprimento fetal na tela clínica / no laudo | R14.5 / R14.8 | Não muda decisão; regra F.2.4 | Só no Modo Paciente |
| Lista de idade por parâmetro no cartão de biometria | R14.7 | Nunca ficava visível | Idade ao lado de cada campo; linha do laudo |
| Razão U/F na interface | R14.7 | Sem faixa auditada; só ocupava linha para dizer isso | Percentil/escore z individual de cada osso |

## F.4 Mantido por decisão explícita (não reabrir sem motivo novo)
- **Média ponderada `igBio`** (heurística interna): mantida por decisão do responsável —
  descritiva, rotulada como sem validação, sem cor e sem nenhuma decisão pendurada nela
  desde a R14. Uma auditoria externa recomendou removê-la; a decisão foi mantê-la.
- **Quadro de territórios hemodinâmicos** na aba Medidas: **não** duplica a leitura
  integrada do Doppler (fica em outra aba e responde a outra pergunta). Alegação de
  duplicação refutada duas vezes contra o código.
- **"Normal" no DV do 1º trimestre quando só a onda A foi avaliada (sem IP):** decisão
  explícita da C3b.2a; módulo DV1 congelado.
- Alegações de auditorias externas que não correspondiam ao código vigente (registro para
  não re-litigar): cor por diferença de IG "ainda ativa" no cartão de proporções (já
  removida na R14 — o problema real era o segundo renderizador, F.2.2); sem-referência
  "no radar" após a R14.6 (já corrigido); feedback háptico (inexistente no arquivo).

## F.5 Validação operacional e autoria dos testes

| Teste | Autoria/executor | Ambiente | Resultado e limite |
|---|---|---|---|
| Worker simulado | Auditor independente; execução Claude | Node | 22/22, resultado preservado do pacote recebido |
| Worker em navegador com set_offline | ChatGPT e Claude, resultados separados | Linux; PW1.58/Chromium153: 10/10; PW1.56/Chromium141: 8/10 | A matriz do ChatGPT reproduziu a dependência do driver; log HTTP mostrou rede ainda acessível pelo worker na simulação 1.56 |
| Worker com transporte interrompido | ChatGPT, auditoria técnica anterior | PW1.56/Chromium141.0.7390.0 e PW1.58/Chromium153.0.8010.0, Linux | 10/10 em cada; não equivale a validar iPhone físico |
| Worker com transporte interrompido — **reexecução nesta integração** | Claude | PW1.56.0/Chromium 141.0.7390.37, Linux; HTML R14.25 + `sw.js` R14.23-SW2 | **10/10** (reproduz o resultado do ChatGPT neste ambiente; explica o 8/10 anterior do Claude, causado pela simulação `set_offline` do driver 1.56) |
| Worker WebKit com transporte interrompido | ChatGPT, auditoria técnica anterior | PW1.58, WebKit headless build 2248, Linux | 10/10; não é Safari/iOS físico |
| Worker com transporte interrompido — **R14.26** | Claude | PW1.56.0/Chromium 141.0.7390.37, Linux; HTML R14.26 + `sw.js` R14.23-SW2 | **10/10** |
| Worker, matriz da auditoria da R14.25 (PW1.56/Chromium 141 e PW1.58/Chromium 153, WebKit headless build 2248, e atualização R14.24→R14.25 com o mesmo worker, 5/5) | ChatGPT, Auditoria_R14_25 | Linux | 10/10 em cada navegador; atualização 5/5. **Relato do auditor: não reexecutado pelo Claude** (exceto a linha PW1.56/Chromium 141 acima, na R14.26) | 
| Worker com transporte interrompido — **R14.27** | Claude | PW1.56.0/Chromium 141.0.7390.37, Linux; HTML R14.27 + `sw.js` R14.23-SW2 | **10/10** |
| Worker com transporte interrompido — **R14.28** | Claude | PW1.56.0/Chromium 141.0.7390.37, Linux; HTML R14.28 + `sw.js` R14.23-SW2 | **10/10** |
| Exibição da discordância (R14.28) em Chromium e WebKit | Claude | Chromium 141.0.7390.37 e WebKit 26.0 (Playwright build 2215), Linux | **0 falhas** nos dois (ver H.4); WebKit no Linux não equivale a Safari/iPhone físico |
| iPhone/Safari físicos e uso clínico real | Nenhuma execução registrada | — | Pendentes operacionais |

Dos resultados de navegador, **foi reexecutado pelo Claude** apenas o worker com transporte interrompido em Chromium 141 (linha acima). **Não foram reexecutados:** a matriz Playwright 1.58/Chromium 153 (com e sem `set_offline`) e o WebKit, que permanecem como relato do ChatGPT. O worker permanece byte a byte: SHA 868972f473094deafe00372b44de52f1e35b2ff15a576d6222d5b39f70fcc840, versão R14.23-SW2. O HTML e o worker têm versões independentes.

## G. Comparação numérica estável nas igualdades dos cortes (R14.24 e R14.25)
- **Problema (achado BND-CA-01 do ChatGPT, reproduzido):** a conversão cm→mm é `v*10` em ponto flutuante, então um valor digitado **exatamente** igual ao corte pode chegar ao comparador como 173,29999… ou 98,10000…1 e virar "abaixo do p3" ou "acima do p90". Exemplo: 24+0 com CA 17,33 cm (= p3 exato) fechava "RCF por CA < p3". Igualdade não satisfaz um critério estrito.
- **Correção:** função `cmpMedida(a,b)` (tolerância `16 × Number.EPSILON × max(1, |a|, |b|)`; é uma tolerância absoluta que cresce com a escala — cerca de 16 ulps para valores de ordem 1, ≈3,6×10⁻¹⁵ até 1 e ≈6×10⁻¹³ em 170 mm —, não um arredondamento) aplicada em 26 comparações: na R14.24, CA (`caPercentil` ×4, `fetoOutro`, `seletiva`), ossos longos (p3, ×2) e DIO (p10/p90, ×2); na R14.25, TN p5/p95 (×2), limites inclusivos da razão CF/CA e CF/DBP (×2) e alerta estrito de CF/CA > 24% (×1), flag de p95 da média das uterinas (×1) e aviso de sensibilidade entre referências (×2); na R14.26, razão PFN/ON ≥ 0,80 (×1), razão CT/CA < 0,80 e < 0,85 (×2) e diferença saco–CCN < 5 mm, por via (×3); na R14.27, limites de 20% e 25% da discordância entre fetos (`discCat`, ×2). Na R14.28, `discFmt()` confere a categoria do número efetivamente exibido (ver H.4). Não arredonda medidas nem percentis; não usa tolerância clínica; operadores seguem estritos; curvas, tabelas e UI inalteradas. `valmm()` **não** foi alterado: a evidência mostra diferenças de representação/interpolação binária dos valores e cortes (tíbia 31+0, 4,77 cm; ulna 27+0, 3,99 cm). Isso não comprova erro científico dos literais publicados; a correção atua na comparação.
- **Varredura dos consumidores de `valmm()`** (metamórfica: saída com conversão ruidosa × conversão decimal exata, todos os decimais de 0,01 a 12 cm — 40 cm na CA): no R14.23 divergiam CA, as cinco ósseas e a DIO (semanas ímpares). A sonda original retornou 0 divergências no recorte executado (CA, úmero, rádio, ulna, tíbia, fíbula, cerebelo, DBO, DIO, cisterna, átrio, prega, osso nasal, PFN, pelve, ureter, bexiga, parênquima, colo, CCN, TN, DMSG), mas não ativou todos os pré-requisitos: TN foi testada sem CCN. Esse resultado não aprova todos os consumidores. O inventário estático tem 24 IDs, incluindo bCC/bFL, e a auditoria adicional ativou os ramos de HC+FL/TN. Limites: IGs de semana completa; o salto interno do `phi` em z = 0 (q = 50,000015 × 49,999985) não muda classe nem texto e foi ignorado.
- **Testes permanentes** (oráculo em frações): CA 108 fronteiras em semanas completas e 192 decimais incluindo dias intermediários; ossos longos; DIO; gemelar (`fetoOutro` e sFGR); na R14.25, TN (1.755 e 4.692), razões CF/CA e CF/DBP (2.448) e uterinas (57.852); na R14.26, consumidores ativos (4.281: PFN/ON, CT/CA, saco–CCN e recortes de parede, prega e CCN/DMSG isolados; autoria ChatGPT, reexecutado pelo Claude). Em cada fronteira: abaixo, igualdade e acima.


## H. Reconciliação técnica de 30/09/2026 — integrada na R14.25

O handoff de 26/09 registra encerramento científico. As verificações recentes procuram erros de implementação e aderência; não redefinem a teoria. As correções desta seção estão **integradas na R14.25 oficial** (SHA-256 `0d7b9c8f773b29577826df286818c9ef3176f9cd77296a4d724cac743e7d23cd`).

- Hierarquia atual (instrução do responsável): **FEBRASGO → CBR → ISUOG**. FMF e demais fontes complementam parâmetros não cobertos; não trocar curvas só para obter outra classe. Exceções previamente autorizadas, como SMFM #46 para graduação do líquido, permanecem documentadas. O texto do overlay de Referências foi alinhado.
- DEC-LONG-001: queda estritamente >50 percentis e intervalo ≥21 dias. Os 21 dias são APP_POLICY de comparabilidade do serviço; não atribuir esse intervalo literalmente ao Delphi. Decisão encontrada no código e testada em 20/21/22 dias e em 49,99/50/50,01 percentis.
- Implementação: comparação estável (`cmpMedida`) também em TN p5/p95, limites e alerta de CF/CA (e CF/DBP), p95 da média uterina e sensibilidade entre referências. Nenhuma curva, tabela, média, corte clínico, unidade, esquema ou `valmm()` foi alterado. Frase óssea na igualdade do p3: “Nenhum abaixo do percentil 3”. Comentário SMFM #46 corrigido para B2–B8.
- Evidência **reexecutada pelo Claude na R14.25** (Linux, Playwright 1.56.0, Chromium 141.0.7390.37): contratos 78/78 e razões 2.448/2.448; uterinas 57.852/57.852; TN 1.755/1.755 e 4.692/4.692; oráculo de interface 104/104; históricos 215/215; varredura 28.080/28.080; v3.1 678/678 (4 inalcançáveis documentados); bateria adicional 3.959/3.959; mutação dirigida 5/5 e mutação de TN 3/3; fronteiras de CA (324 e 576), ossos (210), DIO (39) e gemelar (378); diferencial R14.24×R14.25 (120 fixtures + 160 aleatórios) 280/280 idênticos, exceto a frase óssea intencional; worker com transporte interrompido 10/10.
- **Não reexecutado nesta integração:** mutação histórica (52) e a suíte antiga de 81 casos no baseline R14 do handoff (a evidência existe no pacote do auditor, mas o script não foi fornecido); matriz Playwright 1.58/Chromium 153 e WebKit. iPhone/Safari físicos, implantação/atualização no aparelho e uso clínico real seguem **pendentes**.
- O handoff antigo apresenta MBV ≤2/>8. B.7/B.8 desta referência conservam as correções posteriores R14.21: <2/≥8. A reconciliação não devolve o motor aos limites antigos.

## H.2 R14.26 — auditoria independente da R14.25 e revisão estática dos comparadores derivados (30/09/2026)

- **Origem:** Auditoria_R14_25 (ChatGPT). Três ramos ainda comparavam diretamente o resultado de uma divisão ou subtração: razão PFN/ON (≥ 0,80), razão CT/CA (< 0,80 e < 0,85) e diferença saco–CCN (< 5 mm, por via). Exemplos reproduzidos na R14.25: PFN 0,72 cm / ON 0,90 cm (razão exata 0,80) saía “dentro do esperado”; CT 24,08 / CA 30,10 saía “tórax pequeno”; CT 5,27 / CA 6,20 saía “limítrofe”; DMSG 1,14 / CCN 0,64 dava 4,999999999999998 mm e “saco pequeno”.
- **Correção (R14.26):** seis chamadas de `cmpMedida` (1 PFN/ON, 2 CT/CA, 3 saco–CCN). Operadores vigentes preservados. Nenhuma curva, tabela, cálculo, `valmm()`, UI, campo, schema ou worker alterado. A candidata do auditor (SHA `90609e1d…`) foi reconstruída e a R14.26 (SHA `e2775edb9c4d6bc49513545e59352f6ff906d78cb53b5cd099f4d861e2c6c9c8`) coincide com ela exceto pelas duas linhas de versão.
- **Testes do auditor (autoria ChatGPT), reexecutados pelo Claude sobre a R14.26 (Linux, Playwright 1.56.0, Chromium 141.0.7390.37):** consumidores ativos 4.281/4.281 (na R14.25 eram 3.870 e 411 falhas: PFN/ON 6, CT/CA 297, saco–CCN 108 — repetições de três defeitos, não 411 defeitos); mutação 6/6 sem erro de infraestrutura; reprodução de interface.
- **Reexecutado pelo Claude sobre a R14.26:** contratos 78/78; razões 2.448/2.448; uterinas 57.852/57.852; TN 1.755 e 4.692; oráculo de interface 104/104; históricos 215/215; varredura de diagnóstico 28.080/28.080; v3.1 678/678 (4 inalcançáveis documentados); bateria adicional 3.959/3.959; mutações dirigidas 5/5 e de TN 3/3; fronteiras de CA (324 e 576), ossos (210), DIO (39) e gemelar (378); diferencial R14.25×R14.26 (120 fixtures + 160 aleatórios) 280/280 idênticos — a amostra aleatória não contém as fronteiras novas e **não** prova a correção; worker com transporte interrompido 10/10.
- **Revisão estática dos comparadores derivados (autoria Claude; heurística, não prova).** Três passadas listaram 33 pontos (23 contra literal, 1 contra tabela, 9 com aritmética inline). Nenhum novo defeito de igualdade foi demonstrado; nenhum código foi alterado por essa revisão. Decisões clínicas conferidas: CPR × p5 (o p5 vem da equação de Ciobanu, irracional; menor distância a um par digitável: 7,3×10⁻⁸ em 13,1 milhões de pares); MoM × 1,5 e 1,3 (mediana por equação; menor distância 1,3×10⁻⁵ em 273 mil pares); discordância ≥ 25% (gramas inteiros: 1.451 pares, 0 falhas); domínio do CCN 0,2–12,0 cm (exato nas bordas); CPR com IPs iguais (razão 1,0: 371 pares, 0 falhas); DEC-LONG-001 (percentis irracionais; teste existente em 49,99/50/50,01). Os demais pontos são guardas, rótulos, textos, contadores inteiros ou rolagem de tela. Detalhe por ponto: `REVISAO_ESTATICA_R14_26.md` (no pacote de testes).
- **Limites:** a varredura estática não vê derivações feitas por funções distantes e pode deixar passar comparadores; a sonda `valmm` continua sem ativar todos os pré-requisitos. Não se declara ausência global de defeitos nem varredura global de `valmm()`.
- **Não reexecutado pelo Claude:** matriz Playwright 1.58/Chromium 153 e WebKit, e o teste de atualização R14.24→R14.25 (relato do ChatGPT); mutação histórica (52) e suíte antiga de 81 casos; leitura do Manual Mestre v2.0 e dos Modelos Aprovados v1.0 (não recebidos pelo Claude). iPhone/Safari físicos, implantação/atualização no aparelho e uso clínico real: pendentes.

## H.3 R14.27 — auditoria profunda PIG/GIG/RCF, gestação única e gemelar (01/10/2026)

- **Origem:** Auditoria_Profunda_Fetal_R14_26_Evidencias (ChatGPT; baseline R14.26, SHA `e2775edb…`). Cinco achados (F01–F05). A R14.27 (SHA `bd54755a8a0b2dfce6104f0714f09f3789a10c45494fdc1c1c86f159078a6021`) foi liberada por você com os cinco, com F02 por Φ preciso apenas no caminho do peso.
- **Ponderação das prioridades (posição do Claude, diferente da do auditor em F02):** F01 real e corrigido (peso inválido do outro feto chegava ao classificador). F02 real, mas de relevância clínica muito baixa: o `phi()` (Abramowitz–Stegun com constante truncada) erra até 2,1×10⁻⁵ pontos percentuais; nos quatro cortes o erro é de ±5×10⁻⁶ a ±7×10⁻⁶, o que abre janelas de 4×10⁻⁵ a 2×10⁻⁴ g (cerca de 6 ordens de grandeza abaixo do erro de medida do ultrassom). Estimativa do Claude, com premissas de peso contínuo e ln normal: cerca de 1 exame em 4 milhões. Corrigido por coerência com a limitação já documentada no MICROFIX C0-A, não por urgência clínica; não classificado como P1. F03 real e de baixa relevância (a IG existe na prática; o cartão já mantinha o alerta de gravidade). F04 real (o `var outroId` ficava só no ramo biométrico), sem falso diagnóstico demonstrado (o bloqueio final funciona). F05 real e cosmético; o caso 2000,20 / 1500,15 g está fora do `step=1` do campo.
- **Implementação:** (F01) `fetoOutro()` aplica o gate de `peso()` (finito, 50 a 7000 g, inclusive); o valor recusado fica em `wRecusado` e não entra em discordância nem sFGR. (F02) `phiPreciso()` (série de Maclaurin da erf até x=2 e fração contínua de erfc acima) usado só em `pctPesoFromZ()`; o `phi()` genérico (Doppler, CA, uterinas) segue intocado, assim como a neutralização do ponto nominal. (F03) nova classe `aedf-ig-desconhecida`: sem premissa de forma precoce/tardia, achado de gravidade visível, pede IG válida; o texto usa “limite de 32 semanas da definição Delphi”. (F04) `outroId` declarado antes dos ramos. (F05) `discCat` (comparação estável de 20% e 25%) e `discFmt` (duas casas quando o arredondamento cruzaria o limite; o cálculo segue usando o valor bruto); laudo diz “igual ou acima de 25%”. Não alterados: modelos, SD, domínios, tabelas, `valmm()`, `cmpMedida`, regra >50 pontos e ≥21 dias, política de comparabilidade gemelar, UI estrutural, schema e worker.
- **Contrato de identidade com o handoff R14:** 20 tabelas idênticas; das 30 funções inspecionadas, 28 idênticas e 2 diferentes — `fcfLeitura` (CTI-07, já conhecida) e `pctPesoFromZ` (F02, mudança intencional); 0 ausentes.
- **Reexecutado pelo Claude sobre a R14.27 (Linux, Playwright 1.56.0, Chromium 141.0.7390.37, Node 22):**
  - Bateria nova das correções (autoria Claude; campos reais da interface e oráculos em `erfc`/frações): R14.26 com 297 registros de falha; R14.27 com **0** (F01 110 checagens, F02 2.412, F03 10, F04 9, F05 8). Φ preciso contra `erfc` da libm em 432.001 pontos: erro absoluto máximo 7,5×10⁻¹⁶ e relativo de cauda 5,2×10⁻¹² (o `phi()` antigo: 2,1×10⁻⁷ e 3,6×10⁻³).
  - Oráculo de interface 104/104; históricos 215/215; v3.1 678/678 (4 inalcançáveis documentados); varredura de diagnóstico 28.080/28.080; bateria adicional 3.959/3.959; fronteiras de CA (324 e 576), ossos (210), DIO (39) e gemelar (378); diferencial R14.26×R14.27 (120 fixtures + 160 aleatórios) 280/280 idênticos; worker com transporte interrompido 10/10.
  - Das rodadas anteriores, sobre a R14.27: consumidores ativos 4.281/4.281; razões CF/CA e CF/DBP 2.448/2.448; uterinas 57.852/57.852; TN 1.755 e 4.692; contratos semânticos 78/78; mutações 6/6, 5/5 e 3/3.
  - Testes do auditor (autoria ChatGPT): matriz de interface **2.947/2.947** (R14.26: 2.304); matrizes abstratas 245.760, 86.400, 235.224 e 117.612 sem falha (a lista de extração do harness foi ampliada por 4 nomes — `phiPreciso`, `discCat`, `discFmt`, `n2` — numa cópia, `export_engine_r27.py`; o original foi preservado); mutações dele 18 detectadas e 1 não aplicável (o código `disc>=25` que ela mutava foi substituído); `ui_events`: sFGR nulo nos dois lados e nenhum RCF falso; `invalid_ga` 32/32; `verify_counterexamples` 13/14.
  - Mutação das correções (autoria Claude): 15 mutantes — 13 detectados, 2 equivalentes documentados (gate sem `isFinite`; critério sFGR de discordância cru — equivalência **restrita ao domínio declarado**: discordância formal exige bio×bio, com pesos das equações de Hadlock/INTERGROWTH e entradas decimais; nesse domínio o peso é 10 elevado a um número racional, e a razão exata 3/4 exigiria que log10(3/4) fosse racional, o que é impossível em aritmética exata, logo a igualdade exata de 25% não ocorre. Isso é uma equivalência matemática, não uma garantia sobre o ponto flutuante nem sobre entradas fora do domínio: em ponto flutuante a razão pode cair a ~10⁻¹⁶ do corte, caso em que `discCat()` (comparação estável) e o `>=` cru poderiam diferir), 0 sobreviventes, 0 erros de infraestrutura. Na primeira passada 2 sobreviveram (texto do ramo bio×bio e linha de discordância no guia) por lacuna do meu teste; reforcei o teste e eles passaram a ser detectados.
- **Divergências deliberadas em relação ao auditor (decididas pelo Claude; você pode revertê-las):**
  1. O check `ST.disc.v ≥ 25` do caso 2000,20 / 1500,15 g e a grade numérica de discordância medida no **valor bruto** (111.938 falhas, inalterado) não são satisfeitos: o bruto 24,999999999999996 foi preservado, pois o auditor pede para não arredondar medidas. A decisão por **categoria**, na mesma grade exata (346.417 pares, 20% e 25%, com 0, 1 e 2 casas), dá 0 falhas.
  2. Bateria numérica de pesos (17.734 checagens, oráculo Decimal): R14.26 com 3.351 falhas; R14.27 com 44, nenhuma em gramas inteiros, em 0,01 g ou em 1×10⁻⁴ g. As 44 estão no recorte de 1×10⁻⁶ g. **Correção (R14.28):** a distância máxima ao corte é 4,738×10⁻⁸ g (≈ **47,4 ng**; Hadlock, 39+0, p97, entrada 4304,237291 g, corte 4304,237290952624 g; o app devolve q=97 embora a entrada esteja ligeiramente acima) e a mínima 1,4×10⁻⁹ g. A afirmação anterior, “entre 1 e 8 nanogramas”, era uma extrapolação minha a partir dos cinco primeiros exemplos, e foi corrigida pela leitura das 44 ocorrências. O mecanismo é o `snap` nominal preexistente (|z−Z|<1×10⁻¹⁰, ou seja, ≈ 1,2×10⁻¹¹ do peso em termos relativos, que cresce com o peso em gramas), e não a aproximação antiga de Φ; ele não foi alterado para não ampliar o escopo liberado. É uma política microscópica documentada, não prova de comparação estritamente matemática para todas as entradas reais.
  3. **F03 criou um estado novo** (`aedf-ig-desconhecida`), com ramificação própria no cartão e no laudo; não foi uma troca lexical. Só depois, e como ajuste separado, a redação desse estado foi reescrita para não conter “a partir de 32” (critério lexical do auditor, evitando leitura como premissa).
- **Não reexecutado pelo Claude:** WebKit; as buscas dirigidas de 2.770.347 e 752.874 combinações (os três testemunhos de percentil e o longitudinal foram reproduzidos individualmente); a leitura dos PDFs da ISUOG citados; as capturas de tela; a mutação histórica (52) e a suíte antiga de 81 casos. iPhone/Safari físicos, implantação/atualização no aparelho, uso offline no aparelho e validação clínica seguem **pendentes**.
- **Limites:** o auditor e o Claude escreveram os seus oráculos; independência da implementação não equivale a revisão por um segundo autor. Os testes cobrem espaços finitos; não há prova formal global nem enumeração de todas as entradas e ordens de interação.

## H.4 R14.28 — conclusão de F05 da R14.27 e correções documentais (01/10/2026)

- **Origem:** Auditoria_R14_27_Evidencias (ChatGPT; baseline R14.27, SHA `bd54755a…`). F01–F04 confirmados como corrigidos; F05 com lacuna residual: `discFmt()` passava de inteiro para 2 casas sem conferir se o arredondamento de 2 casas voltava a cruzar o corte. Testemunhos do auditor (IG 30+0, dicoriônica, Hadlock, bio×bio; A: DBP/CC/CA/CF = 7,80/28,50/26,00/5,80 cm): B = 7,00/26,00/22,62/5,96 dá bruto 19,996547704250155% (exibido “20,00%” com “dentro do esperado”); B = 7,00/26,00/22,00/5,81 dá 24,99766227413156% (exibido “25,00%” com “risco”). Reproduzidos pelo Claude em Chromium 141 antes da correção, no cartão, no corpo e na linha do guia, nas duas orientações A/B.
- **Posição do Claude:** a categoria sempre esteve correta; o defeito era só de apresentação. A estimativa grosseira do Claude (premissa: 1 a 2% dos gemelares por ponto percentual perto de 20–25%) é de cerca de 1 em 5.000 a 10.000 gemelares, bem mais frequente que F02, o que justifica corrigir; não é frequência medida. A lacuna foi do próprio Claude: tratou o sintoma (inteiro) e não o invariante (“o número exibido nunca cruza a categoria”).
- **Implementação (decisão do responsável):** `discFmt()` tenta inteiro, depois 2, 3 e 4 casas e aceita a primeira representação cujo **número final exibido** permaneça na mesma categoria de `discCat(valor bruto)`; se nenhuma servir, mostra “<20%” ou “<25%” conforme a categoria. Acima do corte o arredondamento é monótono e nunca cai abaixo dele. Preservados: cálculo bruto, `discCat()`, F01–F04, `cmpMedida`, `valmm()`, curvas, critérios, UI, schema e worker. Não incluídos: rótulos de percentil de peso perto do corte (observação do Claude, item opcional não liberado).
- **Reexecutado pelo Claude (Linux; Playwright 1.56.0; Chromium 141.0.7390.37; WebKit 26.0 / Playwright build 2215, instalado nesta rodada; Node 22):**
  - Bateria nova de exibição (autoria Claude; `r28_f05_exibicao.py`; oráculo Decimal independente): R14.27 com 9.978 registros de falha; R14.28 com **0 em Chromium e 0 em WebKit** (testemunhos A/B 4 checagens, abaixo/igual/acima em gramas inteiras 32, grade de 45.098 valores brutos perto de 20% e 25% com verificação de categoria, precisão mínima e fallback, e fallback ponta a ponta com cartão, corpo, guia e simetria A/B 6).
  - Mutação do `discFmt()` (autoria Claude): 10 mutantes, 10 detectados, incluindo a remoção da verificação final da categoria (N01) e a verificação sobre o valor bruto em vez do exibido (N03); 0 sobreviventes; 0 erros de infraestrutura.
  - Regressões: oráculo de interface 104/104; históricos 215/215; v3.1 678/678 (4 inalcançáveis); varredura 28.080/28.080; bateria adicional 3.959/3.959; bateria F01–F05 da R14.27 (110, 2.412, 10, 9 e 8 checagens) com 0 falhas; Φ preciso contra `erfc` 432.001 pontos (erro absoluto 7,5×10⁻¹⁶); fronteiras de CA (324 e 576), ossos (210), DIO (39) e gemelar (378); diferencial R14.27×R14.28 280/280 idênticos (a amostra aleatória não contém as fronteiras novas; não prova a correção); worker com transporte interrompido 10/10; consumidores 4.281, razões 2.448, uterinas 57.852, TN 1.755 e 4.692, semântica 78, mutações 6/6, 5/5 e 3/3. Contrato de identidade: 20 tabelas idênticas, 28/30 funções idênticas; diferem `fcfLeitura` e `pctPesoFromZ` (F02, intencional).
  - Pacote do auditor (autoria ChatGPT; reexecutado pelo Claude nos ambientes acima, com o HTML R14.28 no lugar do baseline): matrizes abstratas 245.760, 86.400, 235.224 e 117.612 sem falha; bateria numérica de pesos com as mesmas 44 neutralizações nominais (0 em gramas inteiras, 0,01 g e 1×10⁻⁴ g); discordância por categoria 0 falhas em 346.417; mutações dele 19/19; matriz de interface 2.947/2.947 em Chromium e em WebKit; `invalid_ga` 32/32 em ambos; gravidade e estado 9.225/9.225 (Chromium); `verify_counterexamples` 13/14 em ambos (o check residual exige o valor **bruto** `ST.disc.v ≥ 25`, preservado por design); `display_probe` mostrando “19,997%” e “24,998%”, com as categorias corretas, nas duas orientações e nos dois navegadores.
- **Três correções documentais (feitas nesta versão):** (1) o residual máximo das neutralizações nominais é ≈ 47,4 ng, não “1 a 8 ng” (ver H.3); (2) F03 criou o estado novo `aedf-ig-desconhecida`, não foi uma troca lexical (ver H.3); (3) a equivalência do mutante M14 vale só no domínio declarado e em aritmética exata, e deve ser distinguida do comportamento em ponto flutuante (ver H.3).
- **Não reexecutado pelo Claude:** Chromium 153 e WebKit build 2248 do auditor (usei Chromium 141 e WebKit 26.0 / build 2215); o `severity_and_state` em WebKit (o script é só Chromium); a mutação histórica (52) e a suíte antiga de 81 casos; as buscas dirigidas de 2.770.347 e 752.874 combinações; a leitura dos PDFs da ISUOG; Manual Mestre e Modelos Aprovados (não recebidos). iPhone/Safari físicos, atualização/uso offline no aparelho e validação clínica seguem **pendentes**; WebKit no Linux não equivale a Safari/iPhone.
- **Limites:** auditor e Claude escreveram os seus próprios oráculos; os espaços testados são finitos; nenhuma contagem prova ausência universal de defeitos.


---

<!-- ARQUIVO: MATRIZ_PENDENCIAS.csv -->

```csv
prioridade,item,estado,proximo_passo
P3,D3 zoom bloqueado na meta viewport,Sem efeito no iPhone,Só alterar com teste no aparelho
P1,iPhone/Safari físico e offline,Não testado,Testar a R14.40 no aparelho (datas; barras do rodapé com teclado; área segura; offline; atualização)
P0,Publicação R14.40 — site em 404 desde 10/10 13:56,Arquivos excluídos do GitHub sem reenvio,Enviar index.html + CONTEXTO.md + README.md + suíte e conferir o site
P3,Ciobanu: carta DeVore e réplica 2021,Texto não acessado,Obter documentos; decisão atual mantida
P3,Roberts 2025 volume e páginas,DOI confirmado; volume/páginas não,Confirmar no corpo do artigo
P3,Mari 1995 corpo do artigo,Só resumo,Obter métodos do nomograma
P3,Hadlock 1992 CCN,SOURCE_FREEZE_PENDING,Obter corpo do artigo
P3,INTERGROWTH Table S2,Não obtida,Conferência célula a célula se desejada
P3,Alerta NHS England/RCOG 2025,Só fontes secundárias,Ler o original
RESOLVIDO R14.33,Átrio 9–9.9 mm,Normal sem retorno automático,—
RESOLVIDO R14.33,PSV após 35 sem e domínio,Avisos e texto de validação,—
RESOLVIDO R14.33,Colo após 24 sem,Comprimento cervical reduzido,—
RESOLVIDO R14.33,Aviso de Hadlock,Atribuição corrigida,—
RESOLVIDO R14.33,PSV 1.3–1.49 MoM,Rotulada como faixa de atenção do app,—
RESOLVIDO R14.33,Documentação e referências,Tela de referências atualizada,—
FECHADO,Hadlock 1991 equação × tabela,Decisão C0-A,Manter
FECHADO,Hadlock 1985 e INTERGROWTH 2020,Confirmados no original,Manter
FECHADO,Ciobanu equações × tabela,Diferença ≤ 0.0043 na mesma IG,Manter equações
FECHADO,UTD A1 incompleto,Não era regressão,Manter

RESOLVIDO R14.34,E1 osso nasal e tricúspide 1º tri sem janela,Janela 11+0–13+6,—
RESOLVIDO R14.34,E2 osso nasal 2º tri fora de 20–24 sem,Corte só na janela,—
RESOLVIDO R14.34,D1 D2 D4 documentação,Aplicado,—
FECHADO,Colo R14.33 (muito curto e cor),Mantido por decisão delegada,—
FECHADO,E3 prega nucal,Não era erro (campo só de 16 a 24 sem),—
RESOLVIDO R14.35,Valor exibido igual ao corte (PSV CPR vasos uterinas),Casas extras perto do corte,—
RESOLVIDO R14.35,Colo citado como achado morfológico,Agora achado materno,—
REGISTRADO,Operador PSV ≥1.5 × fonte >1.5,Sem efeito prático,Mantido
FECHADO,Adu-Bredu 7.2% × 4.2%,Confirmado no resumo (21.874 gestações),—
P3,Vintzileos 1984 corpo do artigo,Resumo + faixa de fêmur por fonte secundária,Obter o texto original
P3,Tamanho do bebê na população brasileira,Sem validação,Registrado como limitação
RESOLVIDO R14.36,Via das uterinas sem padrão,Transabdominal pré-selecionada + aviso no 1º tri,—
RESOLVIDO R14.36,Incisura em três estados,Quadradinho por lado,—
RESOLVIDO R14.36,Barrinha por lado das uterinas,Só consulta pela curva do IP médio,—
RESOLVIDO R14.37,Campo empurrado por aviso,Âncora do campo em edição,—
RESOLVIDO R14.37,Ergonomia (biometria primeiro; abas no rodapé; avisos dobrados; barra de cópia; simetria),Aplicado,—
RESOLVIDO R14.38,Próximo pendente e aviso rápido sob as barras; por quê sem teclado; 320 px,Corrigido,—
RESOLVIDO R14.39,Tamanho do bebê para a paciente,Vintzileos 1984 autorizado,—
RESOLVIDO R14.39,Próximo pendente só na aba Laudo,Em todas as abas,—
RESOLVIDO R14.40,Limpeza do pente fino (CSS sem efeito; constantes duplicadas; estilo antigo),Aplicado,—

```
