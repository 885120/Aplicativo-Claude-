# Pente fino geral — R14.34 → R14.35

Data: 06/10/2026. Auditor: Claude. Base auditada: R14.34 (`4152a234…`). Versão resultante: R14.35 (`47b3d14c74c611dd1fc44ee7b2e6a58700d856f6bc13cdb96edcd8d43879dbc4`), liberada pelo médico ("Tudo").

## 1. Escopo e método

1. **Integridade:** reconstrução da cadeia de patches, hash, sintaxe, IDs, referências de elementos, schema e worker.
2. **Regressão:** suíte completa e testes dirigidos de cada versão.
3. **Exames simulados:** 1º trimestre com 9 e 12 semanas, morfológico de 22 semanas, 3º trimestre de 30 semanas e troca de feto no gemelar, lendo cartão, síntese e laudo.
4. **Varredura de textos:** frases e citações que sobraram de versões antigas.
5. **Validação de dados clínicos e citações:** completa para tudo o que foi inserido em 06/10/2026.
6. **Coerência documental:** dossiê, CONTEXTO, README e hashes.

## 2. Resultado da R14.34

- **Íntegra:**
  - os patches reconstroem a R14.33 e a R14.34 byte a byte;
  - 332 IDs únicos, nenhuma referência `$()` a ID inexistente;
  - SCHEMA 14; `sw.js` R14.23-SW2 inalterado;
  - publicada como `index.html` + `sw.js`, carrega sem erro e registra o worker em Chromium e WebKit (o 404 visto no servidor de testes era só a ausência do `sw.js` naquela pasta).
- **Testes:** suíte 48.184/0 (Chromium e WebKit); rótulos de percentil (`t32.py`) 740/0; `t33.py` 278/0; `t34.py` 112/0.
- **Exames simulados:** coerentes. Com 12 semanas os marcadores entram no laudo; com 9 semanas, não. Átrio de 9,5 mm é normal e não aparece no laudo; colo de 20 mm com 22 semanas é "colo curto", e com 30 semanas, "comprimento cervical reduzido". No gemelar, o osso nasal é por feto e o colo é compartilhado.
- **Textos antigos:** só sobraram ramos de código que não são mais executados (`atr==='lim'`, `colo==='muito'`). Não aparecem na tela.
- **Dados e citações conferidos:**
  - Maisonneuve 2017 (69% entre 34 e 37 semanas) e Sharon-Weiner 2022 (RESUMO).
  - Roberts 2025: 176.060 exames e 5,1% de 78.660 pacientes (RESUMO). O DOI está correto; o volume e as páginas "233:331.e1-11" não foram confirmados.
  - Adu-Bredu 2026: p10 da equação ≈ p17 da tabela, e 7,2% × 4,2% abaixo de p10 em 21.874 gestações de 35+0 a 36+6 semanas (RESUMO). Isso confirma o que antes estava como RECEBIDO.
  - FEBRASGO morfológico 2025 (PDF anexado): exame entre 20 e 24 semanas; osso nasal ≥ 4,5 mm; átrio < 10 mm; colo ≤ 25 mm antes de 24 semanas; CCN de 45–84 mm para 11 a 13+6 semanas.
  - Nomogramas do osso nasal no 2º trimestre (RESUMOS).
  - Alerta do NHS England divulgado pelo RCOG (fontes secundárias).

## 3. Achados

1. **Valor exibido igual ao corte com classe diferente** (mesma família do rótulo de percentil da R14.32):
   - PSV: "1,50 MoM — Limítrofe" com MoM de 1,4985, em 99 combinações de IG e velocidade.
   - CPR: "0,85 · p5 = 0,85 · abaixo do p5", em cerca de 0,2% das combinações de IP.
   - Umbilical: "IP 1,57 acima do p95", com o p95 exibido também como 1,57.
   - Uterinas: a média de dois lados (ex.: 1,585) aparecia "1,58" acima do p95 de 1,58. Este último caso foi achado pelo teste novo durante a correção.
   - Em todos, a classificação estava correta.
2. **Colo listado como "achado morfológico" na conclusão**, embora seja achado materno. Já vinha de antes da R14.33.
3. **Operador da PSV:** o app usa ≥ 1,5 MoM e a fonte (SMFM #8, Mari 2000) escreve > 1,5. Sem efeito prático, porque o MoM calculado nunca é exatamente 1,5. Mantido, porque operadores clínicos não mudam sem decisão específica; fica registrado.
4. **Documentação desatualizada:**
   - o dossiê ainda dizia que as escolhas do colo aguardavam conferência e que Adu-Bredu estava pendente;
   - a pasta de saída tinha a versão antiga do relatório de auditoria (que ainda chamava a prega nucal de erro provável) e dossiês antigos já superados.

## 4. O que entrou na R14.35

- **Achado 1:** as funções `casasPar`, `fxVal` e `fxCorte` acrescentam casas (até 5) quando valor e corte pareceriam iguais com 2 casas. Aplicadas ao MoM da PSV (no cartão, na barra, no laudo e na síntese), à CPR (valor, p5, cortes de 1,0 e 1,3, laudo e avisos), à faixa p5/p50/p95 dos vasos e das uterinas e ao IP médio das uterinas (na tela e no laudo, 1º e 2º/3º trimestres). Só muda a exibição; a classificação continua no valor bruto.
- **Achado 2:** a função `achadosTxt()` separa achado materno de achado fetal na conclusão. Exemplos: "com achado materno: colo curto"; "com achado(s) morfológico(s): ventriculomegalia e achado materno: colo curto". O título da síntese passa a "Peso adequado, achado materno" quando o colo é o único achado.
- **Achados 3 e 4:** registrados no dossiê e no CONTEXTO; arquivos superados removidos da pasta de saída.

## 5. Testes da R14.35

| Teste | Resultado |
|---|---|
| `t35.py` (mudanças da R14.35), Chromium e WebKit | 630 checagens, 0 falhas; na R14.34, 152 falhas |
| `t34.py`, `t33.py` e `t32.py` na R14.35 | 112/0, 278/0 e 740/0 |
| Suíte de regressão completa, Chromium e WebKit | 48.184 checagens, 0 falhas nos dois |

## 6. Continua pendente

- Teste em iPhone físico (campos de data, uso offline, atualização) e publicação.
- D3 (zoom bloqueado): só com teste no aparelho.
- Documentos não obtidos: carta de DeVore e réplica, corpo de Mari 1995, Hadlock 1992, Table S2 do INTERGROWTH, corpo de Roberts 2025 (para o volume e as páginas) e texto original do alerta do NHS.
