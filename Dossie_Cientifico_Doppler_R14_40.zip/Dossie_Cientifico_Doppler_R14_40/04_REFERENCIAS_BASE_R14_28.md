# REFERÊNCIAS — cadeia de proveniência das tabelas e regras do motor

Calculadora Doppler Obstétrico · baseline de saída **R14 (corrigida; schema 13 no handoff)** · versão vigente **R14.28** (SCHEMA_VERSION=14)
Última auditoria: 2026-09-26 (C3b.2a + R14 inicial + correções pós-revisão externa); 2026-09-30 (integração R14.25: comparação numérica estável e reconciliação documental; R14.26: PFN/ON, CT/CA, saco–CCN e revisão estática dos comparadores derivados); 2026-10-01 (R14.28: exibição da discordância e correções documentais); 2026-10-01 (R14.27: auditoria profunda PIG/GIG/RCF gemelar — gate de PFE do outro feto, Φ preciso no peso, IG ausente com AEDF/REDF, escopo do outro feto e discordância).
Cumulativo: mantém o detalhamento de C3b.2a (órbitas, DV1, FCF, TN, UTD) e adiciona as 10 adjudicações da R14. Nenhum PDF de editora está neste repositório — PDFs licenciados ficam em armazenamento privado do responsável, fora da pasta de deploy (o Vercel serve publicamente tudo que está na pasta de deploy).

Níveis de evidência: PRIMARY_FULLTEXT · PRIMARY_TABLE · PRIMARY_FIGURE · PRIMARY_ABSTRACT · GUIDELINE_CONSENSUS · AUTHORIAL_REPRODUCTION · SECONDARY_REPRODUCTION · SECONDARY_REVIEW · EQUIPMENT_REPRODUCTION · APP_POLICY (decisão do app, não dos autores) · APP_HEURISTIC (heurística interna, sem validação publicada) · UNKNOWN_ORIGIN.

---
---

# PARTE A — Módulos já auditados no C3b.2a (base congelada, não reaberta na R14)

## A.1 Órbitas — distância interocular (DIO) e binocular (DBO)

- **Referência:** Sukonpan K, Phupong V. Fetal ocular distance in normal pregnancies. *J Med Assoc Thai* 2008;91(9):1318-1322. PMID 18843858.
- **Local:** Tabela 1 (interocular) e Tabela 2 (binocular).
- **Como foi conferido:** imagem das duas tabelas extraída do PDF publicado (servidor de figuras da Semantic Scholar). 156/156 células de p10/p50/p90 idênticas ao motor; soma dos n = 595, igual ao artigo.
- **Domínio:** 15–40 semanas; linha da semana **completa**, sem interpolar (APP_POLICY_COMPLETED_WEEK).
- **Estatística:** p10/p50/p90 empíricos por semana. A fonte **não** publica p5/p95: fora de p10–p90 é alerta amarelo, não diagnóstico.
- **Status:** CONFIRMADO — PRIMARY_TABLE.
- **Fonte anterior descartada:** tabela "Jeanty 1982" da Fetalmed, identificada como reconstrução com bandas fixas ±5,0/±3,0 mm — não é transcrição do artigo original.

## A.2 Ducto venoso — PIV no 1º trimestre

- **Referência:** Pruksanusak N, Kor-anantakul O, Suntharasaj T, Suwanrath C, Hanprasertpong T, Pranpanus S, Geater A. A reference for ductus venosus blood flow at 11–13+6 weeks of gestation. *Gynecol Obstet Invest* 2014;78(1):22-25. DOI 10.1159/000362273.
- **Local:** p. 24, Tabela 2 ("Values of S/a, PIV, PLI, and PVIV with CRL 45.9–75.5 mm"), lida no texto integral.
- **Valores no motor:** PIV p5 **0,69** (IC95% 0,64–0,73) · p50 **0,92** (0,90–0,94) · p95 **1,13** (1,08–1,19).
- **Domínio:** CCN **45,9–75,5 mm** (faixa observada). Fora disso: IP registrado, sem classificação. Sem percentil intermediário.
- **Não usar:** Sachin et al. 2025 (IJCPR 17(3), Tab. 7) atribui 0,64/0,84/1,01 ao PIV — é a linha do **PVIV**.
- **Status:** CONFIRMADO — PRIMARY_TABLE.
- **Comportamento congelado (verificado por regressão, 200 cenários, 0 divergências em toda a R14):** onda A interpretada à parte do PIV; onda A positiva + IP acima do p95 → cartão amarelo com "IP acima do p95" (não "Normal"); IP abaixo do p5 → neutro; sem IP → "Normal".

## A.3 Frequência cardíaca fetal (FCF)

- **Prognóstico precoce (6+0–7+0):** Doubilet PM, Benson CB. *J Ultrasound Med* 1995;14:431-434 — limite inferior 100/120 bpm — e faixa "poor" do resumo autoral de Doubilet (<90/<110).
- **FC rápida (6+0–7+0):** Doubilet, Benson & Chow. *AJR* 2000;175:67-69 — ≥135/≥155 bpm, bom prognóstico isolado.
- **Mapeamento de tempo:** `DOUBILET_TIME_MAPPING`: 6+0/6+1 = 1º grupo; 6+3–7+0 = 2º grupo; **6+2 = zona indeterminada** — APP_POLICY.
- **Fisiologia 6+0–9+6:** Silva & Bailão, *RBGO* 2000;22(9), Tab. 2 — colunas −2DP/M/+2DP **publicadas**, por meia semana. Alocação dos dias nas meias semanas não definida no artigo — o app testa as duas alocações plausíveis (APP_POLICY) e só classifica quando concordam.
- **Fisiologia 10+0–13+6:** Pettersen & Faria, *RBGO* 2001;23:567 — p5/p50/p95 por semana completa (1.078 fetos).
- **14+0–19+6:** sem referência ultrassonográfica pontual validada — descritivo.
- **≥20+0:** 110–160 bpm como alerta, faixa basal de CTG (FIGO 2015; Pildner von Steinburg 2013).
- **Status:** CONFIRMADO (todas as camadas, PRIMARY_TABLE/PRIMARY_ABSTRACT conforme o trecho).

## A.4 Translucência nucal (TN)

- **Curva FMF:** Nicolaides KH, Snijders RJM, Cuckle HS, carta *Prenatal Diagnosis* 1998. Equação log10 TN = −0,3599+0,0127·CCN−0,000058·CCN²; MoM 0,62/1,57; CCN 45–84. 40 CCNs recalculados em Python fora do app, idênticos ao motor.
- **Curva Faria:** Pettersen & Faria, *RBUS* 2010 — reprodução autoral da tabela de Faria 2004. 119/119 células conferidas. Só <p5/p5–p95/>p95, sem zona limítrofe reconstruída.
- **Status:** CONFIRMADO (PRIMARY para a carta FMF; AUTHORIAL_REPRODUCTION para Faria).

## A.5 Dilatação do trato urinário (UTD)

- **Referência:** Nguyen HT et al. 2021 update on the urinary tract dilation (UTD) classification system. *Pediatr Radiol* 2022;52:740-751. DOI 10.1007/s00247-021-05263-w. Correção 2023;53:1217 (só o APRPD do P3 = 15mm).
- **Local:** Fig. 1, lida diretamente. Antenatal A2-3: cálices "*Any Dilation*"; ureter/parênquima/bexiga/oligoâmnio só contam "*with APRPD ≥4mm or calyceal dilation*". "Central/Peripheral Dilation" só no pós-natal.
- **Status:** Fig. 1 CONFIRMADA — PRIMARY_FIGURE. Texto integral (para o trecho sobre cálice central) permanece pendente de acesso institucional — não bloqueia a regra vigente, apoiada na figura.

## A.6 Outros módulos citados no motor, não reauditados neste ciclo

Ciobanu et al. 2019 (CPR/FMF), INTERGROWTH-21st (CA/PFE), Hadlock PFE (4/3 parâmetros), Hadlock 1991 (percentil de peso), Vintzileos 1984 (comprimento fetal, auxiliar), RPOC descritivo, placenta descritiva, DMSG +30 informativo — mantidos como estavam, sem alteração nesta rodada.

---
---

# PARTE B — As 10 adjudicações da R14 (com as correções da revisão externa)

## B.1 CC/CA — Campbell & Thoms 1977

- **Referência:** Campbell S, Thoms A. Ultrasound measurement of the fetal head to abdomen circumference ratio in the assessment of growth retardation. *Br J Obstet Gynaecol* 1977;84(3):165-174. DOI 10.1111/j.1471-0528.1977.tb12550.x · PMID 843490.
- **Nível:** PRIMARY_ABSTRACT (resumo) + SECONDARY_REPRODUCTION (tabela, vista em Joshi BR, *J Inst Med Nepal* 2017, Tab. 2 — rótulos de coluna invertidos nessa reprodução; o artigo original está em paywall).
- **Dado original:** n=568 gestações normais, 17–41 semanas. O próprio resumo mistura "95 per cent confidence limits" e "95th centile limit" para os mesmos limites — construção estatística **indeterminada**. Em 31 fetos pequenos para a idade, 22 (71%) ficaram acima do limite do percentil 95.
- **Domínio:** 17–41 semanas, em blocos de 2 semanas (17-18, 19-20, ..., 39-40; 41 isolada) — sem evidência de regressão contínua que sustente interpolação fracionária.
- **Decisão:** REBAIXADO PARA DESCRITIVO. `T_CCAC[Math.floor(g)]` lida por bloco real (pares 17-18/19-20/.../39-40; 41 isolada — corrigido na revisão: o rótulo do bloco antes usava `[floor(g), floor(g)+1]`, que ficava errado nas semanas pares; agora usa a lógica de pares corretos). Exibida como "referência de Campbell 1977 (bloco X–Y sem)", sem cor de normal/anormal, fora da lista "fora da faixa"/critério de RCF.
- **Status:** PARCIALMENTE CONFIRMADO (valores) / INDETERMINADO (estatística e legitimidade de interpolação fracionária).
- **Documentação sincronizada (correção pós-revisão):** o comentário de código de `T_CCAC` e a linha do overlay de Referências foram reescritos para não afirmarem mais "o artigo publica média com IC95%; os rótulos p5/p95 são aproximação" — agora registram a indeterminação estatística real e que a tabela vem de reprodução secundária, não do artigo original.

## B.2 CF/CC — Hadlock et al. 1984

- **Referência:** Hadlock FP, Harrist RB, Shah Y, Park SK. The femur length/head circumference relation in obstetric sonography. *J Ultrasound Med* 1984;3(10):439-442. DOI 10.7863/jum.1984.3.10.439 · PMID 6387166.
- **Nível:** PRIMARY_ABSTRACT (amostra e domínio); a tabela semanal de limites só foi localizada em manuais de equipamento (GE Voluson/LOGIQ) — EQUIPMENT_REPRODUCTION, nunca confirmada no artigo original nem em reprodução autorizada.
- **Dado original:** n=361 fetos normais, 15–42 semanas.
- **Decisão:** REMOVIDO o classificador. A faixa fixa "13,30–23,90% em toda a janela" do baseline anterior era, na prática, o menor limite inferior e o maior limite superior de linhas semanais diferentes de uma tabela nunca verificada — não uma faixa única legítima.
- **Status:** UNKNOWN_ORIGIN / APP_LEGACY para o classificador. CF/CC agora é só numérico, sem normal/anormal.
- **Não migrado para OMS/Kiserud:** a tabela corrigida (Kiserud et al., *PLOS Med* 2017, com duas erratas em 2017 e 2021) não foi extraída e conferida célula a célula nesta rodada — migrar sem essa conferência violaria a mesma regra que está sendo aplicada aqui. Pendente para ciclo futuro.

## B.3 CF/DBP — Hohler & Quetel 1981

- **Referência:** Hohler CW, Quetel TA. Comparison of ultrasound femur length and biparietal diameter in late pregnancy. *Am J Obstet Gynecol* 1981;141(7):759-762. DOI 10.1016/0002-9378(81)90700-6 · PMID 7315902.
- **Nível:** PRIMARY_ABSTRACT.
- **Dado original:** "linear relationship... after 22 weeks' gestation"; FL/BPD = 79 ± 8% (71–87%).
- **Estatística:** o resumo **não define** o que ±8 representa. O rótulo "90% CI" é de manuais de equipamento — **REFUTADO** como citação do autor.
- **Decisão:** MANTIDO 71–87% como **faixa publicada** (nunca "normal" — correção pós-revisão, ver B.9), com gate real em **≥23+0 semanas** (APP_POLICY). Abaixo do gate, o valor é só descritivo.
- **Status:** PARCIALMENTE CONFIRMADO (79±8% = 71-87%) / REFUTADO (rótulo "90% CI").

## B.4 CF/CA — Hadlock et al. 1983

- **Referência:** Hadlock FP, Deter RL, Harrist RB, Park SK. A date-independent predictor of intrauterine growth retardation: femur length/abdominal circumference ratio. *AJR* 1983;141(5):979-984. PMID 6605074.
- **Nível:** PRIMARY_ABSTRACT + fragmentos de PRIMARY_FULLTEXT.
- **Dado original:** n=361, 15–42 semanas; após 21 semanas a razão independe da idade gestacional; normal (mean ± 2SD) 22±2% = 20–24%; corte de rastreio 23,5% = **p90**, sensibilidade de 63% para RCIU (30 casos).
- **Decisão:** MANTIDO 20–24% como **faixa normal** (Hadlock publica explicitamente como "normal range" — por isso, diferente de CF/DBP, esta é a única das três razões onde a palavra "normal" é usada na UI). Gate real em **≥22+0 semanas** (APP_POLICY). Frase causal "típico de insuficiência placentária" REMOVIDA, substituída por linguagem descritiva citando a sensibilidade de 63%.
- **Status:** CONFIRMADO (amostra, domínio, 20–24%, corte de 23,5%=p90, sensibilidade 63%).

## B.5 Razão úmero/fêmur (U/F) 0,90–1,10

- **Busca dedicada:** Krakow D et al. Guidelines for the prenatal diagnosis of fetal skeletal dysplasias. *Genet Med* 2009;11(2):127-133. PMCID PMC2832320. SMFM/AJOG 2018. FEBRASGO nº 43 (2025).
- **Achado:** nenhuma fonte valida a razão U/F 0,90–1,10 nem "úmero curto"/"fêmur curto"/"rizomélico". O que está validado é o percentil/escore z **individual** de cada osso — e as duas sociedades usam limiares **diferentes entre si**: Krakow 2009 (avaliação especializada com medida ≤p5 ou >3 DP abaixo da média) e SMFM 2018 (<p5 ou >2 DP abaixo da média para "curto").
- **Decisão:** REMOVIDO. U/F é só valor numérico. **Correção pós-revisão:** o texto anterior citava incorretamente "abaixo do p3" (não corresponde a nenhuma das duas fontes, que usam p5, com DP diferente entre si) — reescrito para não misturar p3/p5/−2DP/−3DP numa única regra; cada sociedade citada separadamente, com o limiar que lhe pertence.
- **Status:** UNKNOWN_ORIGIN / APP_LEGACY.
- **Fora do escopo (deliberadamente não adicionado):** CF/pé, CF/CA<0,16, CT/CA, índices de letalidade.

## B.6 igBio() e heurísticas de divergência biométrica

- **Busca dedicada:** nenhuma fonte publicada valida a ponderação cerebelo×3/DBP×2/CC×2/FL×2, nem os cortes de 1/1,5/2/3 semanas usados para classificar a comparação.
- **Decisão original da R14:** removidos a classificação "compatível/aceitável/discordância importante" em `peso()`, o alerta agregado em `coer()` para ≥3 semanas, a cor clínica das IGs individuais em ≥1/≥2 semanas, e o alerta de dispersão ≥1,5 semana.
- **BLOQUEADOR encontrado na revisão externa e corrigido nesta rodada:** mesmo com a cor e o texto "compatível/discordância" neutralizados, o bloco `if(ad>=1){...}` dentro de `peso()` (ramo `!datando`, ou seja, quando a IG já está estabelecida e a biometria só é comparada) continuava usando `ad=|gbComp−g|` para **acionar decisões clínicas reais** no cartão `igbRes`: "Isto é crescimento, não data", "a discordância é alteração do crescimento", "mudar a data aqui apagaria a restrição", comparação com `limiarRedata()` sugerindo ou não redatação, e a recomendação "meça o cerebelo". Isso violava o próprio critério da R14 (zero decisão clínica automática sem proveniência) porque a heurística não validada continuava decidindo.
- **Correção:** neste ramo (`!datando`), o cartão `igbRes` agora é **sempre oculto** (`hide(eb)`), incondicionalmente — `gbComp` nunca mais aciona `limiarRedata()`, nunca mais declara crescimento alterado, nunca mais sugere (ou nega) redatação, nunca mais recomenda medir o cerebelo. `gbComp` continua calculado e exibido só como diferença numérica neutra no cartão `igRes` (texto acima do `igbRes`).
- **Preservado, sem alteração:** o cartão `igbRes` no ramo `datando===true` (quando a IG está sendo estabelecida por HC+FL/`igBioHCFL()`, validado, ISUOG grau B) — ali `gb=gbDat`, não `gbComp`, e o aviso de "gestação subotimamente datada" (ACOG, quando `gb>=22`) permanece intacto, porque não deriva da heurística não validada.
- **`limiarRedata()` e o fluxo de redatação por DUM/US/CCN:** continuam existindo, mas **não recebem mais `gbComp` como gatilho** em nenhum caminho — o gatilho de `ad>=1` que os acionava só existia dentro do bloco removido. Este mecanismo (por dias, ISUOG/ACOG) segue como um sistema válido e à parte, mas **a formulação anterior de que ele era "separado" da heurística não validada estava incompleta** enquanto seu gatilho ainda era `gbComp` — isso foi corrigido removendo o gatilho, não apenas reformulando o texto.
- **Também preservados:** as IGs equivalentes individuais por parâmetro (exibidas de forma descritiva, sem corte clínico) e o texto do laudo "Idade equivalente por parâmetro" (puramente informativo).
- **Status:** APP_HEURISTIC / NÃO VALIDADA — agora sem nenhuma via de acionar decisão clínica.

## B.7 Oligoâmnio — diagnóstico e gravidade por MBV

- **Diagnóstico (corrigido na R14.21):** FEBRASGO, Protocolo nº 43 (2025), *Ultrassonografia obstétrica do terceiro trimestre da gestação* (Femina 2025;53(6):831-5), Tabela 1: oligoâmnio **MBV <2,0 cm** ou **ILA <5 cm** (normal: MBV ≥2 e <8; ILA ≥5 e <24). *Correção:* até a R14.20 este item dizia "MBV ≤2,0 cm" e atribuía o corte ao nº 43 — a Tabela 1 diz "<2".
- **Graduação removida:** "<1 acentuado / 1–2 moderado" sem sustentação em diretriz contemporânea. Chamberlain PF et al. *Am J Obstet Gynecol* 1984;150(3):245-249 usa "decreased"(<1cm)/"marginal"(1-2cm), não "acentuado"/"moderado". FEBRASGO nº 82 (2018, mais antiga) chama de "severo" o MBV ≤1cm — fronteira diferente do baseline antigo (<1).
- **Decisão:** diagnóstico binário mantido; grau automático REMOVIDO.
- **Status:** diagnóstico CONFIRMADO contra a Tabela 1 do nº 43 (R14.21); graduação histórica REMOVIDA por não ser padrão contemporâneo.

## B.8 Polidrâmnio — diagnóstico e gravidade

- **Diagnóstico (corrigido na R14.21):** FEBRASGO nº 43 (2025), Tabela 1: **MBV ≥8,0 cm** ou **ILA ≥24 cm**. A SMFM Consult Series #46 (*AJOG* 2018;219(4):B2–B8, DOI 10.1016/j.ajog.2018.07.016) define do mesmo modo (DVP ≥8 cm ou AFI ≥24 cm): **não há divergência** em 8,00 cm. *Correção:* até a R14.20 o app usava MBV >8 e ILA >25, atribuídos por engano ao nº 43 (que também foi citado com o título errado, "morfológica no segundo trimestre"); a "divergência documentada com a SMFM" registrada aqui deixou de existir.
- **Graduação (R14.22):** SMFM Consult #46, Tabela 2 — MBV 8–11 leve · 12–15 moderado · ≥16 grave; ILA 24,0–29,9 leve · 30,0–34,9 moderado · ≥35 grave (limites inferiores inclusivos: 12,00 já é moderado; 16,00 já é grave; 30,0 já é moderado; 35,0 já é grave). **Fonte autorizada explicitamente pelo usuário** por estar fora da ordem FEBRASGO > CBR > ISUOG (hierarquia atual explicitada pelo responsável em 30/09/2026). A FEBRASGO nº 82 (2018) permanece só como referência histórica: sua tabela de gravidade do ILA começa em 25 cm, portanto **não** sustenta ILA 24,0–24,9 como "leve".
- **Status:** diagnóstico CONFIRMADO (Tabela 1 do nº 43); graduação pela SMFM #46 (fonte autorizada).

## B.9 CF/DBP não pode ser chamado de "normal" (correção de renderer)

- **Achado da revisão externa:** o renderer genérico das taxas escrevia "normal" na frente de toda faixa exibida, inclusive CF/DBP — mas Hohler & Quetel 1981 nunca usa essa palavra, e a estatística do ±8% é indeterminada (ver B.3).
- **Correção:** o array de taxas agora carrega um 6º campo com o rótulo que a própria fonte sustenta: "normal" para CF/CA (Hadlock 1983 publica "normal range" explicitamente) e "faixa publicada" para CF/DBP (sem essa palavra na fonte). O renderer usa esse rótulo em vez de escrever "normal" para todas.
- **Status:** implementação corrigida; nenhuma mudança de dado ou de classificação, só de rótulo.

## B.10 Sequência de deterioração Doppler

- **Referências:** ISUOG Practice Guidelines — diagnosis and management of SGA fetus and FGR. *Ultrasound Obstet Gynecol* 2020. DOI 10.1002/uog.22134. FIGO — best practice advice for FGR. *Int J Gynaecol Obstet* 2021. DOI 10.1002/ijgo.13522.
- **Achado:** as duas diretrizes descrevem **dois fenótipos com padrões diferentes**, não uma escada obrigatória. RCF tardia: "alterations in UA Doppler and venous districts are RARE...MCA-PI...the most important Doppler parameters in the surveillance of late FGR" (ISUOG 2020). RCF precoce: progressão "typically precedes a cascade", como tendência, não regra individual.
- **Decisão:** `sequencia()` reescrita. "Onde está na sequência" → "Territórios hemodinâmicos avaliados". Classe/semântica "pulou" REMOVIDA (achado de ACM/CPR alterado com AU normal é o padrão esperado na RCF tardia, não uma etapa saltada). Frases de precedência obrigatória em `dopplerIntegrado()` suavizadas.
- **Limpeza pós-revisão:** CSS morto da classe `.seq-e.pulou`/`.seq-e.pulou .seq-p` removido; comentário de cabeçalho do bloco CSS atualizado (antes dizia só "sequência de deterioração", sem contexto da renomeação).
- **Status:** CONFIRMADO que não há sequência universal obrigatória, com fonte primária (texto integral das duas diretrizes).

## B.11 Ureter fetal — cortes de 4 e 7 mm

- **Corte de 4 mm:** busca dedicada não encontrou fonte primária para diâmetro ureteral fetal >4mm como corte antenatal. UNKNOWN_ORIGIN.
- **Corte de 7 mm:** BAPU. Farrugia MK et al. Consensus statement on the management of primary obstructive megaureter. *J Pediatr Urol* 2014;10(1):26-33. DOI 10.1016/j.jpurol.2013.09.018. Define ureter >7mm como anormal, mas no **manejo pós-natal** — não transportável para rastreio antenatal.
- **Decisão:** classificação numérica automática REMOVIDA para os dois cortes. Medida em mm agora só descritiva. UTD qualitativo (`eUreUTD`) continua sendo a única classificação clínica formal — intocado.
- **Status:** 4mm UNKNOWN_ORIGIN (removido). 7mm PARCIALMENTE CONFIRMADO (pós-natal/pediátrico) — não transportável, também removido do classificador antenatal.

---
---

# PARTE C — APP_POLICY explícitas (resumo)

| Política | O quê | Por quê |
|---|---|---|
| Gate CF/CA ≥22+0 sem | Hadlock 1983 não define o primeiro dia de "after 21 weeks" | Operacionalização conservadora |
| Gate CF/DBP ≥23+0 sem | Hohler 1981 não define o primeiro dia de "after 22 weeks" | Idem |
| Hierarquia geral de referências | FEBRASGO → CBR → ISUOG; demais fontes complementam lacunas, com atribuição explícita | Instrução atual do responsável; preserve adjudicações e exceções autorizadas |
| Zona 6+2 sem indeterminada (FCF) | Notação semana decimal vs semana+dia ambígua nesse ponto | Doubilet não define |
| Alocação dupla de meia-semana (Silva & Bailão) | Artigo não define arredondamento dos dias | Classifica só quando as duas alocações concordam |
| Bloco de Campbell por `Math.floor(g)`, sem interpolar | Tabela é em blocos de 2 semanas, sem regressão contínua publicada | Evita inventar continuidade |

---
---

# PARTE D — Limitações residuais (declaradas)

- PDFs originais de Campbell 1977, Hadlock 1984 (JUM), Hadlock 1983 (texto completo além dos fragmentos), Hohler 1981 (texto completo) e BAPU 2014 (Tabela 1) não foram obtidos — auditoria feita com resumos e fragmentos de busca.
- Tabela corrigida da OMS/Kiserud para CF/CC não extraída e conferida célula a célula — por isso CF/CC permanece descritivo em vez de migrado.
- Protocolo FEBRASGO específico de Doppler/RCF (se existir) não localizado — a posição do item B.10 apoia-se em ISUOG 2020 e FIGO 2021.
- Posição atual do ACOG sobre graduação de oligoâmnio e a diretriz ISUOG 2024 de esqueleto fetal não obtidas nesta rodada.
- Texto integral de Nguyen 2022 (UTD) sobre cálice central antenatal permanece pendente de acesso institucional (não bloqueia a regra vigente, apoiada na Fig. 1).

# PARTE E — Regras removidas ou rebaixadas nesta R14 (resumo para handoff)

| Regra anterior | Origem alegada | Status real | Ação |
|---|---|---|---|
| CC/CA normal/anormal via interpolação fracionária | "Campbell 1977" | Estatística indeterminada; interpolação não sustentada | Descritivo, por bloco |
| CF/CC faixa fixa 13,30–23,90% | "Hadlock 1984" | Tabela nunca vista fora de manual de equipamento | Removido |
| CF/DBP rotulado "normal" e "90% IC" | "Hohler 1981" | Fonte não usa "normal" nem define a estatística do ±8% | Rótulo corrigido, mantida a faixa |
| CF/CA "típico de insuficiência placentária" | "Hadlock 1983" | Linguagem causal não encontrada na fonte | Descritivo, com sensibilidade citada |
| U/F 0,90–1,10, "rizomélico" | Desconhecida | Sem fonte | Removido |
| igBio 1/2/3/1,5 semanas — cores e alertas clínicos | Desconhecida | Sem fonte; **ainda acionava `igbRes`/`limiarRedata()` até esta correção** | Removido, incluindo o gatilho residual |
| Oligo "acentuado"/"moderado" (MBV) | "convenção histórica" | Fronteiras e rótulos não batem com nenhuma fonte atual | Removido, diagnóstico binário mantido |
| Poli "Manning" 8-12/12-16/>16 | Atribuição nunca auditada | Números batem com SMFM #46, não confirmados em Manning | Atribuição e fronteiras corrigidas |
| Sequência Doppler obrigatória, classe "pulou" | Uso interno do app | ISUOG 2020/FIGO 2021 refutam sequência universal | Reescrita para territórios paralelos |
| Ureter >4mm / >7mm | Convenção auxiliar do app | Sem fonte antenatal (4mm); pós-natal/pediátrica (7mm) | Removidos; UTD qualitativo é a única autoridade |

Este arquivo é a base para o próximo handoff científico (Codex ou outro).

---

# PARTE F — Ciclo R14.1 a R14.11 (pós-freeze da R14)

Esta parte é autocontida: pode ser anexada a qualquer versão consolidada deste documento.
Nenhuma curva, tabela, fonte ou limiar das Partes A–E foi alterado neste ciclo. As mudanças
são de **semântica de saída** (o que pode ou não virar achado, conclusão ou laudo), de
**apresentação** e de **persistência**. Cada item abaixo foi verificado no código antes de
ser implementado, e várias alegações de auditorias externas foram refutadas por não
corresponderem ao arquivo vigente (registradas em F.4).

## F.1 Histórico de versões e integridade

| Versão | SHA-256 | Bytes | Conteúdo |
|---|---|---|---|
| R14 (freeze) | `4821d7fb828b5c5e0f987b0fb2f7115a36f230f142bc4b551f3f093109608cf6` | 448.306 | Baseline científica congelada |
| R14.1 | `c71d4e36c63eb4aafbaee0d03c22dfa8bd65349280af9bda61a51b5003f2af12` | 448.976 | Cartão neutro legível no modo escuro; foco no toque |
| R14.2 | `5c26641d194e86c7dfa24f3feef40f7d3d4eae223136a060e810a1ede75a5399` | 450.142 | Pendências clicáveis; foco do "Próximo pendente" |
| R14.3 | `52260c516e8a836fab0c6bee1b87d3eb1c83566319dc3141e86280dd9e8b04c5` | 451.482 | Mapa das abas; painéis ancestrais; confirmação de troca de referência; data/hora na recuperação |
| R14.4 | `52949077cf665d90b1acf29e801ac217e216dda02bbe2345b29f90298707400a` | 452.010 | Cabeçalho rola; faixa IG/peso/pendências fixa |
| R14.5 | `85dd6708a66e1d4ffdd2a250b1ebadf0121e1e6d906e3b05e777ac9f7dea377e` | 449.700 | Bloco de seguimento morto removido; "Positiva"; comprimento fora da tela clínica |
| R14.6 | `a0e7740c782b749afc51cdace8d7e39e00dae74efbe36aee98dba6124f7cc7a8` | 450.713 | Sem cor por diferença de IG (2º local); sem-referência fora dos achados |
| R14.7 | `ea5deb31815abd3105c8d1270b3a5cae4c9d5b5b835d490b0e3a5f4d203a245d` | 449.421 | Lista morta da leitura biométrica removida; U/F fora da interface |
| R14.8 | `d23aebe5c56312e3524dac8cc8f14d07880a948993f786f2254bc1ac66fabcff` | 450.981 | Doppler grave não mascarado por anemia; comprimento fora do laudo |
| R14.9 | `5c915f8fa21446b61d205450e64a7e4669ccb7db09070e379e97b6d6b3131c36` | 455.570 | Modo Paciente ampliado |
| R14.10 | `8a59841de44f88ef7b5d15c9b2e37e290cbea081bd7a9d4fa9864b9e735a3ba9` | 455.634 | Revisão final: concordância, CSS morto, tabela de referências |
| **R14.11 (histórica)** | `d1ba54b7b39ea87aec30eebc89cf453dcd582ae527dc6463f541002accc5bc85` | 457.627 | Exame salvo carimbado com a versão do motor |

`SCHEMA_VERSION` permaneceu **13** em todo o ciclo (ver F.2.7). Regressão ao fim do ciclo:
golden R14 80/80; suíte histórica sem regressão nova; DV1 200/200 cenários sem divergência;
estado clínico + laudo idênticos à versão anterior em 231 cenários a cada passo sem mudança
clínica intencional.

## F.2 Decisões semânticas e de política (valem para qualquer reimplementação)

### F.2.1 SEM_REFERÊNCIA ≠ achado (R14.6)
Medida existente porém não classificável pela referência ativa (ex.: artérias uterinas
medidas sem via informada, ou fora do domínio da curva) **nunca** entra na síntese de
achados ("achados associados") nem aumenta gravidade. Continua contando só para
**cobertura** ("Doppler foi tentado"). Mesmo princípio de "não avaliado ≠ normal", no
sentido inverso: não classificável ≠ alterado.

### F.2.2 Idade equivalente por parâmetro: nenhuma cor em lugar nenhum (R14.6)
A decisão B.6 (idade equivalente é descritiva, sem corte de 1/1,5/2/3 semanas) só tinha sido
aplicada a um dos dois renderizadores. O segundo, que exibe a idade ao lado de cada campo de
biometria, ainda coloria por limiares escalonados pela IG — removido. A seta ↑/↓ é só
direção. **Exceção legítima:** a linha da CA pode ter cor, mas só pelo percentil validado da
CA (INTERGROWTH-21st): abaixo do p3 → grave; abaixo do p10 ou acima do p97 → atenção. A CA
acima do p97 só aparecia colorida "de carona" na heurística removida; foi religada
explicitamente à fonte validada.

### F.2.3 Gravidade não depende da ordem de avaliação (R14.8)
Na síntese de feto com peso adequado, a anemia (PSV-ACM > 1,5 MoM) era avaliada antes de
diástole zero/reversa na umbilical e ducto venoso alterado, com retorno imediato: quando os
dois coexistiam, a conclusão citava só a anemia. Agora o achado hemodinâmico grave é
sempre avaliado primeiro, e a coexistência gera uma classe própria que **nomeia os dois**
na síntese e na conclusão do laudo. Os casos isolados permaneceram idênticos. A escalada
de gravidade máxima (frase "alta gravidade hemodinâmica") nunca foi afetada, porque lê os
achados brutos.

### F.2.4 Regra do laudo (R14.8)
**Nenhuma informação entra automaticamente no laudo se não estiver visível na interface
clínica.** Aplicação: o comprimento fetal estimado (Vintzileos et al. 1984, auxiliar) saiu
da tela clínica na R14.5 e continuava entrando sozinho no laudo — removido do laudo; segue
calculado apenas para o Modo Paciente.

### F.2.5 Modo Paciente (R14.9–R14.10)
Tela de comunicação. Nada dela entra no laudo ou na síntese.
- **Mostra:** tempo de gestação (meses + semanas e dias), FCF em bpm, peso, comprimento,
  "completa o mês em", data provável do parto com contagem regressiva, concepção.
- **Nunca mostra:** percentil, Doppler, líquido amniótico — números que exigem
  interpretação presencial.
- **Precisão:** peso arredondado a 50 g (erro do método ~10–15%), comprimento ao cm inteiro,
  sempre com "cerca de".
- **Concepção:** estimada como DUM + 14 dias (ciclo de 28 dias presumido); o ultrassom não
  determina a data. **Nunca o dia exato.** Início/meados/fim do mês quando a IG vem de CCN
  ou DUM; só o mês nas demais origens (biometria tardia, exame anterior de trimestre
  desconhecido, IG digitada).
- **Gemelares:** peso, comprimento e FCF por bebê (A/B), sempre na ordem A→B. No 1º
  trimestre a FCF não é registrada por feto → linha oculta em gestação gemelar.
- Linha sem dado fica oculta.

### F.2.6 Proteções de uso (R14.3)
- Troca de referência (curva de peso Hadlock↔INTERGROWTH, TN FMF↔Faria, uterinas
  Gómez↔Cavoretto) **pede confirmação somente se já houver resultado** calculado com a
  referência atual.
- Recuperação de exame com mais de 1 h mostra sempre data e hora explícitas — defesa contra
  confundir com o exame da paciente anterior.

### F.2.7 Versão do motor ≠ versão do formato (R14.11)
`SCHEMA_VERSION` protege o **formato** do exame salvo (incompatível → só descartar). Ele não
muda quando só as **regras** mudam — e as regras mudaram várias vezes com o schema em 13.
O exame salvo agora leva o carimbo da versão do app (`motorV`, fonte única `APP_VERSAO`,
que também alimenta o rodapé). Recuperação em versão diferente: aviso explícito ("salvo na
X · app atualizado para Y — resultados recalculados, revise antes de assinar"), recuperação
**permitida**. Campo opcional e retrocompatível: payload v13 sem carimbo = "versão
anterior"; por isso o schema continua 13.

## F.3 Removidos ou alterados na apresentação

| Item | Versão | Motivo | O que continua existindo |
|---|---|---|---|
| Bloco "seguimento sugerido" | R14.5 | Nunca renderizava (DOM/CSS mortos) | Estado interno, usado na frase de alta gravidade do laudo |
| "Positiva (normal)" na onda A do DV 1º tri | R14.5 | Onda A e IP são leituras independentes | "Positiva" |
| Comprimento fetal na tela clínica / no laudo | R14.5 / R14.8 | Não muda decisão; regra F.2.4 | Só no Modo Paciente |
| Lista de idade por parâmetro no cartão de biometria | R14.7 | Nunca ficava visível | Idade ao lado de cada campo; linha do laudo |
| Razão U/F na interface | R14.7 | Sem faixa auditada; só ocupava linha para dizer isso | Percentil/escore z individual de cada osso |

## F.4 Mantido por decisão explícita (não reabrir sem motivo novo)
- **Média ponderada `igBio`** (heurística interna): mantida por decisão do responsável —
  descritiva, rotulada como sem validação, sem cor e sem nenhuma decisão pendurada nela
  desde a R14. Uma auditoria externa recomendou removê-la; a decisão foi mantê-la.
- **Quadro de territórios hemodinâmicos** na aba Medidas: **não** duplica a leitura
  integrada do Doppler (fica em outra aba e responde a outra pergunta). Alegação de
  duplicação refutada duas vezes contra o código.
- **"Normal" no DV do 1º trimestre quando só a onda A foi avaliada (sem IP):** decisão
  explícita da C3b.2a; módulo DV1 congelado.
- Alegações de auditorias externas que não correspondiam ao código vigente (registro para
  não re-litigar): cor por diferença de IG "ainda ativa" no cartão de proporções (já
  removida na R14 — o problema real era o segundo renderizador, F.2.2); sem-referência
  "no radar" após a R14.6 (já corrigido); feedback háptico (inexistente no arquivo).

## F.5 Validação operacional e autoria dos testes

| Teste | Autoria/executor | Ambiente | Resultado e limite |
|---|---|---|---|
| Worker simulado | Auditor independente; execução Claude | Node | 22/22, resultado preservado do pacote recebido |
| Worker em navegador com set_offline | ChatGPT e Claude, resultados separados | Linux; PW1.58/Chromium153: 10/10; PW1.56/Chromium141: 8/10 | A matriz do ChatGPT reproduziu a dependência do driver; log HTTP mostrou rede ainda acessível pelo worker na simulação 1.56 |
| Worker com transporte interrompido | ChatGPT, auditoria técnica anterior | PW1.56/Chromium141.0.7390.0 e PW1.58/Chromium153.0.8010.0, Linux | 10/10 em cada; não equivale a validar iPhone físico |
| Worker com transporte interrompido — **reexecução nesta integração** | Claude | PW1.56.0/Chromium 141.0.7390.37, Linux; HTML R14.25 + `sw.js` R14.23-SW2 | **10/10** (reproduz o resultado do ChatGPT neste ambiente; explica o 8/10 anterior do Claude, causado pela simulação `set_offline` do driver 1.56) |
| Worker WebKit com transporte interrompido | ChatGPT, auditoria técnica anterior | PW1.58, WebKit headless build 2248, Linux | 10/10; não é Safari/iOS físico |
| Worker com transporte interrompido — **R14.26** | Claude | PW1.56.0/Chromium 141.0.7390.37, Linux; HTML R14.26 + `sw.js` R14.23-SW2 | **10/10** |
| Worker, matriz da auditoria da R14.25 (PW1.56/Chromium 141 e PW1.58/Chromium 153, WebKit headless build 2248, e atualização R14.24→R14.25 com o mesmo worker, 5/5) | ChatGPT, Auditoria_R14_25 | Linux | 10/10 em cada navegador; atualização 5/5. **Relato do auditor: não reexecutado pelo Claude** (exceto a linha PW1.56/Chromium 141 acima, na R14.26) | 
| Worker com transporte interrompido — **R14.27** | Claude | PW1.56.0/Chromium 141.0.7390.37, Linux; HTML R14.27 + `sw.js` R14.23-SW2 | **10/10** |
| Worker com transporte interrompido — **R14.28** | Claude | PW1.56.0/Chromium 141.0.7390.37, Linux; HTML R14.28 + `sw.js` R14.23-SW2 | **10/10** |
| Exibição da discordância (R14.28) em Chromium e WebKit | Claude | Chromium 141.0.7390.37 e WebKit 26.0 (Playwright build 2215), Linux | **0 falhas** nos dois (ver H.4); WebKit no Linux não equivale a Safari/iPhone físico |
| iPhone/Safari físicos e uso clínico real | Nenhuma execução registrada | — | Pendentes operacionais |

Dos resultados de navegador, **foi reexecutado pelo Claude** apenas o worker com transporte interrompido em Chromium 141 (linha acima). **Não foram reexecutados:** a matriz Playwright 1.58/Chromium 153 (com e sem `set_offline`) e o WebKit, que permanecem como relato do ChatGPT. O worker permanece byte a byte: SHA 868972f473094deafe00372b44de52f1e35b2ff15a576d6222d5b39f70fcc840, versão R14.23-SW2. O HTML e o worker têm versões independentes.

## G. Comparação numérica estável nas igualdades dos cortes (R14.24 e R14.25)
- **Problema (achado BND-CA-01 do ChatGPT, reproduzido):** a conversão cm→mm é `v*10` em ponto flutuante, então um valor digitado **exatamente** igual ao corte pode chegar ao comparador como 173,29999… ou 98,10000…1 e virar "abaixo do p3" ou "acima do p90". Exemplo: 24+0 com CA 17,33 cm (= p3 exato) fechava "RCF por CA < p3". Igualdade não satisfaz um critério estrito.
- **Correção:** função `cmpMedida(a,b)` (tolerância `16 × Number.EPSILON × max(1, |a|, |b|)`; é uma tolerância absoluta que cresce com a escala — cerca de 16 ulps para valores de ordem 1, ≈3,6×10⁻¹⁵ até 1 e ≈6×10⁻¹³ em 170 mm —, não um arredondamento) aplicada em 26 comparações: na R14.24, CA (`caPercentil` ×4, `fetoOutro`, `seletiva`), ossos longos (p3, ×2) e DIO (p10/p90, ×2); na R14.25, TN p5/p95 (×2), limites inclusivos da razão CF/CA e CF/DBP (×2) e alerta estrito de CF/CA > 24% (×1), flag de p95 da média das uterinas (×1) e aviso de sensibilidade entre referências (×2); na R14.26, razão PFN/ON ≥ 0,80 (×1), razão CT/CA < 0,80 e < 0,85 (×2) e diferença saco–CCN < 5 mm, por via (×3); na R14.27, limites de 20% e 25% da discordância entre fetos (`discCat`, ×2). Na R14.28, `discFmt()` confere a categoria do número efetivamente exibido (ver H.4). Não arredonda medidas nem percentis; não usa tolerância clínica; operadores seguem estritos; curvas, tabelas e UI inalteradas. `valmm()` **não** foi alterado: a evidência mostra diferenças de representação/interpolação binária dos valores e cortes (tíbia 31+0, 4,77 cm; ulna 27+0, 3,99 cm). Isso não comprova erro científico dos literais publicados; a correção atua na comparação.
- **Varredura dos consumidores de `valmm()`** (metamórfica: saída com conversão ruidosa × conversão decimal exata, todos os decimais de 0,01 a 12 cm — 40 cm na CA): no R14.23 divergiam CA, as cinco ósseas e a DIO (semanas ímpares). A sonda original retornou 0 divergências no recorte executado (CA, úmero, rádio, ulna, tíbia, fíbula, cerebelo, DBO, DIO, cisterna, átrio, prega, osso nasal, PFN, pelve, ureter, bexiga, parênquima, colo, CCN, TN, DMSG), mas não ativou todos os pré-requisitos: TN foi testada sem CCN. Esse resultado não aprova todos os consumidores. O inventário estático tem 24 IDs, incluindo bCC/bFL, e a auditoria adicional ativou os ramos de HC+FL/TN. Limites: IGs de semana completa; o salto interno do `phi` em z = 0 (q = 50,000015 × 49,999985) não muda classe nem texto e foi ignorado.
- **Testes permanentes** (oráculo em frações): CA 108 fronteiras em semanas completas e 192 decimais incluindo dias intermediários; ossos longos; DIO; gemelar (`fetoOutro` e sFGR); na R14.25, TN (1.755 e 4.692), razões CF/CA e CF/DBP (2.448) e uterinas (57.852); na R14.26, consumidores ativos (4.281: PFN/ON, CT/CA, saco–CCN e recortes de parede, prega e CCN/DMSG isolados; autoria ChatGPT, reexecutado pelo Claude). Em cada fronteira: abaixo, igualdade e acima.


## H. Reconciliação técnica de 30/09/2026 — integrada na R14.25

O handoff de 26/09 registra encerramento científico. As verificações recentes procuram erros de implementação e aderência; não redefinem a teoria. As correções desta seção estão **integradas na R14.25 oficial** (SHA-256 `0d7b9c8f773b29577826df286818c9ef3176f9cd77296a4d724cac743e7d23cd`).

- Hierarquia atual (instrução do responsável): **FEBRASGO → CBR → ISUOG**. FMF e demais fontes complementam parâmetros não cobertos; não trocar curvas só para obter outra classe. Exceções previamente autorizadas, como SMFM #46 para graduação do líquido, permanecem documentadas. O texto do overlay de Referências foi alinhado.
- DEC-LONG-001: queda estritamente >50 percentis e intervalo ≥21 dias. Os 21 dias são APP_POLICY de comparabilidade do serviço; não atribuir esse intervalo literalmente ao Delphi. Decisão encontrada no código e testada em 20/21/22 dias e em 49,99/50/50,01 percentis.
- Implementação: comparação estável (`cmpMedida`) também em TN p5/p95, limites e alerta de CF/CA (e CF/DBP), p95 da média uterina e sensibilidade entre referências. Nenhuma curva, tabela, média, corte clínico, unidade, esquema ou `valmm()` foi alterado. Frase óssea na igualdade do p3: “Nenhum abaixo do percentil 3”. Comentário SMFM #46 corrigido para B2–B8.
- Evidência **reexecutada pelo Claude na R14.25** (Linux, Playwright 1.56.0, Chromium 141.0.7390.37): contratos 78/78 e razões 2.448/2.448; uterinas 57.852/57.852; TN 1.755/1.755 e 4.692/4.692; oráculo de interface 104/104; históricos 215/215; varredura 28.080/28.080; v3.1 678/678 (4 inalcançáveis documentados); bateria adicional 3.959/3.959; mutação dirigida 5/5 e mutação de TN 3/3; fronteiras de CA (324 e 576), ossos (210), DIO (39) e gemelar (378); diferencial R14.24×R14.25 (120 fixtures + 160 aleatórios) 280/280 idênticos, exceto a frase óssea intencional; worker com transporte interrompido 10/10.
- **Não reexecutado nesta integração:** mutação histórica (52) e a suíte antiga de 81 casos no baseline R14 do handoff (a evidência existe no pacote do auditor, mas o script não foi fornecido); matriz Playwright 1.58/Chromium 153 e WebKit. iPhone/Safari físicos, implantação/atualização no aparelho e uso clínico real seguem **pendentes**.
- O handoff antigo apresenta MBV ≤2/>8. B.7/B.8 desta referência conservam as correções posteriores R14.21: <2/≥8. A reconciliação não devolve o motor aos limites antigos.

## H.2 R14.26 — auditoria independente da R14.25 e revisão estática dos comparadores derivados (30/09/2026)

- **Origem:** Auditoria_R14_25 (ChatGPT). Três ramos ainda comparavam diretamente o resultado de uma divisão ou subtração: razão PFN/ON (≥ 0,80), razão CT/CA (< 0,80 e < 0,85) e diferença saco–CCN (< 5 mm, por via). Exemplos reproduzidos na R14.25: PFN 0,72 cm / ON 0,90 cm (razão exata 0,80) saía “dentro do esperado”; CT 24,08 / CA 30,10 saía “tórax pequeno”; CT 5,27 / CA 6,20 saía “limítrofe”; DMSG 1,14 / CCN 0,64 dava 4,999999999999998 mm e “saco pequeno”.
- **Correção (R14.26):** seis chamadas de `cmpMedida` (1 PFN/ON, 2 CT/CA, 3 saco–CCN). Operadores vigentes preservados. Nenhuma curva, tabela, cálculo, `valmm()`, UI, campo, schema ou worker alterado. A candidata do auditor (SHA `90609e1d…`) foi reconstruída e a R14.26 (SHA `e2775edb9c4d6bc49513545e59352f6ff906d78cb53b5cd099f4d861e2c6c9c8`) coincide com ela exceto pelas duas linhas de versão.
- **Testes do auditor (autoria ChatGPT), reexecutados pelo Claude sobre a R14.26 (Linux, Playwright 1.56.0, Chromium 141.0.7390.37):** consumidores ativos 4.281/4.281 (na R14.25 eram 3.870 e 411 falhas: PFN/ON 6, CT/CA 297, saco–CCN 108 — repetições de três defeitos, não 411 defeitos); mutação 6/6 sem erro de infraestrutura; reprodução de interface.
- **Reexecutado pelo Claude sobre a R14.26:** contratos 78/78; razões 2.448/2.448; uterinas 57.852/57.852; TN 1.755 e 4.692; oráculo de interface 104/104; históricos 215/215; varredura de diagnóstico 28.080/28.080; v3.1 678/678 (4 inalcançáveis documentados); bateria adicional 3.959/3.959; mutações dirigidas 5/5 e de TN 3/3; fronteiras de CA (324 e 576), ossos (210), DIO (39) e gemelar (378); diferencial R14.25×R14.26 (120 fixtures + 160 aleatórios) 280/280 idênticos — a amostra aleatória não contém as fronteiras novas e **não** prova a correção; worker com transporte interrompido 10/10.
- **Revisão estática dos comparadores derivados (autoria Claude; heurística, não prova).** Três passadas listaram 33 pontos (23 contra literal, 1 contra tabela, 9 com aritmética inline). Nenhum novo defeito de igualdade foi demonstrado; nenhum código foi alterado por essa revisão. Decisões clínicas conferidas: CPR × p5 (o p5 vem da equação de Ciobanu, irracional; menor distância a um par digitável: 7,3×10⁻⁸ em 13,1 milhões de pares); MoM × 1,5 e 1,3 (mediana por equação; menor distância 1,3×10⁻⁵ em 273 mil pares); discordância ≥ 25% (gramas inteiros: 1.451 pares, 0 falhas); domínio do CCN 0,2–12,0 cm (exato nas bordas); CPR com IPs iguais (razão 1,0: 371 pares, 0 falhas); DEC-LONG-001 (percentis irracionais; teste existente em 49,99/50/50,01). Os demais pontos são guardas, rótulos, textos, contadores inteiros ou rolagem de tela. Detalhe por ponto: `REVISAO_ESTATICA_R14_26.md` (no pacote de testes).
- **Limites:** a varredura estática não vê derivações feitas por funções distantes e pode deixar passar comparadores; a sonda `valmm` continua sem ativar todos os pré-requisitos. Não se declara ausência global de defeitos nem varredura global de `valmm()`.
- **Não reexecutado pelo Claude:** matriz Playwright 1.58/Chromium 153 e WebKit, e o teste de atualização R14.24→R14.25 (relato do ChatGPT); mutação histórica (52) e suíte antiga de 81 casos; leitura do Manual Mestre v2.0 e dos Modelos Aprovados v1.0 (não recebidos pelo Claude). iPhone/Safari físicos, implantação/atualização no aparelho e uso clínico real: pendentes.

## H.3 R14.27 — auditoria profunda PIG/GIG/RCF, gestação única e gemelar (01/10/2026)

- **Origem:** Auditoria_Profunda_Fetal_R14_26_Evidencias (ChatGPT; baseline R14.26, SHA `e2775edb…`). Cinco achados (F01–F05). A R14.27 (SHA `bd54755a8a0b2dfce6104f0714f09f3789a10c45494fdc1c1c86f159078a6021`) foi liberada por você com os cinco, com F02 por Φ preciso apenas no caminho do peso.
- **Ponderação das prioridades (posição do Claude, diferente da do auditor em F02):** F01 real e corrigido (peso inválido do outro feto chegava ao classificador). F02 real, mas de relevância clínica muito baixa: o `phi()` (Abramowitz–Stegun com constante truncada) erra até 2,1×10⁻⁵ pontos percentuais; nos quatro cortes o erro é de ±5×10⁻⁶ a ±7×10⁻⁶, o que abre janelas de 4×10⁻⁵ a 2×10⁻⁴ g (cerca de 6 ordens de grandeza abaixo do erro de medida do ultrassom). Estimativa do Claude, com premissas de peso contínuo e ln normal: cerca de 1 exame em 4 milhões. Corrigido por coerência com a limitação já documentada no MICROFIX C0-A, não por urgência clínica; não classificado como P1. F03 real e de baixa relevância (a IG existe na prática; o cartão já mantinha o alerta de gravidade). F04 real (o `var outroId` ficava só no ramo biométrico), sem falso diagnóstico demonstrado (o bloqueio final funciona). F05 real e cosmético; o caso 2000,20 / 1500,15 g está fora do `step=1` do campo.
- **Implementação:** (F01) `fetoOutro()` aplica o gate de `peso()` (finito, 50 a 7000 g, inclusive); o valor recusado fica em `wRecusado` e não entra em discordância nem sFGR. (F02) `phiPreciso()` (série de Maclaurin da erf até x=2 e fração contínua de erfc acima) usado só em `pctPesoFromZ()`; o `phi()` genérico (Doppler, CA, uterinas) segue intocado, assim como a neutralização do ponto nominal. (F03) nova classe `aedf-ig-desconhecida`: sem premissa de forma precoce/tardia, achado de gravidade visível, pede IG válida; o texto usa “limite de 32 semanas da definição Delphi”. (F04) `outroId` declarado antes dos ramos. (F05) `discCat` (comparação estável de 20% e 25%) e `discFmt` (duas casas quando o arredondamento cruzaria o limite; o cálculo segue usando o valor bruto); laudo diz “igual ou acima de 25%”. Não alterados: modelos, SD, domínios, tabelas, `valmm()`, `cmpMedida`, regra >50 pontos e ≥21 dias, política de comparabilidade gemelar, UI estrutural, schema e worker.
- **Contrato de identidade com o handoff R14:** 20 tabelas idênticas; das 30 funções inspecionadas, 28 idênticas e 2 diferentes — `fcfLeitura` (CTI-07, já conhecida) e `pctPesoFromZ` (F02, mudança intencional); 0 ausentes.
- **Reexecutado pelo Claude sobre a R14.27 (Linux, Playwright 1.56.0, Chromium 141.0.7390.37, Node 22):**
  - Bateria nova das correções (autoria Claude; campos reais da interface e oráculos em `erfc`/frações): R14.26 com 297 registros de falha; R14.27 com **0** (F01 110 checagens, F02 2.412, F03 10, F04 9, F05 8). Φ preciso contra `erfc` da libm em 432.001 pontos: erro absoluto máximo 7,5×10⁻¹⁶ e relativo de cauda 5,2×10⁻¹² (o `phi()` antigo: 2,1×10⁻⁷ e 3,6×10⁻³).
  - Oráculo de interface 104/104; históricos 215/215; v3.1 678/678 (4 inalcançáveis documentados); varredura de diagnóstico 28.080/28.080; bateria adicional 3.959/3.959; fronteiras de CA (324 e 576), ossos (210), DIO (39) e gemelar (378); diferencial R14.26×R14.27 (120 fixtures + 160 aleatórios) 280/280 idênticos; worker com transporte interrompido 10/10.
  - Das rodadas anteriores, sobre a R14.27: consumidores ativos 4.281/4.281; razões CF/CA e CF/DBP 2.448/2.448; uterinas 57.852/57.852; TN 1.755 e 4.692; contratos semânticos 78/78; mutações 6/6, 5/5 e 3/3.
  - Testes do auditor (autoria ChatGPT): matriz de interface **2.947/2.947** (R14.26: 2.304); matrizes abstratas 245.760, 86.400, 235.224 e 117.612 sem falha (a lista de extração do harness foi ampliada por 4 nomes — `phiPreciso`, `discCat`, `discFmt`, `n2` — numa cópia, `export_engine_r27.py`; o original foi preservado); mutações dele 18 detectadas e 1 não aplicável (o código `disc>=25` que ela mutava foi substituído); `ui_events`: sFGR nulo nos dois lados e nenhum RCF falso; `invalid_ga` 32/32; `verify_counterexamples` 13/14.
  - Mutação das correções (autoria Claude): 15 mutantes — 13 detectados, 2 equivalentes documentados (gate sem `isFinite`; critério sFGR de discordância cru — equivalência **restrita ao domínio declarado**: discordância formal exige bio×bio, com pesos das equações de Hadlock/INTERGROWTH e entradas decimais; nesse domínio o peso é 10 elevado a um número racional, e a razão exata 3/4 exigiria que log10(3/4) fosse racional, o que é impossível em aritmética exata, logo a igualdade exata de 25% não ocorre. Isso é uma equivalência matemática, não uma garantia sobre o ponto flutuante nem sobre entradas fora do domínio: em ponto flutuante a razão pode cair a ~10⁻¹⁶ do corte, caso em que `discCat()` (comparação estável) e o `>=` cru poderiam diferir), 0 sobreviventes, 0 erros de infraestrutura. Na primeira passada 2 sobreviveram (texto do ramo bio×bio e linha de discordância no guia) por lacuna do meu teste; reforcei o teste e eles passaram a ser detectados.
- **Divergências deliberadas em relação ao auditor (decididas pelo Claude; você pode revertê-las):**
  1. O check `ST.disc.v ≥ 25` do caso 2000,20 / 1500,15 g e a grade numérica de discordância medida no **valor bruto** (111.938 falhas, inalterado) não são satisfeitos: o bruto 24,999999999999996 foi preservado, pois o auditor pede para não arredondar medidas. A decisão por **categoria**, na mesma grade exata (346.417 pares, 20% e 25%, com 0, 1 e 2 casas), dá 0 falhas.
  2. Bateria numérica de pesos (17.734 checagens, oráculo Decimal): R14.26 com 3.351 falhas; R14.27 com 44, nenhuma em gramas inteiros, em 0,01 g ou em 1×10⁻⁴ g. As 44 estão no recorte de 1×10⁻⁶ g. **Correção (R14.28):** a distância máxima ao corte é 4,738×10⁻⁸ g (≈ **47,4 ng**; Hadlock, 39+0, p97, entrada 4304,237291 g, corte 4304,237290952624 g; o app devolve q=97 embora a entrada esteja ligeiramente acima) e a mínima 1,4×10⁻⁹ g. A afirmação anterior, “entre 1 e 8 nanogramas”, era uma extrapolação minha a partir dos cinco primeiros exemplos, e foi corrigida pela leitura das 44 ocorrências. O mecanismo é o `snap` nominal preexistente (|z−Z|<1×10⁻¹⁰, ou seja, ≈ 1,2×10⁻¹¹ do peso em termos relativos, que cresce com o peso em gramas), e não a aproximação antiga de Φ; ele não foi alterado para não ampliar o escopo liberado. É uma política microscópica documentada, não prova de comparação estritamente matemática para todas as entradas reais.
  3. **F03 criou um estado novo** (`aedf-ig-desconhecida`), com ramificação própria no cartão e no laudo; não foi uma troca lexical. Só depois, e como ajuste separado, a redação desse estado foi reescrita para não conter “a partir de 32” (critério lexical do auditor, evitando leitura como premissa).
- **Não reexecutado pelo Claude:** WebKit; as buscas dirigidas de 2.770.347 e 752.874 combinações (os três testemunhos de percentil e o longitudinal foram reproduzidos individualmente); a leitura dos PDFs da ISUOG citados; as capturas de tela; a mutação histórica (52) e a suíte antiga de 81 casos. iPhone/Safari físicos, implantação/atualização no aparelho, uso offline no aparelho e validação clínica seguem **pendentes**.
- **Limites:** o auditor e o Claude escreveram os seus oráculos; independência da implementação não equivale a revisão por um segundo autor. Os testes cobrem espaços finitos; não há prova formal global nem enumeração de todas as entradas e ordens de interação.

## H.4 R14.28 — conclusão de F05 da R14.27 e correções documentais (01/10/2026)

- **Origem:** Auditoria_R14_27_Evidencias (ChatGPT; baseline R14.27, SHA `bd54755a…`). F01–F04 confirmados como corrigidos; F05 com lacuna residual: `discFmt()` passava de inteiro para 2 casas sem conferir se o arredondamento de 2 casas voltava a cruzar o corte. Testemunhos do auditor (IG 30+0, dicoriônica, Hadlock, bio×bio; A: DBP/CC/CA/CF = 7,80/28,50/26,00/5,80 cm): B = 7,00/26,00/22,62/5,96 dá bruto 19,996547704250155% (exibido “20,00%” com “dentro do esperado”); B = 7,00/26,00/22,00/5,81 dá 24,99766227413156% (exibido “25,00%” com “risco”). Reproduzidos pelo Claude em Chromium 141 antes da correção, no cartão, no corpo e na linha do guia, nas duas orientações A/B.
- **Posição do Claude:** a categoria sempre esteve correta; o defeito era só de apresentação. A estimativa grosseira do Claude (premissa: 1 a 2% dos gemelares por ponto percentual perto de 20–25%) é de cerca de 1 em 5.000 a 10.000 gemelares, bem mais frequente que F02, o que justifica corrigir; não é frequência medida. A lacuna foi do próprio Claude: tratou o sintoma (inteiro) e não o invariante (“o número exibido nunca cruza a categoria”).
- **Implementação (decisão do responsável):** `discFmt()` tenta inteiro, depois 2, 3 e 4 casas e aceita a primeira representação cujo **número final exibido** permaneça na mesma categoria de `discCat(valor bruto)`; se nenhuma servir, mostra “<20%” ou “<25%” conforme a categoria. Acima do corte o arredondamento é monótono e nunca cai abaixo dele. Preservados: cálculo bruto, `discCat()`, F01–F04, `cmpMedida`, `valmm()`, curvas, critérios, UI, schema e worker. Não incluídos: rótulos de percentil de peso perto do corte (observação do Claude, item opcional não liberado).
- **Reexecutado pelo Claude (Linux; Playwright 1.56.0; Chromium 141.0.7390.37; WebKit 26.0 / Playwright build 2215, instalado nesta rodada; Node 22):**
  - Bateria nova de exibição (autoria Claude; `r28_f05_exibicao.py`; oráculo Decimal independente): R14.27 com 9.978 registros de falha; R14.28 com **0 em Chromium e 0 em WebKit** (testemunhos A/B 4 checagens, abaixo/igual/acima em gramas inteiras 32, grade de 45.098 valores brutos perto de 20% e 25% com verificação de categoria, precisão mínima e fallback, e fallback ponta a ponta com cartão, corpo, guia e simetria A/B 6).
  - Mutação do `discFmt()` (autoria Claude): 10 mutantes, 10 detectados, incluindo a remoção da verificação final da categoria (N01) e a verificação sobre o valor bruto em vez do exibido (N03); 0 sobreviventes; 0 erros de infraestrutura.
  - Regressões: oráculo de interface 104/104; históricos 215/215; v3.1 678/678 (4 inalcançáveis); varredura 28.080/28.080; bateria adicional 3.959/3.959; bateria F01–F05 da R14.27 (110, 2.412, 10, 9 e 8 checagens) com 0 falhas; Φ preciso contra `erfc` 432.001 pontos (erro absoluto 7,5×10⁻¹⁶); fronteiras de CA (324 e 576), ossos (210), DIO (39) e gemelar (378); diferencial R14.27×R14.28 280/280 idênticos (a amostra aleatória não contém as fronteiras novas; não prova a correção); worker com transporte interrompido 10/10; consumidores 4.281, razões 2.448, uterinas 57.852, TN 1.755 e 4.692, semântica 78, mutações 6/6, 5/5 e 3/3. Contrato de identidade: 20 tabelas idênticas, 28/30 funções idênticas; diferem `fcfLeitura` e `pctPesoFromZ` (F02, intencional).
  - Pacote do auditor (autoria ChatGPT; reexecutado pelo Claude nos ambientes acima, com o HTML R14.28 no lugar do baseline): matrizes abstratas 245.760, 86.400, 235.224 e 117.612 sem falha; bateria numérica de pesos com as mesmas 44 neutralizações nominais (0 em gramas inteiras, 0,01 g e 1×10⁻⁴ g); discordância por categoria 0 falhas em 346.417; mutações dele 19/19; matriz de interface 2.947/2.947 em Chromium e em WebKit; `invalid_ga` 32/32 em ambos; gravidade e estado 9.225/9.225 (Chromium); `verify_counterexamples` 13/14 em ambos (o check residual exige o valor **bruto** `ST.disc.v ≥ 25`, preservado por design); `display_probe` mostrando “19,997%” e “24,998%”, com as categorias corretas, nas duas orientações e nos dois navegadores.
- **Três correções documentais (feitas nesta versão):** (1) o residual máximo das neutralizações nominais é ≈ 47,4 ng, não “1 a 8 ng” (ver H.3); (2) F03 criou o estado novo `aedf-ig-desconhecida`, não foi uma troca lexical (ver H.3); (3) a equivalência do mutante M14 vale só no domínio declarado e em aritmética exata, e deve ser distinguida do comportamento em ponto flutuante (ver H.3).
- **Não reexecutado pelo Claude:** Chromium 153 e WebKit build 2248 do auditor (usei Chromium 141 e WebKit 26.0 / build 2215); o `severity_and_state` em WebKit (o script é só Chromium); a mutação histórica (52) e a suíte antiga de 81 casos; as buscas dirigidas de 2.770.347 e 752.874 combinações; a leitura dos PDFs da ISUOG; Manual Mestre e Modelos Aprovados (não recebidos). iPhone/Safari físicos, atualização/uso offline no aparelho e validação clínica seguem **pendentes**; WebKit no Linux não equivale a Safari/iPhone.
- **Limites:** auditor e Claude escreveram os seus próprios oráculos; os espaços testados são finitos; nenhuma contagem prova ausência universal de defeitos.
