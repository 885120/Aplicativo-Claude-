# Dossiê científico — Calculadora Doppler Obstétrico (R14.40)

Material de 06/10/2026, atualizado em 10/10/2026, para revisão, auditoria ou estudo por outro assistente de IA (ChatGPT, Codex) ou por pessoas. Responsável clínico: Dr. Diogo S. Ribeiro (CRM 5789-AL).

Funde e substitui o dossiê de Claude R14.28 (03/10/2026) e o dossiê consolidado do ChatGPT (06/10/2026), já com a revisão Q1–Q8, a investigação científica, a recuperação documental e o adendo de busca seletiva, todos conferidos no código, e registra as mudanças da R14.33 à R14.40 e os pentes finos de 06/10 e 10/10/2026.

**Versão descrita: R14.40.** `index.html` SHA-256 `d5a9931092acab63cb59f95418f8992d7e9ca0d5591cdd10fb0863d926cfd0f5` (542.589 B), SCHEMA_VERSION 14. Worker `sw.js` R14.23-SW2, SHA-256 `868972f473094deafe00372b44de52f1e35b2ff15a576d6222d5b39f70fcc840`. Última publicação confirmada: R14.35 (07/10/2026). Em 10/10/2026 os arquivos foram excluídos do GitHub e o site ficou em 404; a R14.40 ainda não foi publicada. Se você recebeu outro HTML, confira o hash antes de usar este material. O HTML não está neste pacote.

## Arquivos e ordem de leitura

| Arquivo | Conteúdo |
|---|---|
| `01_ESTADO_CIENTIFICO_R14_40.md` | **Comece aqui.** Correções desta fusão, estado de cada módulo com fonte, DOI, tipo de acesso e conferência no código, mudanças da R14.33, o que ainda falta definir e documentos que faltam. |
| `02_TEORIA_DO_APP_R14_40.md` | Toda a teoria que o app exibe, extraída literalmente do HTML da R14.35, com adendo do que mudou até a R14.40, e os avisos clínicos condicionais do motor que estão em discussão. |
| `03_DECISOES_E_CONTEXTO_R14_40.md` | Decisões fechadas, armadilhas, bugs que não podem voltar e histórico até a R14.40 (é o `CONTEXTO.md` do repositório). |
| `04_REFERENCIAS_BASE_R14_28.md` | Cadeia de proveniência de cada tabela e regra até a R14.28, com adjudicações. Para o que mudou depois, vale o `01`. |
| `05_AUDITORIA_FILA_HERDADA_R14_35.md` | Auditoria de todos os itens herdados do CONTEXTO de 17/09: dois erros demonstrados (corrigidos na R14.34), um suspeito descartado, ajustes de documentação e o que já estava resolvido. |
| `06_PENTE_FINO_R14_35.md` | Pente fino geral da R14.34 (integridade, regressão, exames simulados, textos, fontes, documentação) e o que entrou na R14.35. |
| `07_MUDANCAS_E_PENTE_FINO_10_10_2026.md` | Mudanças de 10/10/2026 (R14.36 a R14.40): uterinas, interface, tamanho do bebê, com hashes, fontes e testes; pente fino da R14.39. |
| `MATRIZ_PENDENCIAS.csv` | Pendências por prioridade, já reconciliadas. |
| `DOSSIE_COMPLETO_R14_40.md` | Os arquivos acima num só, para anexar de uma vez. |
| `anexos/revisoes_chatgpt/` | Revisão Q1–Q8 e adendo de busca seletiva (PDFs originais). |
| `anexos/investigacao/` | Investigação original e recuperação documental: tabelas das fontes em CSV, scripts de cálculo, registro de acesso, PDFs FEBRASGO e SMFM, Table S1 de Ciobanu. |
| `anexos/regras_e_modelos/` | Manual Mestre v2.0, Modelos Aprovados de laudo, contratos do laudo e decisões históricas. |

Precedência em caso de conflito: código da R14.40 > `07` > `01` > `03` > `04` > anexos. Os anexos são registros históricos de cada rodada; onde contradizem o `01`, a correção está na seção 1 do `01`.

## Regras para quem usar este material

1. **Hierarquia de fontes: FEBRASGO → CBR → ISUOG**, confirmada pelo médico em 06/10/2026. SMFM, RCOG, FMF, INTERGROWTH e artigos originais complementam lacunas, com atribuição explícita. Documentos antigos com outra ordem estão superados.
2. **Não reabrir decisões fechadas** sem evidência primária nova: equação de Hadlock 1991 (C0-A); equações de Ciobanu 2019; queda > 50 percentis com intervalo ≥ 21 dias; tamanho fetal por PFE + CA; discordância gemelar com valor bruto e decisão por categoria; cortes de líquido; regra UTD pré-natal.
3. **Separar fato de inferência.** Marcar se a afirmação vem do texto integral, do resumo, de reprodução secundária, de cálculo ou de dedução. Dizer "não acessei" quando for o caso. Relato de outra IA não é fonte científica nem substitui execução.
4. **Proponha, não aplique.** Nenhuma alteração no app sem liberação explícita do médico.
5. **Confirme cada achado no código presente** antes de tratá-lo como defeito. Auditorias anteriores já descreveram bugs inexistentes, e esta fusão corrigiu três afirmações que o código desmentia (`01`, seção 1).
6. **Não há validação clínica formal.** Quantidade de testes ou de artigos não prova ausência de defeitos.
7. **Não alterar sem decisão fundamentada:** `valmm()`, `cmpMedida()`, curvas, operadores clínicos, valores brutos, estados incompletos, schema, worker e interface.

## O que pede atenção primeiro

- **Publicar a R14.40** (site em 404 desde 10/10/2026, 13:56) e testar em iPhone físico.
- D3 (zoom bloqueado): só com teste no aparelho.
- Documentos ainda não obtidos (`01`, seção 4); nenhum muda o app hoje.
