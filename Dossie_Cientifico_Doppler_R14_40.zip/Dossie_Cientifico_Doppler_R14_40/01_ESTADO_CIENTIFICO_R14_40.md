# Estado científico consolidado — Calculadora Doppler Obstétrico R14.40

Data: 06/10/2026, atualizado em 10/10/2026. Responsável clínico: Dr. Diogo S. Ribeiro (CRM 5789-AL).
Baseline atual: `index.html` **R14.40**, SHA-256 `d5a9931092acab63cb59f95418f8992d7e9ca0d5591cdd10fb0863d926cfd0f5` (542.589 B). De R14.36 a R14.40 (10/10/2026): via das uterinas, barrinha por lado, incisura por quadradinho, interface, tamanho do bebê para a paciente e limpeza; detalhes, hashes e testes no `07`. Baseline anterior: `index.html` R14.35, SHA-256 `47b3d14c74c611dd1fc44ee7b2e6a58700d856f6bc13cdb96edcd8d43879dbc4` (528.726 B). A R14.35 corrigiu a exibição de valores perto dos cortes e a citação do colo como achado materno (`06`). Antes dela, R14.34, SHA-256 `4152a23438e546b7588abc760324e8b5733c80399e4fd635ab9fe58c6e26cb74`: a R14.34 corrigiu as janelas de IG do osso nasal e da tricúspide (auditoria da fila herdada, `05`). Antes dela, R14.33, SHA-256 `bef7664b14e26820268055a8c730959b9c92856522f6b2e39759e0867c112a24`. A R14.33 aplicou, com liberação do médico em 06/10/2026, as seis propostas que a versão anterior deste arquivo trazia para a R14.32 (seção 3).

Este arquivo funde e substitui, no que se refere à parte científica:

1. o dossiê de Claude R14.28 (03/10/2026);
2. a revisão Q1–Q8 do ChatGPT (`Revisao_Cientifica_R14_32_Q1_Q8.pdf`) e a investigação com tabelas e scripts (`Investigacao_R14_32`);
3. o dossiê consolidado do ChatGPT (`Dossie_Consolidado_R14_32_2026_10_06`), com a recuperação documental de Ciobanu S1 e dos PDFs FEBRASGO;
4. o adendo de busca seletiva do ChatGPT de 06/10/2026 (`Adendo_Busca_Seletiva_R14_32.pdf`);
5. a conferência de cada achado no código da R14.32 e uma busca própria, feitas por Claude em 06/10/2026;
6. as mudanças da R14.33 e seus testes;
7. as mudanças de 10/10/2026 (R14.36 a R14.40) e o pente fino da R14.39 (`07`).

**Hierarquia de fontes, confirmada pelo médico em 06/10/2026: FEBRASGO → CBR → ISUOG.** SMFM, RCOG, FMF, INTERGROWTH e artigos originais complementam lacunas, com atribuição explícita. Para conferir uma equação vale a publicação que a criou.

Qualquer mudança além do que está descrito como aplicado depende de liberação explícita do médico.

## Legenda do tipo de evidência

| Marca | Significado |
|---|---|
| INTEGRAL | texto completo da fonte primária lido |
| RESUMO | só o resumo ou a página editorial foi lido |
| SECUNDÁRIA | reprodução por terceiros (planilha, outro artigo, contrato interno) |
| CÁLCULO | conta independente feita por Claude ou pelo ChatGPT, com oráculo próprio |
| CÓDIGO | conferido por Claude no HTML (R14.32 para o diagnóstico; R14.33 para o que mudou) |
| RECEBIDO | afirmado em relatório de outra IA e ainda não conferido por Claude |
| INFERÊNCIA | conclusão de quem analisou, não da fonte |

---

## 1. Correções feitas nesta fusão

Estas correções resolvem contradições entre os materiais recebidos. Onde um documento anterior diz outra coisa, vale o que está aqui.

**1.1 Hadlock 1991 não é decisão pendente.** O código registra a **DECISÃO C0-A**: percentil pela equação original em ln(PFE), σ ln = 0,12; a Tabela 1 impressa fica só como referência histórica (CÓDIGO: comentário de `HADLOCK_SD_LN`, ajuda do cartão de peso e aviso exibido quando o percentil é < 20). Ficam corrigidos: o resumo de Claude que dizia que a escolha "nunca foi adjudicada na linha R14", e a `MATRIZ_PENDENCIAS.csv` e a seção 11 do consolidado do ChatGPT, que a listavam como P1. A diferença numérica entre equação e tabela continua documentada (seção 2.2); o que saiu foi a ideia de que exista uma decisão a tomar.

**1.2 Aviso de Hadlock na tela: números corretos, atribuição a conferir.** O resumo de Roberts et al. (AJOG 2025, DOI 10.1016/j.ajog.2025.03.032) confirma os 176.060 exames e o subdiagnóstico de 5,1% citados pelo app (RESUMO). A frase "p10 pela equação ≈ p16–17 da tabela" **não aparece nesse resumo**. Ela é compatível com Adu-Bredu et al. (BJOG 2026, DOI 10.1111/1471-0528.70296), cujo resumo diz que o p10 da equação corresponde ao p17 da tabela, numa coorte de 35+0 a 36+6 semanas e com reanálise funcional da tabela (RESUMO). O cálculo de Claude com interpolação normal da Tabela 1 dá cerca de p14,5 em todas as idades de 10 a 40 semanas (CÁLCULO). Conclusão: o valor depende do método usado para interpolar a tabela. Isso corrige a afirmação de Claude em 06/10 de que "o número da tela pode estar errado": ele é defensável, mas a atribuição está provavelmente no artigo errado.

**1.3 PSV-ACM: o aviso após 35 semanas já existe.** A R14.32 já avisa sobre falso-positivo a partir de 35 semanas, mas só quando a PSV está alta ou limítrofe (CÓDIGO). A proposta anterior de Claude de "criar aviso a partir de 35 semanas" fica substituída pela da seção 3.

**1.4 Colo: parte do problema já estava resolvida.** O rótulo "limítrofe" de 26–30 mm só aparece antes de 24 semanas, e a conduta terapêutica automática foi retirada (C0-C1E-05) (CÓDIGO). Continua em aberto o uso de "curto" e "muito curto" em qualquer IG (seção 2.9).

**1.5 INTERGROWTH: o app já troca fórmula e curva juntas.** Com a curva INTERGROWTH o peso passa a ser o Hadlock de 3 parâmetros, e a faixa é 18–41 semanas, alinhada à política do consórcio de outubro de 2025 (CÓDIGO). A planilha oficial aceita até 294 dias (42+0), o que contradiz a própria instrução; isso não deve ser copiado para o app.

**1.6 Testes da R14.32 e da R14.33 foram executados.** O consolidado do ChatGPT diz que a interface da R14.32 não foi reexecutada. Ela foi, por Claude, em 05–06/10/2026: suíte de regressão com 48.184 checagens e 0 falhas em Chromium e WebKit, e teste dos rótulos com 740 checagens e 0 falhas. A R14.33 passou na mesma suíte (48.184/0 em Chromium e WebKit) e no teste das mudanças (278/0; a R14.32 falha 104 dessas checagens). Continua sem teste o iPhone/Safari físico, com atualização e uso offline. WebKit no Linux não substitui o aparelho.

**1.7 Identificação da FEBRASGO de líquido.** "Nº 43" sozinho é ambíguo. Citar pelo título, "Ultrassonografia obstétrica do terceiro trimestre da gestação", Femina 2025, DOI 10.61622/0100-7254536202507, Tabela 1 p. 833. Os cortes de líquido do app foram corroborados e não mudam.

**1.8 Hierarquia.** Documentos antigos (CONTEXTO de 17/09, REFERENCIAS(5), handoff R14.11) trazem FEBRASGO → ISUOG → Rumack → CBR/SBR. Vale FEBRASGO → CBR → ISUOG, confirmada pelo médico em 06/10/2026.

---

## 2. Estado por módulo

### 2.1 Peso estimado — Hadlock 1985

- **Implementado (CÓDIGO):** `hadlock4` (DBP, CC, CA, F) é o padrão; `hadlock3` (CC, CA, F) é usado com a curva INTERGROWTH. Medidas em cm, peso em g, log10.
- **Fonte:** Hadlock FP, Harrist RB, Sharman RS, Deter RL, Park SK. AJOG 1985;151(3):333–337. DOI 10.1016/0002-9378(85)90298-4. Tabela II, p. 334. INTEGRAL (cópia universitária pública, lida pelo ChatGPT; o download local falhou, então não há hash do PDF).
- **Conferência:** coeficientes iguais aos do artigo; 120 comparações aritméticas sem divergência (CÁLCULO, adendo de 06/10). Claude conferiu os coeficientes no HTML (CÓDIGO).
- **Estado: CONFIRMADO.** Os rótulos "Hadlock 1/2/3/4" variam entre aparelhos; identificar sempre pelas medidas usadas.
- **Nota prática:** "Hadlock de 4 medidas" no aparelho é esta mesma fórmula. Isso não diz qual curva o aparelho usa para o percentil (seção 2.2).

### 2.2 Percentil de peso — Hadlock 1991

- **Implementado (CÓDIGO):** ln(PFE) = 0,578 + 0,332·IG − 0,00354·IG², σ ln = 0,12; Φ de dupla precisão (`phiPreciso`, R14.27); domínio 10 a < 41 semanas. Decisão C0-A.
- **Fonte:** Hadlock FP, Harrist RB, Martinez-Poyer J. Radiology 1991;181:129–133. DOI 10.1148/radiology.181.1.1887021. Equação na p. 131 e Tabela 1 na p. 130. INTEGRAL (investigação do ChatGPT).
- **Conferência:** modelo, σ e medianas (670, 1.210, 1.953, 2.813 e 3.619 g) batem com o artigo. Os percentis da equação **não** reproduzem a Tabela 1. Exemplos: p10 em 32 semanas, 1.674 g pela equação × 1.621 g pela tabela; em 40 semanas, 3.103 × 3.004 g; p3 em 40 semanas, 2.888 × 2.714 g. Comparação de 155 células (CÁLCULO).
- **Anomalia da Tabela 1:** o p97 de 30 semanas (1.649 g) é menor que o p90 (1.824 g). Não copiar a tabela sem revisar consistência.
- **Literatura recente:**
  - Roberts et al., AJOG 2025 (RESUMO): equação e tabela não são a mesma referência; usar a tabela subdiagnosticaria restrição em 5,1% de 78.660 pacientes; se se deseja maior detecção, preferir a equação.
  - Adu-Bredu et al., BJOG 2026 (RESUMO): p3 e p10 da tabela equivalem aproximadamente a p1 e p6 da equação; o p10 da equação equivale ao p17 da tabela. Resumo confirmado por Claude em 06/10/2026: em 21.874 gestações de 35+0 a 36+6 semanas, 7,2% abaixo de p10 pela equação × 4,2% pela tabela. Os números de p3 (2,3% × 0,8%) vieram da revisão do ChatGPT (RECEBIDO).
  - Estudo de Cambridge na AJOG (RESUMO, repositório institucional): perto do termo, o percentil de Hadlock discriminou melhor os extremos de peso ao nascer que o INTERGROWTH.
  - Alerta NHS/RCOG de 10/12/2025 (PRN02254) contra curvas de peso INTERGROWTH, por identificarem menos fetos pequenos (RECEBIDO; Claude não abriu o documento).
  - Revisão comparativa de diretrizes de RCF na AJOG (abril de 2026, RESUMO): a escolha da curva de crescimento continua entre os pontos sem consenso internacional.
- **Aviso na tela (R14.33):** 176.060 exames e 5,1% das pacientes atribuídos a Roberts 2025; p10 da equação ≈ p17 da tabela atribuído a Adu-Bredu 2026, com a ressalva de que depende do método de interpolação. Na tela de referências entrou a nota sobre o alerta do NHS England divulgado pelo RCOG em dezembro de 2025 (verificado por Claude em fontes secundárias: os serviços ingleses deveriam deixar as curvas de peso INTERGROWTH até 31/03/2026, sem curva substituta definida no alerta; parte dessas fontes é do Perinatal Institute, que desenvolve a curva GROW, então há conflito de interesse).
- **Estado: DECIDIDO (C0-A), com diferença entre referências documentada.** A equação é a opção que detecta mais fetos pequenos, e é a escolhida.
- **Teste opcional no aparelho**, só para explicar divergências entre o laudo do aparelho e o app: IG 32+0 com PFE ≈ 1.650 g. Se o aparelho mostrar p8, ele usa a equação, igual ao app; se mostrar p11–12, usa a tabela.

### 2.3 Curva alternativa — INTERGROWTH-21st (2020)

- **Implementado (CÓDIGO):** `ig21Lambda`, `ig21Mu`, `ig21Sigma`, `ig21Z`; IG de 18 a 41 semanas; fórmula de peso trocada para Hadlock de 3 parâmetros; a troca vale só para o exame em curso.
- **Fontes:** Stirnemann J, Salomon LJ, Papageorghiou AT. UOG 2020;56:946–948. DOI 10.1002/uog.22000. Manuscrito aceito, Table S1, script R e planilha oficial: INTEGRAL. Política de idade gestacional do consórcio, outubro de 2025: INTEGRAL (recomenda 18–40 semanas e permite até 41 quando clinicamente justificado).
- **Conferência (CÁLCULO, adendo de 06/10):** 486/486 parâmetros LMS, 162/162 medianas e 810/810 quantis concordam com o HTML; diferença máxima de Z na ordem de 10⁻¹³.
- **Estado: CONFIRMADO** para equações e associação com a fórmula. A Table S2 impressa não foi obtida; não se afirma concordância célula a célula com ela.

### 2.4 Doppler fetal — Ciobanu 2019 (AU, ACM, RCP)

- **Implementado (CÓDIGO):** equações da Table S1, IG em dias; mediana da AU linear no IP; ACM e RCP em polinômio log10; dispersões em log10.
- **Fonte:** Ciobanu A, Wright A, Syngelaki A, et al. UOG 2019;53:465–472. DOI 10.1002/uog.20157. Table 2 p. 468 e Table S1. INTEGRAL; S1 recuperada (DOCX, SHA-256 `462701e98e87380826d9f86e3497636abf3af595a7553e7ac9c9136d2c433ffb`).
- **Conferência:** as linhas da Table 2 são semana + 3 dias, não + 0. Comparando na mesma idade em dias (198 comparações), o app difere da tabela em no máximo 0,0006 (AU), 0,0043 (ACM) e 0,0019 (RCP); todas as diferenças relativas ficam abaixo de 0,25% (CÁLCULO, Claude e ChatGPT). Irrelevante com IP medido com duas casas.
- **Estado: FECHADO — manter as equações.**
- **Pendente (documental):** carta de DeVore (UOG 2021;57:349–350, DOI 10.1002/uog.23578, com Appendix S1 em planilha) e réplica de Wright, Wright e Nicolaides (UOG 2021;57:350–351, DOI 10.1002/uog.23579). Sem acesso ao texto em nenhuma das buscas, inclusive a de Claude em 06/10. Não atribuir aos autores preferência por equação ou tabela.

### 2.5 Crescimento seriado — queda > 50 percentis e intervalo ≥ 21 dias

- **Implementado:** queda > 50 pontos percentílicos é critério contributivo de RCF tardia; o app só a interpreta automaticamente entre exames separados por ≥ 21 dias.
- **Fontes:** Gordijn SJ et al. UOG 2016;48:333–339, DOI 10.1002/uog.15884, Tabela 6 p. 338 (critério > 2 quartis, sem intervalo definido). Salomon LJ et al., ISUOG 2019, UOG 2019;53:715–723, DOI 10.1002/uog.20272, p. 717: intervalo entre exames tipicamente de pelo menos 3 semanas, para reduzir falso-positivo. RCOG Green-top 31 (Morris RK et al., BJOG 2024;131:e31–e80, DOI 10.1111/1471-0528.17814), seção 7.2.1: intervalo mínimo de 14 dias, com preferência de 21–28 dias para velocidade de crescimento. INTEGRAL pelo ChatGPT; RECEBIDO para Claude.
- **Estado: PRESERVADO como APP_POLICY** de comparabilidade, não como texto literal do Delphi e não como frequência de vigilância. A citação da ISUOG 2019 entrou no cartão de velocidade e na tela de referências (R14.33).

### 2.6 Artérias uterinas

- **Implementado (CÓDIGO):** a via é explícita (`VIA_UT`, nunca inferida pela IG); desde a R14.36 cada exame novo começa em **transabdominal** (decisão do médico), com aviso para confirmar a via no 1º trimestre enquanto ela não for tocada. O app recusa classificar quando curva, via e IG são incompatíveis (`utRefCompativel`). Quem classifica é o **IP médio** (C0-B2); a barrinha por lado (R14.36) é só de consulta. Incisura por lado: marcado = presente; desmarcado com IP do lado = ausente; o laudo cita só a presença (`07`, seção 1).
- **Fontes:** Gómez O et al. UOG 2008;32:128–132, DOI 10.1002/uog.5315 (transvaginal 11–14 semanas, transabdominal 15–41). Cavoretto PI et al. UOG 2023;61:474–480, DOI 10.1002/uog.26092, Table 3 p. 478 (transabdominal 10+0–39+0). 42 valores conferidos (CÁLCULO, ChatGPT). Bhide A et al., ISUOG 2021, UOG 2021;58:331–339, DOI 10.1002/uog.23698 (técnica).
- **Estado: CONFORME.** Nenhuma diretriz FEBRASGO, CBR ou ISUOG acessada impõe uma das duas curvas. O destaque editorial da ISUOG de abril de 2023 sobre Cavoretto pede validação externa e não é recomendação normativa.

### 2.7 PSV da artéria cerebral média

- **Implementado (CÓDIGO, R14.33):** mediana `exp(2,31 + 0,046·IG)`; ≥ 1,5 MoM elevada; 1,3 a < 1,5 limítrofe, rotulada como faixa de atenção do app; a partir de 35 semanas, PSV alta ou limítrofe gera aviso de falso-positivo (inclui pós-transfusão) e PSV normal gera aviso de que não exclui anemia; fora de 15+0–40+6 a PSV é registrada, mas não interpretada, e o texto separa o cálculo até 40+6 da validação de 15–36 semanas. Cortes e fórmula não mudaram.
- **Fontes:**
  - Mari G et al. NEJM 2000;342:9–14, DOI 10.1056/NEJM200001063420102: fórmula e limiar confirmados; a coorte diagnóstica foi de **15 a 36 semanas** (INTEGRAL, ChatGPT).
  - Mari G et al. UOG 1995;5:400–405, DOI 10.1046/j.1469-0705.1995.05060400.x: nomograma original com 135 fetos normais (RESUMO; métodos completos não acessados).
  - SMFM Clinical Guideline #8, AJOG 2015;212:697–710, DOI 10.1016/j.ajog.2015.01.059.
  - Maisonneuve E et al. Fetal Diagn Ther 2017;42:225–231, DOI 10.1159/000456661 (RESUMO): 150 gestantes com aloimunização grave avaliadas entre 34 e 37 semanas; sensibilidade da PSV isolada de 69%, e de 94% somando sinais de hidropisia; mais falsos positivos após transfusão prévia.
- **Operador:** o app classifica PSV elevada com ≥ 1,5 MoM; a fonte escreve > 1,5. Sem efeito prático (o MoM calculado nunca é exatamente 1,5); mantido, registrado no pente fino de 06/10/2026.
- **Exibição (R14.35):** perto de 1,3 e 1,5 o MoM ganha casas para nunca parecer igual ao corte com classe diferente.
- **Faixa de 1,3–1,49 MoM:** o valor de 1,29 MoM aparece na literatura associado a anemia leve (Mari 2000, segundo fontes secundárias; Rahimi-Sharbaf, Arch Iran Med 2012, RESUMO), que a PSV não prediz bem. Não é corte diagnóstico; o app agora diz isso. O app usa 1,3, não 1,29 — diferença mantida, sem impacto prático com PSV medida em cm/s.
- **Estado: RESOLVIDO NA R14.33 quanto à redação.** O cálculo do MoM é correto; o desempenho diagnóstico continua não validado depois de 36 semanas, e o app agora informa isso.

### 2.8 Átrio do ventrículo lateral

- **Implementado (CÓDIGO, R14.33):** < 10 mm normal; entre 9 e < 10 mm o cartão pede para confirmar a técnica e correlacionar com o SNC, com seguimento a critério clínico, sem retorno automático e sem menção no laudo; 10 a < 13 leve; 13 a 15 moderada; > 15 grave. Até a R14.32 a faixa de 9–9,9 mm era "No limite superior", com retorno em 3–4 semanas.
- **Fontes:** FEBRASGO morfológico, p. 822 (< 10 mm normal; PDF anexado). Malinger G et al., ISUOG 2020, UOG 2020;56:476–484, DOI 10.1002/uog.22145, Figura 5 (< 10 mm normal). Fox NS et al., SMFM Consult #45, AJOG 2018;219:B2–B9, DOI 10.1016/j.ajog.2018.04.039, p. B7 (10–12 leve, 13–15 moderada, > 15 grave). Sharon-Weiner M et al. Prenat Diagn 2022;42(2):278–286, DOI 10.1002/pd.6076 (RESUMO): 121 fetos com átrio isolado de 9–9,9 mm entre 21 e 24 semanas, comparados a 123 controles < 9 mm; tiveram mais investigação pré-natal, mas taxas semelhantes de sequela no neurodesenvolvimento.
- **Estado: RESOLVIDO NA R14.33.** O retorno em 3–4 semanas, que não tinha respaldo, saiu. A faixa 9–9,9 mm é observação operacional, não categoria de diretriz. Os intervalos decimais da graduação ([10,13), [13,15], > 15) são tradução operacional dos números inteiros da SMFM e devem ser rotulados assim.

### 2.9 Colo uterino

- **Implementado (CÓDIGO, R14.33):** ≤ 25 mm com IG < 24 semanas: "colo curto"; ≤ 25 mm com IG ≥ 24 semanas ou sem IG: "comprimento cervical reduzido" (estado `red`, cor vermelha), sem categoria de risco; sem rótulo separado de 15 mm, mas ≤ 15 mm acrescenta a checagem do sinal do lama; 26–30 mm "limítrofe" só antes de 24 semanas; sem conduta automática. Até a R14.32: ≤ 15 "muito curto" e 16–25 "curto" em qualquer IG.
- **Fontes:** FEBRASGO morfológico, p. 828: corte de 25 mm antes de 24 semanas (PDF anexado). Coutinho CM et al., ISUOG 2022, UOG 2022;60:435–456, DOI 10.1002/uog.26020 (INTEGRAL, ChatGPT): rastreio transvaginal entre 18 e 24 semanas; valores fixos < 15 mm, < 20 mm e ≥ 30 mm aparecem no contexto de gestante **sintomática**. SMFM Consult Series #70, 2024 (PDF anexado): tratamento depende de IG, história, sintomas e gemelaridade.
- **Estado: RESOLVIDO NA R14.33.** As duas escolhas de implementação (fim do rótulo "muito curto" na janela; cor vermelha em "comprimento cervical reduzido") foram mantidas por decisão delegada pelo médico em 06/10/2026. Na R14.35, a conclusão do laudo passou a citar o colo como achado materno, e não morfológico fetal. O operador ≤ 25 mm foi mantido (a FEBRASGO usa o corte de 25 mm; a ISUOG escreve < em outros valores).

### 2.10 Dilatação do trato urinário (UTD)

- **Implementado (CÓDIGO):** `classificaUTD` gera `ST.utd`; qualquer dilatação calicial no pré-natal entra como A2-3; sem cálices, parênquima, ureter, bexiga e oligoâmnio avaliados, o estado fica "incompleto" e lista o que falta. `ST.estr.pel` é só a faixa bruta da pelve.
- **Fonte:** Nguyen HT et al. 2021 update on the urinary tract dilation (UTD) classification system. Pediatr Radiol 2022;52:740–751, DOI 10.1007/s00247-021-05263-w, Figura 1; correção 2023;53:1217 (detalhes em `04_REFERENCIAS_BASE_R14_28.md`, A.5). Texto integral sobre cálice central no pré-natal ainda sem acesso; a regra se apoia na Figura 1.
- **Estado: CONFORME.** A distinção central × periférica é pós-natal e não se aplica ao pré-natal. O caso "pelve 0,5 cm isolada = A1 incompleto" foi resolvido em 05/10/2026: não era regressão.

### 2.11 Líquido amniótico

- **Implementado:** oligoâmnio com MBV < 2 cm ou ILA < 5 cm; polidrâmnio com MBV ≥ 8 cm ou ILA ≥ 24 cm; graduação do polidrâmnio pela SMFM Consult #46, Tabela 2.
- **Fonte:** FEBRASGO, terceiro trimestre (seção 1.7), Tabela 1 p. 833. O texto foi acessado pela web pelo ChatGPT; o download deu HTTP 403, então o PDF não está anexado.
- **Estado: CONFIRMADO E PRESERVADO.**

### 2.12 Datação por CCN — Hadlock 1992

- **Fonte:** Hadlock FP, Shah YP, Kanon DJ, Lindsey JV. Radiology 1992;182(2):501–505. DOI 10.1148/radiology.182.2.1732970. RESUMO: 416 pacientes, CCN de 2 mm a 12 cm.
- **Estado: SOURCE_FREEZE_PENDING.** O contrato interno (verificador 84/84) confirma só a reprodução secundária. O domínio de produto 2–85 mm é escolha do app, não domínio literal do artigo. Não confundir com o peso de Hadlock 1985/1991.

### 2.13 Apresentação (R14.29–R14.32)

Mudanças de interface, sem regra clínica nova: data do exame em cartão próprio (R14.29); datas em dd/mm/aaaa (R14.30); data digitada em dia/mês/ano, com suspensão das dependências quando inválida (R14.31); rótulo de percentil que nunca contradiz a classificação (`rotP`, com espaço fino U+202F depois de < e >) e concordância de número no laudo UTD (R14.32). Casas decimais extras na exibição não representam precisão clínica adicional.

---

### 2.14 Tamanho do bebê para a paciente — Vintzileos 1984 (R14.39)

- **Implementado (CÓDIGO):** comprimento (cm) = 6,18 + 0,59 × fêmur (mm), só com fêmur 3,0–9,0 cm, linha "Para a paciente" na aba Medidas e no Modo Paciente, com número redondo; **nunca no laudo**.
- **Fontes:** Vintzileos AM et al., Obstet Gynecol 1984;64:779-82, PMID 6390277 (RESUMO, com a fórmula). Milner 1994, DOI 10.1002/jcu.1870220407: erro aleatório ±6%, a melhor de seis funções para gestação única (RESUMO). Hadlock 1984, DOI 10.7863/jum.1984.3.1.1: DP 2,4 cm (RESUMO). Lim 2000, DOI 10.1046/j.1469-0705.2000.00053.x: variação entre populações (RESUMO). Faixa de fêmur 30–90 mm: perinatology.com (SECUNDÁRIA).
- **Estado: FORA DA HIERARQUIA, AUTORIZADO** pelo médico em 10/10/2026 (FEBRASGO/ISUOG/Rumack/CBR não trazem fórmula). Sem validação na população brasileira.

## 3. Mudanças aplicadas na R14.33 (liberadas em 06/10/2026)

Patch `patch_r14_33.py` reconstrói a R14.33 byte a byte a partir da R14.32. Sem mudança de cálculo, curva, corte numérico, `valmm()`, `cmpMedida()` ou schema.

1. **Átrio de 9–9,9 mm** normal, sem retorno automático (seção 2.8).
2. **PSV em gestação avançada:** aviso de que PSV normal depois de 35 semanas não exclui anemia; pós-transfusão no aviso de falso-positivo; texto do domínio separando cálculo e validação (seção 2.7).
3. **Colo depois de 24 semanas ou sem IG:** "comprimento cervical reduzido" (seção 2.9).
4. **Aviso de Hadlock:** atribuição corrigida (seção 2.2).
5. **Documentação e tela de referências:** Hadlock 1985 com DOI e tabela; INTERGROWTH com Table S1; Roberts e Adu-Bredu; nota do alerta do NHS England; ISUOG 2019 para os 21 dias; PSV com validação 15–36, Maisonneuve e faixa de atenção; FEBRASGO de líquido pelo título e DOI; átrio pela FEBRASGO, ISUOG 2020 e SMFM #45; linha nova para o colo.
6. **PSV de 1,3–1,49 MoM** identificada como faixa de atenção do app.

## 3.1 Decisões de 06/10/2026 (delegadas a Claude pelo médico)

- **Colo (R14.33):** mantidos o rótulo único "colo curto" na janela (com checagem do sinal do lama em ≤ 15 mm) e a cor vermelha em "comprimento cervical reduzido".
- **Fila herdada:** auditada (`05`). Na R14.34 entraram E1, E2, D1, D2 e D4. Fica de fora o D3 (zoom), que só deve mudar com teste no aparelho.

## 3.2 Mudanças de 10/10/2026 (R14.36 a R14.40, liberadas pelo médico)

Resumo; detalhes, hashes e testes no `07`.

1. **R14.36:** via das uterinas transabdominal por padrão, com aviso no 1º trimestre; barrinha de consulta por lado; incisura por quadradinho.
2. **R14.37:** Medidas começa pela biometria; abas no rodapé; avisos do Laudo dobrados com "por quê"; barra Copiar laudo · Copiar conclusão; simetria; campo em edição não é empurrado. Botões e fontes inalterados.
3. **R14.38:** correções da bateria de testes (flutuantes, teclado, 320 px).
4. **R14.39:** tamanho do bebê para a paciente (2.14); "Próximo pendente" em todas as abas.
5. **R14.40:** limpeza do pente fino, sem efeito clínico.

## 4. Documentos que ainda faltam

| Documento | Para quê |
|---|---|
| DeVore 2021 (10.1002/uog.23578) + Appendix S1 + réplica (10.1002/uog.23579) | Saber a posição dos autores sobre equação × tabela de Ciobanu |
| Corpo de Roberts 2025 (10.1016/j.ajog.2025.03.032) | Confirmar volume e páginas (233:331.e1-11), não verificados |
| Corpo de Mari 1995 (10.1046/j.1469-0705.1995.05060400.x) | Métodos e domínio do nomograma |
| Corpo de Hadlock 1992 (10.1148/radiology.182.2.1732970) | Equação da CCN e fim do SOURCE_FREEZE_PENDING |
| Table S2 do INTERGROWTH 2020 | Conferência célula a célula |
| Fonte nacional (FEBRASGO/CBR) para categorias de colo e átrio | Substituir categorias operacionais por fonte da hierarquia |
| Corpo de Vintzileos 1984 (Obstet Gynecol 64:779) | Confirmar a faixa de fêmur e o erro no texto original (hoje: resumo + fonte secundária) |
| Arquivos do adendo de busca seletiva (CSVs, `conferir_peso_fontes.py`) | Citados no PDF, mas não recebidos |
| Texto do alerta do NHS England/RCOG (2025) | Ler no original, e não só em fontes secundárias |

## 5. Pendências técnicas (não bibliográficas)

- **Publicar a R14.40** como `index.html` e reenviar `CONTEXTO.md`, `README.md` e `suite_regressao_doppler.py` (excluídos do GitHub em 10/10/2026, site em 404).
- Testar a R14.40 em iPhone/Safari físico: teclado numérico nos campos de data, barras do rodapé com teclado aberto, área segura, campo parado, uso offline e atualização.
- Validação clínica formal: nenhuma das conferências acima a substitui.

## 6. Contagens de verificação

São de suítes diferentes. Não somar como número de exames independentes, e não tratar como prova de ausência de defeitos.

| Verificação | Resultado | Quem e quando |
|---|---|---|
| Suíte de regressão R14.39 e R14.40 (18 grupos), Chromium e WebKit | 63.832 checagens, 0 falhas | Claude, 10/10/2026 |
| Diferenciais R14.35/R14.36/R14.37/R14.38/R14.39/R14.40 | até 400 exames aleatórios por par; só as mudanças decididas diferem | Claude, 10/10/2026 |
| Tamanho do bebê, 1.001 valores de fêmur | 0 falhas (Chromium e WebKit) | Claude, 10/10/2026 |
| Suíte de regressão R14.32, Chromium e WebKit | 48.184 checagens, 0 falhas | Claude, 05–06/10/2026 |
| Suíte de regressão R14.33, Chromium e WebKit | 48.184 checagens, 0 falhas | Claude, 06/10/2026 |
| Mudanças da R14.33 (`t33.py`), Chromium e WebKit | 278 checagens, 0 falhas (104 falhas na R14.32); 278/0 também na R14.34 | Claude, 06/10/2026 |
| Mudanças da R14.34 (`t34.py`), Chromium e WebKit | 112 checagens, 0 falhas (66 falhas na R14.33); 112/0 também na R14.35 | Claude, 06/10/2026 |
| Mudanças da R14.35 (`t35.py`), Chromium e WebKit | 630 checagens, 0 falhas (152 falhas na R14.34) | Claude, 06/10/2026 |
| Rótulos de percentil (`t32.py`) na R14.34 e na R14.35 | 740/0 nas duas | Claude, 06/10/2026 |
| Suíte de regressão R14.34, Chromium e WebKit | 48.184 checagens, 0 falhas | Claude, 06/10/2026 |
| Rótulos de percentil R14.32 (`t32.py`) | 740 checagens, 0 falhas (298 falhas na R14.31) | Claude, 06/10/2026 |
| Data do exame R14.31 | 40/40 em Chromium e WebKit | Claude, 05/10/2026 |
| Ciobanu na mesma IG | 198 comparações; diferença ≤ 0,0043 | Claude e ChatGPT, 06/10/2026 |
| Hadlock 1991, equação × tabela | 155 células | ChatGPT, 06/10/2026 |
| Hadlock 1985, duas fórmulas | 120 comparações, 0 falhas | ChatGPT, 06/10/2026 |
| INTERGROWTH: LMS, medianas, quantis | 486 + 162 + 810, 0 falhas | ChatGPT, 06/10/2026 |
| Uterinas | 42 valores | ChatGPT, 06/10/2026 |
| Hadlock 1991: p10 da equação na Tabela 1, por interpolação normal | ≈ p14,5 de 10 a 40 semanas | Claude, 06/10/2026 |
| Contrato CCN Hadlock 1992 | 84/84 (reprodução secundária) | ChatGPT, data do pacote |
