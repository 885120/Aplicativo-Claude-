# Teoria embutida no aplicativo — Calculadora Doppler Obstétrico R14.40

> **Adendo de 10/10/2026 (R14.36 a R14.40).** O corpo abaixo é a extração literal da R14.35. Textos novos ou alterados desde então:
> - **Uterinas (aba Doppler):** "Só consulta: barrinhas pela curva do IP médio. Incisura: marque só se presente." Quadradinho "Incisura" por lado. Aviso no 1º trimestre: "Confirme a via. Transabdominal vem pré-selecionada; no 1º trimestre as duas vias são usadas. Toque na via usada para confirmar." Com Gómez, acrescenta: "A curva de Gómez no 1º trimestre é transvaginal; para medida transabdominal, a curva compatível é Cavoretto.".
> - **Doppler fetal:** campo "Umbilical — diástole" em linha própria.
> - **Medidas:** "Para a paciente: tamanho do bebê ≈ N cm (faixa ≈ a–b cm) · pelo fêmur (Vintzileos 1984) · não entra no laudo".
> - **Laudo:** cada aviso do "Confira antes de laudar" mostra a 1ª frase e o resto em "por quê ›"; o de Hadlock resume-se a "Este app usa a equação de Hadlock 1991; calculadoras com a tabela impressa dão percentil maior." Botões "Copiar laudo" e "Copiar conclusão".
> - **Referências:** linha nova "Tamanho do bebê (só para a paciente)" com Vintzileos 1984, Milner 1994 e o aviso de fonte fora da hierarquia.
>
> O texto dos avisos e do laudo não mudou (diferenciais no `07`).

Texto extraído literalmente do `index.html` R14.35 (SHA-256 `47b3d14c74c611dd1fc44ee7b2e6a58700d856f6bc13cdb96edcd8d43879dbc4`): explicações dos blocos expansíveis, dicas de técnica, painel teórico e painel de referências. Campos de formulário omitidos. A seção 5 reúne, também literalmente, os avisos clínicos condicionais que o motor só exibe com certos dados.

## 1. Explicações dos blocos expansíveis

### 1.1 Calcular a IG por exame anterior ou DUM

Usa a data do exame atual, definida no topo desta aba.

### 1.2 Velocidade de crescimento · opcional

Preenchida com a data do exame usado na datação. Altere se o exame de crescimento foi outro.
Na RCF tardia, queda de CA ou PFE superior a 2 quartis (>50 percentis) é um dos três critérios contributivos do Delphi — e vale mesmo com o peso ainda acima do p10. Quedas menores são sinal de alerta, não critério. O intervalo ideal entre exames é de 21 a 28 dias.

### 1.3 Líquido amniótico · opcional

A FEBRASGO recomenda o uso preferencial do maior bolsão pela simplicidade, e o considera mais acurado para oligoâmnio. Na suspeita de polidrâmnio, porém, trabalhos recentes indicam desempenho superior do ILA. Critérios (FEBRASGO nº 43, 2025): oligoâmnio ILA < 5 cm ou MBV < 2 cm · polidrâmnio ILA ≥ 24 cm ou MBV ≥ 8 cm. Quando os dois métodos divergem, o app mostra os dois e não escolhe um vencedor.
Na comparação randomizada, o ILA diagnosticou significativamente mais oligoâmnio (RR 2,39), com mais induções e mais cesáreas por sofrimento fetal, sem melhora demonstrada dos desfechos perinatais.
FEBRASGO, Ultrassonografia obstétrica do 3º trimestre (2025) · Cochrane CD006593 (Nabhan & Abdelmoula 2008).

### 1.4 Achados morfológicos · opcional

Preencha só o que medir. Cada valor é interpretado para a idade gestacional e sugere o que checar junto.

### 1.5 Marcadores qualitativos

Marque presente ou ausente. Sem medida, mas contam para saber se o achado é isolado — por isso "não avaliado" também importa aqui.

### 1.6 Checklist anatômico — órgãos-alvo

FEBRASGO 77: a avaliação anatômica no 1º trimestre é dirigida aos órgãos-alvo. Não identificar alteração aqui não dispensa o morfológico de 2º trimestre.
• DBP abaixo do p5 pede atenção redobrada à coluna.
• Não diagnostique placenta prévia no 1º trimestre — a migração ocorre na maioria dos casos.
Gemelar: corionicidade entre 8 e 15 semanas — sinal do lambda indica dicoriônica; sinal do T, monocoriônica.

### 1.7 Tabela completa dos critérios

Os quatro critérios acima são transvaginais — o título da Table 2 é "Guidelines for Transvaginal Ultrasonographic Diagnosis". Em exame apenas transabdominal a fonte descreve uma exceção: embrião com CCN ≥ 1,5 cm sem atividade cardíaca. Achados suspeitos devem, em geral, ser reavaliados em 7 a 10 dias.
Documente a ausência de atividade cardíaca por modo M (ou modo B). Meça o CCN em corte sagital, com o embrião em posição neutra, sem incluir a vesícula vitelina — a partir de ~7 semanas o embrião flete, e medir o maior eixo qualquer superestima.
A ISUOG orienta não usar rotineiramente Doppler espectral, mapeamento colorido ou power Doppler antes de 11 semanas — a saída acústica é bem maior e o alvo é pequeno. Modo B e modo M não têm indício de dano nessa fase. Se o Doppler for clinicamente indicado, mantenha o índice térmico ≤ 1,0 e o tempo de exposição no mínimo.
Os cortes antigos (CCN 0,5 cm, SG 1,6 cm) vinham de séries pequenas e produziam falso-positivo — por isso foram elevados.

### 1.8 Tabela rápida e aviso sobre as referências

Antes de laudar: tabelas de referência publicadas divergem entre si de forma clinicamente relevante (até ~37% no p5 da ACM). Use sempre a mesma, cite-a no laudo, e confira qual está carregada no seu aparelho.

### 1.9 Técnica — o que falseia o valor

- Filtro de parede alto apaga a diástole real e simula diástole zero. Baixe ao mínimo antes de cravar AEDF/reversa.
- PRF/escala alta comprime a diástole contra o zero — mesmo erro.
- Ganho excessivo preenche a janela espectral com ruído e simula fluxo inexistente.
- Fora da FC basal (110–160): bradicardia sobe o IP, taquicardia desce.
- Movimento respiratório fetal distorce a onda — espere apneia, registre 3+ ciclos.
- ACM: não comprima o polo cefálico. Ângulo 0° para PSV.
- AU: padronize alça livre — o IP muda entre inserção fetal e placentária.
- Peso: o erro aleatório do método é de ~10%, e piora nos fetos pequenos — justamente os que importam.

## 2. Dicas de técnica e interpretação

**2.1** Critérios da SRU/Doubilet (NEJM 2013). A Table 2 do artigo é explicitamente transvaginal. Por via transvaginal, CCN ≥ 0,7 cm sem atividade cardíaca, ou DMSG ≥ 2,5 cm sem embrião, fecham o diagnóstico de perda gestacional precoce. Em exame apenas transabdominal, a única exceção descrita pela fonte é embrião com CCN ≥ 1,5 cm sem atividade cardíaca — os cortes de 0,7 cm e 2,5 cm não são transportáveis para a via transabdominal. Foram escolhidos para especificidade de 100% — na dúvida, o certo é repetir, nunca antecipar. Documente a ausência de atividade cardíaca por modo M.

**2.2** Duas curvas disponíveis, alternáveis no botão ao lado do título. Hadlock: peso por Hadlock 1985 com quatro parâmetros, percentil por Hadlock 1991 — equação original em ln(EFW), SD=0,12 (escala log); é a referência populacional recomendada pela SMFM. INTERGROWTH-21st: padrão prescritivo internacional que inclui sítio brasileiro (Pelotas); usa o Hadlock de três parâmetros (CC, CA, F), sem DBP, e o percentil de Stirnemann 2020 — faixa recomendada 18–40 sem, extensão até 41 sem quando clinicamente justificada. Trocar a curva troca a fórmula junto — o peso em gramas também muda.

**2.3** Cada medida tem sua idade equivalente por Hadlock 1984, mostrada junto ao próprio campo (DBP, CC, CA, CF) — é descritiva: não há corte automático de 1, 1,5, 2 ou 3 semanas associado a ela, e ela nunca redata uma gestação já estabelecida (a datação oficial usa só HC+FL, método separado e validado — ver o cartão de IG).

**2.4** Relações entre as medidas — cada uma com sua própria adjudicação (auditoria 2026-09), não "faixas do aparelho": CF/CA — Hadlock 1983, faixa normal 20–24%, a partir de 22+0 sem (gate = política do app); CF/DBP — Hohler & Quetel 1981, faixa publicada 71–87% (a estatística do ±8% não é especificada no resumo), a partir de 23+0 sem (gate = política do app); CF/CC — descritiva, sem faixa auditável (Hadlock 1984 confirma a amostra, não uma tabela verificável); CC/CA — descritiva, reprodução secundária de Campbell (Br J Obstet Gynaecol 1977), estatística indeterminada no resumo original.

**2.5** Chitty & Altman, BJOG 2002 — percentis 3, 50 e 97 (cm) por semana dos ossos longos. O percentil de cada um aparece embaixo do próprio campo; aqui fica só a faixa, para quem quiser conferir.

**2.6** A FEBRASGO recomenda o uso preferencial do maior bolsão pela simplicidade, e o considera mais acurado para oligoâmnio. Na suspeita de polidrâmnio, porém, trabalhos recentes indicam desempenho superior do ILA. Critérios (FEBRASGO nº 43, 2025): oligoâmnio ILA < 5 cm ou MBV < 2 cm · polidrâmnio ILA ≥ 24 cm ou MBV ≥ 8 cm. Quando os dois métodos divergem, o app mostra os dois e não escolhe um vencedor. Na comparação randomizada, o ILA diagnosticou significativamente mais oligoâmnio (RR 2,39), com mais induções e mais cesáreas por sofrimento fetal, sem melhora demonstrada dos desfechos perinatais. FEBRASGO, Ultrassonografia obstétrica do 3º trimestre (2025) · Cochrane CD006593 (Nabhan & Abdelmoula 2008).

**2.7** Umbilical: mede a resistência da placenta — sobe quando a área de troca cai. Aqui o alto é que preocupa (IP acima do p95). Alça livre, sem contração fetal, ângulo próximo de zero. Cerebral média: mede a vasodilatação cerebral. Aqui o baixo é que preocupa (IP abaixo do p5 = centralização). Terço proximal, ângulo zero, sem comprimir o polo cefálico — a compressão falseia para baixo. Ciobanu et al. 2019 (FMF) — mesma coorte pras duas.

**2.8** Compartimento materno — reflete a placentação. Alto preocupa: IP médio acima do p95 — a referência ativa (Gómez ou Cavoretto, veja o botão no título do card) foi construída pro IP médio das duas artérias, não para cada lado isolado; os campos por lado servem de conferência de medida, sem classificação clínica própria. Confirme velocidade acima de 60 cm/s para garantir que é o tronco, não ramo colateral. Discordância importante entre os lados deve motivar revisão da técnica e do ponto de amostragem. A incisura protodiastólica pode ser marcada por lado, mas fica registrada como achado descritivo — CBR/FEBRASGO orienta não valorizar isoladamente presença ou ausência de incisura. Gómez 2008 · 11–41 semanas, citada pela ISUOG. 11–14 sem por via transvaginal, 15–41 sem por via transabdominal — valores não intercambiáveis entre vias.

**2.9** Território venoso de vigilância em fetos com comprometimento placentário. Onda ‘a’ ausente ou reversa representa alteração hemodinâmica de alta gravidade. A interpretação deve ser integrada à vitalidade fetal, idade gestacional e condição materna. Não é critério diagnóstico de restrição.

**2.10** Sem campo de incisura aqui, de propósito: entre 11 e 14 semanas ela é fisiológica — está presente em 46–64% das gestações normais — e não entra no modelo de risco da Fetal Medicine Foundation, que usa o IP médio. A incisura pode ser registrada no 2º/3º trimestre como achado descritivo, mas sua presença ou ausência isolada não modifica a classificação Doppler do app — a interpretação formal das artérias uterinas usa o IP médio das duas artérias. Se desejar registrá-la nessa fase, use o card de artérias uterinas da aba Doppler. Gómez 2008 mediu por via transvaginal entre 11–14 semanas e por via transabdominal entre 15–41 semanas — os valores de referência não são automaticamente intercambiáveis entre as duas vias. O app usa a mesma tabela para ambas as janelas por não ter campo de via; informe-se de que a medida foi feita pela técnica compatível com a fase do exame.

## 3. Painel teórico — Restos ovulares

Restos ovulares
A hierarquia do que prediz
1
Massa ecogênica intracavitária
Melhor desempenho diagnóstico entre os achados ultrassonográficos.
2
Vascularização ao Doppler
Aumenta a suspeita quando associada a massa. Isolada, pouco específica.
3
Espessura endometrial
Dado objetivo útil, mas inespecífico isoladamente.
Restos ovulares/RPOC são diagnóstico pós-evento gestacional que deve integrar história, sintomas e ultrassom; não devem ser definidos apenas pela espessura endometrial nem equiparados automaticamente a abortamento incompleto. Não há recomendação formal padronizada para o diagnóstico ultrassonográfico (Blyth et al., 2025 — revisão de 17 estudos).
1 · Massa ecogênica intracavitária
Na metanálise de Sundararajan et al. (AJOG 2024 — 11 estudos, 1.567 participantes) foi o marcador de maior acurácia: sensibilidade de cerca de 91,5% e especificidade de cerca de 84,3%. Os estudos são heterogêneos, e o achado não equivale a diagnóstico histológico automático.
2 · Espessura endometrial
Os cortes variam entre os estudos — 10 mm e 15 mm aparecem com frequência — e não existe corte isolado validado que determine diagnóstico ou tratamento. Na mesma metanálise, com corte de 10 mm, a sensibilidade foi de cerca de 66,7% e a especificidade de cerca de 86,6%, com intervalos de confiança amplos e desempenho inferior ao da massa ecogênica. A revisão de 2025 também encontrou grande heterogeneidade de limiares.
A espessura isolada nunca deve produzir "restos presentes" nem indicação de conduta. Reporte-a como dado objetivo.
3 · Doppler colorido
- A vascularização aumenta a suspeita quando associada a massa.
- Ausência de fluxo não exclui restos ovulares.
- Isolado, tem baixa especificidade — cerca de 85,0% de sensibilidade e 40,6% de especificidade na metanálise de 2024 — e não confirma RPOC sozinho.
- Não equipare qualquer fluxo endometrial a tecido retido; avalie a distribuição do fluxo e o miométrio quando pertinente.
Leitura combinada
Achado — Leitura
Massa ecogênica com vascularização — Fortalece a suspeita
Massa ecogênica avascular — RPOC permanece possível; coágulo é diferencial
Espessamento isolado — Achado inespecífico
Cavidade sem massa focal e endométrio fino — Reduz a probabilidade; não constitui regra universal isolada. Em Durfee et al. (2005), ausência de massa ou fluido complexo com endométrio < 10 mm tornou RPOC muito improvável — resultado de estudo, não regra diagnóstica.
Para o laudo: descreva a morfologia (massa, ecogenicidade, vascularização) e reporte a espessura como dado objetivo. Diferenciar tecido de coágulo é reconhecidamente difícil.
A decisão terapêutica depende do quadro clínico, estabilidade, sangramento, sinais infecciosos, evolução e preferência da paciente, além dos achados de imagem.
Considere sempre diagnósticos alternativos e correlacione com a clínica e com a queda do hCG. Fontes: Sundararajan et al., AJOG 2024 (DOI 10.1016/j.ajog.2023.11.1243) · Blyth et al., Hum Fertil 2025 (DOI 10.1080/14647273.2025.2522054) · Durfee et al., 2005 (estudo complementar).
</div

## 4. Painel de referências do app (como exibido)

Referências
Hierarquia adotada: FEBRASGO → CBR → ISUOG. FMF e demais fontes complementam os parâmetros não cobertos por essa ordem. Os consensos Delphi entram onde a FEBRASGO não detalha o critério operacional. Quando um critério vem de fora dessas fontes, está identificado como tal.
Biometria e crescimento
Peso fetal estimado — Curva selecionável no cartão de peso. Hadlock: Hadlock 1985, 4 parâmetros (DBP, CC, CA, F) — a fórmula do Rumack. INTERGROWTH-21st: Hadlock 1985, 3 parâmetros (CC, CA, F), que é a fórmula pressuposta pelo padrão. Fonte das duas fórmulas: Hadlock et al., AJOG 1985;151:333-337, Tabela II
Percentil de peso — Hadlock: Hadlock 1991, equação original em ln(EFW), SD=0,12 (escala log) — referência populacional recomendada pela SMFM; a Tabela 1 impressa do mesmo artigo é mantida só como referência histórica, por não ser matematicamente equivalente à equação (Roberts et al., AJOG 2025; Adu-Bredu et al., BJOG 2026). INTERGROWTH-21st: Stirnemann, Salomon & Papageorghiou, UOG 2020;56:946-948, equações da Table S1; faixa recomendada 18–40 semanas, extensão até 41 semanas quando clinicamente justificada (política INTERGROWTH 2025)
Idade por parâmetro — Hadlock 1984
Relação CC/CA — Campbell S. & Thoms A. Br J Obstet Gynaecol 1977;84:165-174 — domínio publicado 17 a 41 semanas. Fora dessa faixa o app não calcula a relação (a extrapolação para 13–16 e 42 sem foi removida em 2026-09). O abstract usa simultaneamente "95 per cent confidence limits" e "95th centile limit" — construção estatística indeterminada; os números da tabela só estão disponíveis por reprodução secundária (não no artigo original). Classificação automática removida em 2026-09 (auditoria R14) — a relação aparece só como referência descritiva, por bloco de 2 semanas, sem interpolação fracionária
Relações CF/CA, CF/DBP, CF/CC — Auditoria independente 2026-09 (R14) — cada uma com fonte e status próprios, não "faixas do equipamento": CF/CA — Hadlock et al. 1983 (AJR 141:979-984), faixa normal 20–24% (mean ± 2 SD), a partir de 22+0 sem (gate = política do app, pois "after 21 weeks" não define o primeiro dia no resumo). CF/DBP — Hohler & Quetel 1981 (AJOG 141:759-762), faixa publicada 71–87% (79 ± 8%; o resumo não especifica o que ±8 representa estatisticamente — "90% IC", usado em manuais de equipamento, não é confirmável na fonte), a partir de 23+0 sem (gate = política do app). CF/CC — Hadlock et al. 1984 (JUM 3:439-442) confirma a amostra (n=361, 15-42 sem), mas a tabela semanal de limites só foi vista em manuais de equipamento — sem faixa auditável, descritiva
Comprimento fetal — Vintzileos et al. 1984 — auxiliar, fora da hierarquia; informativo — exibido só no Modo Paciente, não entra no laudo
Por que Hadlock é o padrão — É a curva da tabela de referência da Fetalmed e a recomendação de referência populacional do protocolo de medicina fetal da FEBRASGO. O INTERGROWTH-21st fica disponível como alternativa prescritiva, selecionável no cartão de peso — não como padrão. Em dezembro de 2025, o NHS England (alerta de segurança divulgado pelo RCOG) orientou os serviços ingleses a deixar de usar as curvas de peso INTERGROWTH-21st, por identificarem menos fetos pequenos
Definição de RCF: duas leituras — A FEBRASGO caracteriza RCF suspeita já com PFE ou CA abaixo do p10. O consenso Delphi é mais restritivo e exige critério adicional. Quando as duas divergem, o app mostra as duas em vez de escolher por você
Critérios de RCF — Consenso Delphi (Gordijn, UOG 2016) · ISUOG Practice Guidelines 2020
Restrição seletiva em gemelar — Consenso Delphi gemelar (Khalil, UOG 2019;53:47-54). Solitário em qualquer corionicidade: PFE de um feto abaixo do p3. Monocoriônica: 2 de 4 contributivos (PFE < p10, CA < p10, discordância ≥ 25%, IP-AU do menor > p95). Dicoriônica: 2 de 3, sem a CA. Aplicado sobre curvas de feto único. ISUOG 2025 (UOG 2025, DOI 10.1002/uog.29166): se os dois fetos têm PFE abaixo do p10, ambos devem ser descritos como SGA — nomenclatura que pode sobrepor os critérios Delphi acima; o app não resolve essa sobreposição automaticamente
Percentil da circunferência abdominal — INTERGROWTH-21st (Papageorghiou, Lancet 2014;384:869-79) — tabela de centis, 14 a 40 semanas. Com a curva de peso em Hadlock, CA e peso vêm de referências diferentes e o app sinaliza a limitação; com a curva em INTERGROWTH-21st, as duas ficam na mesma fonte
Queda >2 quartis — RCOG Green-top 31 (2024) — equivale a 50 percentis. Intervalo mínimo de 21 dias entre os exames comparados: política do app, apoiada na ISUOG 2019 (Salomon et al., UOG 2019;53:715-723 — intervalo tipicamente de pelo menos 3 semanas)
Intervalo de reavaliação — O app não sugere intervalos de seguimento. Referência para o médico: FEBRASGO, Protocolo de RCF (Martinelli, Zugaib, Francisco, Bittar, 2018)
Doppler
Artéria umbilical — Ciobanu et al. Ultrasound Obstet Gynecol 2019;53:465-472 (FMF), 20+0–41+6 sem
Cerebral média — IP — Ciobanu et al. Ultrasound Obstet Gynecol 2019;53:465-472 (FMF), 20+0–41+6 sem
Cerebral média — PSV — Mari G et al. N Engl J Med 2000;342:9-14 — fórmula e corte de 1,5 MoM; validação diagnóstica entre 15 e 36 semanas. O app calcula de 15+0 a 40+6. Após 35 semanas: Maisonneuve E et al., Fetal Diagn Ther 2017;42:225-231. Faixa de atenção de 1,3 a 1,49 MoM: critério do app, não corte diagnóstico
Artérias uterinas — Duas referências selecionáveis (IP médio das duas artérias, nunca cada lado isolado) — nenhuma é tratada como "padrão internacional" ou substituta da outra; o próprio Cavoretto 2023 declara ausência de padrão internacionalmente endossado e necessidade de validação externa.
Gómez et al. Ultrasound Obstet Gynecol 2008;32:128-132 — transversal, 620 gestantes, 11–41 sem, p5/p50/p95, citada nas ISUOG Practice Guidelines. 11–14 sem via transvaginal, 15–41 sem via transabdominal — valores não intercambiáveis entre vias.
Cavoretto et al. Ultrasound Obstet Gynecol 2023;61:474-480 — longitudinal, 476 gestantes (2045 exames), população saudável de baixo risco, 10–39 sem, p3/p5/p10/p25/p50/p75/p90/p95/p97, 100% via transabdominal. Table 3 publicada usada como referência direta (não o modelo MEN contínuo — ver Oviedo-Cruz et al. 2024/Cavoretto et al. 2024, DOI 10.1002/uog.27550 e 27552)
Relação cerebroplacentária — critério ISUOG é < p5, incorporado desde 2026-09 via Ciobanu 2019/FMF (20+0–41+6 sem, mesma família agora usada pra AU e MCA) como via alternativa ao IP-AU no 3º componente da RCF tardia. O corte absoluto de 1,0 permanece como radar informativo adicional, não formal
Ducto venoso — IP (2º/3º tri) — Tongprasert F, Srisupundit K, Luewan S, Wanapirak C, Tongsong T. Gynecol Obstet Invest 2012;73:32-37 (14–40 sem) — origem dos percentis exibidos. Papel clínico conforme ISUOG 2020: vigilância, não critério diagnóstico de RCF
Vigilância com diástole ausente/reversa — ISUOG Practice Guidelines 2020 — a cada 2–3 dias antes de 34 sem (referência para o médico; o app não automatiza a vigilância)
Manejo da RCF — Protocolos de manejo de RCF definem vigilância e momento de resolução combinando Doppler, vitalidade fetal, idade gestacional e condição materna; este app não automatiza esses marcos.
Territórios do Doppler — FEBRASGO, Ultrassonografia obstétrica do 3º trimestre
Primeiro trimestre
Perda gestacional precoce — Doubilet PM et al., painel SRU, N Engl J Med 2013 · léxico multissociedades 2024
Datação pelo CCN — Hadlock 1992 · Robinson & Fleming permanece como comparação histórica
FCF — prognóstico precoce — Doubilet & Benson, JUM 1995 (limite inferior 100/120 bpm) e resumo autoral de Doubilet (faixa "poor")
FCF — FC rápida — Doubilet, Benson & Chow, AJR 2000 (≥135/≥155 bpm; bom prognóstico)
FCF — fisiologia 6–9+6 sem — Silva & Bailão, RBGO 2000, Tab. 2 (−2DP/M/+2DP por meia semana)
FCF — fisiologia 10–13+6 sem — Pettersen & Faria, RBGO 2001 (p5/p95 por semana completa)
FCF — 14–19+6 sem — Sem referência ultrassonográfica pontual validada: só registro
FCF — a partir de 20 sem — 110–160 bpm como alerta: faixa basal de CTG (FIGO 2015; Pildner von Steinburg 2013)
Translucência nucal — Faria 2004 — população brasileira · técnica FEBRASGO (Protocolo 63)
Osso nasal, ducto, tricúspide, uterinas — FEBRASGO, Protocolo 77 — Ultrassonografia no 1º trimestre. Osso nasal, ducto venoso e tricúspide são classificados só entre 11+0 e 13+6 semanas
Ducto venoso — IP (1º tri) — Pruksanusak et al., Gynecol Obstet Invest 2014;78:22-25, Tabela 2 (p. 24), lida no texto integral: PIV p5 0,69 · p50 0,92 · p95 1,13, constantes para CCN 45,9–75,5 mm (faixa observada). Onda A interpretada à parte.
Corte de 60 cm/s na tricúspide — Fetal Medicine Foundation
Cálculo de risco combinado — não realizado no app — a FEBRASGO remete ao software da FMF
Morfológico e estruturas
Checklist e valores de referência — FEBRASGO, Ultrassonografia morfológica do segundo trimestre (Protocolo de Obstetrícia nº 43, 2025; antes nº 78, 2018). O corte de osso nasal (≥ 4,5 mm) é aplicado só de 20 a 24 semanas, a janela do exame
Líquido amniótico — FEBRASGO — Ultrassonografia obstétrica do terceiro trimestre (Femina 2025, DOI 10.61622/0100-7254536202507), Tabela 1 — diagnóstico formal · SMFM Consult Series #46 (AJOG 2018), Tabela 2 — graduação do polidrâmnio · FEBRASGO nº 82 (2018) — referência histórica e técnica · Cochrane CD006593 (Nabhan & Abdelmoula 2008) — preferência do maior bolsão para oligoâmnio
Átrio do ventrículo lateral — Normal abaixo de 10 mm em qualquer IG: FEBRASGO (morfológico, 2025) e ISUOG 2020 (Malinger et al., UOG 2020;56:476-484). Graduação leve/moderada/grave: SMFM Consult Series #45 (10–12, 13–15 e > 15 mm; as faixas decimais são tradução operacional do app). Snijders & Nicolaides, UOG 1994 — referência histórica
Colo uterino — FEBRASGO (morfológico, 2025) — corte de 25 mm antes de 24 semanas · ISUOG 2022 (Coutinho et al., UOG 2022;60:435-456) — rastreio transvaginal entre 18 e 24 semanas; valores fixos como < 15 mm são do contexto de gestante sintomática · SMFM Consult Series #70 (2024) — a conduta depende do contexto clínico, e o app não a automatiza. Fora da janela de rastreio o app descreve "comprimento cervical reduzido", sem categoria de risco
Órbitas — Sukonpan & Phupong, J Med Assoc Thai 2008;91(9):1318-22, Tabelas 1 e 2 (p10/p50/p90, 15–40 sem, 595 medidas; conferidas célula a célula). Fora de p10–p90 = alerta, não diagnóstico.
Placenta — espessura — Bonilla-Musoles F. Diagnóstico con Ultrasonidos en Obstetricia y Ginecología. Valencia, 1972 — valores reproduzidos pelo Fetalmed, 16 a 38 sem. São média e variação, não percentis, e derivam da regra de bolso "espessura em mm ≈ IG em semanas, até ~4 cm". Nenhum guideline (FEBRASGO/ISUOG) adota corte diagnóstico para espessura placentária — por isso o app apenas descreve a medida e não emite laudo assertivo de placenta espessa ou fina
Ossos longos — Chitty & Altman, BJOG 2002 (percentis 3, 50 e 97)
Cerebelo — diâmetro transverso — Snijders RJ, Nicolaides KH. Ultrasound Obstet Gynecol 1994;4(1):34-48 — 14 a 38 semanas, percentis conferidos contra a tabela do Fetalmed. Fora dessa faixa o app não classifica (a versão anterior extrapolava até 40 sem)
Dilatação urinária — UTD Classification System — consenso multidisciplinar
Marcadores de aneuploidia — SMFM Consult Series #57
Restos ovulares — Sundararajan et al., AJOG 2024 (DOI 10.1016/j.ajog.2023.11.1243) · Blyth et al., Hum Fertil 2025 (DOI 10.1080/14647273.2025.2522054) · Durfee et al. 2005, complementar
Limitações assumidas
- Percentil da CA incorporado (INTERGROWTH-21st, p10 conferido linha a linha). A ISUOG define o critério (< p3 isolado, < p10 combinado). Um resultado negativo do app vale apenas para os parâmetros avaliados.
- Percentil da CPR incorporado desde 2026-09 (Ciobanu 2019/FMF, 20+0–41+6 sem) — usado como via alternativa ao IP-AU no 3º componente da RCF tardia. Desde o C0-B1, IP-AU e IP-ACM isolados também usam essa mesma família (Ciobanu 2019/FMF) — Acharya 2005 e Arduini & Rizzo 1990 ficam só como referência histórica, fora do motor ativo.
- Curvas de peso são de feto único — não há ajuste para gemelar.
- O percentil satura nas caudas; nesses casos o app mostra a distância do limiar.
As classificações são apoio à decisão. A conduta, o seguimento e o momento do parto são do obstetra, integrando vitalidade fetal e contexto materno.
</div

## 5. Avisos clínicos condicionais do motor

Estes textos não aparecem na tela estática: o motor só os mostra quando certos dados são preenchidos. Copiados literalmente do JavaScript da R14.35 (aspas e marcação HTML removidas). A análise de cada um está em `01_ESTADO_CIENTIFICO_R14_35.md`.

### 5.1 Peso — aviso Hadlock equação × tabela (percentil de peso < 20)

A equação original de Hadlock 1991 classifica mais fetos como pequenos do que a tabela impressa do mesmo artigo. Em 176.060 exames, usar a tabela em vez da equação subdiagnosticaria restrição em 5,1% das pacientes (Roberts AW et al., Am J Obstet Gynecol 2025;233:331.e1-11). Outra reanálise encontrou o p10 da equação equivalente a cerca do p17 da tabela, entre 35 e 36 semanas (Adu-Bredu TK et al., BJOG 2026); o número exato depende de como a tabela é interpolada. Este app usa a equação (decisão C0-A) — se você compara com uma calculadora que usa a tabela impressa clássica, a diferença acima explica a divergência. Perto do limiar, correlacione com a tendência de crescimento, não só o valor isolado.

### 5.2 Curva de peso selecionável (comentário do código)

'hadlock' — peso por Hadlock 1985 (4 parâmetros) e percentil por Hadlock 1991. 'ig21' — padrão INTERGROWTH-21st para o peso de Hadlock (Stirnemann, Salomon e Papageorghiou, UOG 2020;56:946-948). Esse padrão pressupõe o Hadlock de três parâmetros (CC, CA, F) — trocar a curva troca também a fórmula, senão o percentil sai enviesado. Faixa recomendada 18–40 sem; uso até 41 sem como extensão condicional (política INTERGROWTH 2025). Hadlock é sempre o ponto de partida de cada exame; a troca para INTERGROWTH vale só para o exame em curso.

### 5.3 PSV-ACM

- Texto de base: "A interpretação da PSV-ACM para anemia fetal pressupõe feto em risco para anemia; não é rastreio universal (SMFM Clinical Guideline #8)."
- ≥ 1,5 MoM: "Acima de 1,5 — risco de anemia moderada/grave". Com IP-ACM < p5: a velocidade elevada pode refletir o estado hiperdinâmico da centralização, e não anemia.
- 1,3 a < 1,5 MoM: "Limítrofe — acompanhar tendência", com a nota: "A faixa de 1,3 a 1,49 MoM é critério de atenção deste app, não corte diagnóstico: o corte validado é 1,5 MoM (Mari 2000), e abaixo dele a PSV não prediz de forma confiável a anemia leve."
- < 1,3 MoM: "Dentro da normalidade".
- IG ≥ 35 sem com PSV alta ou limítrofe: "PSV-ACM elevada após 35 semanas: a taxa de falso-positivo para anemia sobe nessa faixa e também após transfusão intrauterina prévia. Valorize mais a tendência entre exames do que um valor isolado aqui."
- IG ≥ 35 sem com PSV normal (novo na R14.33): "PSV-ACM dentro da normalidade após 35 semanas não exclui anemia fetal: nessa fase a sensibilidade da PSV isolada é menor (69% entre 34 e 37 semanas em aloimunização grave — Maisonneuve 2017). Em feto de risco, valorize sinais de hidropisia, a tendência entre exames e o contexto clínico."
- Fora de 15+0–40+6: "Este app calcula o MoM da PSV-ACM de 15+0 a 40+6 semanas (nomograma de Mari); a validação diagnóstica do estudo original foi feita entre 15 e 36 semanas (Mari 2000; SMFM Clinical Guideline #8)." A medida é registrada, mas não interpretada.

### 5.4 Átrio do ventrículo lateral

- > 15 mm: "Ventriculomegalia grave".
- 13 a 15 mm: "Ventriculomegalia moderada".
- 10 a < 13 mm: "Ventriculomegalia leve".
- 9 a < 10 mm (alterado na R14.33): "Normal" — "Abaixo de 1,0 cm é normal em qualquer idade gestacional. Valor próximo do limite: confirme a técnica de medida e correlacione com os demais achados do SNC; seguimento a critério clínico."
- < 9 mm: "Normal abaixo de 1,0 cm em qualquer idade gestacional."
- Técnica: corte transventricular, medida no glomo do plexo coroide, perpendicular ao eixo do ventrículo.

### 5.5 Colo uterino (alterado na R14.33)

- Técnica: "Medida por via transvaginal, bexiga vazia, três aquisições — anotar a menor. O corte de 25 mm vale antes de 24 semanas."
- ≤ 25 mm com IG < 24 sem: "Colo curto", com o contexto: "Comprimento cervical reduzido. A interpretação de risco e a conduta dependem da idade gestacional, sintomas, história obstétrica, gestação única ou múltipla e demais achados clínicos. Correlacionar com avaliação obstétrica." Laudo: "colo curto".
- ≤ 25 mm com IG ≥ 24 sem ou sem IG: "Comprimento cervical reduzido" — "Fora da janela de rastreio, o corte de 25 mm não tem o mesmo significado prognóstico" (ou "Sem IG informada, não é possível saber se o exame está na janela de rastreio"), seguido do mesmo contexto clínico. Laudo: "comprimento cervical reduzido; interpretação conforme a idade gestacional e o contexto clínico."
- ≤ 15 mm: sem rótulo próprio; o cartão acrescenta "Checar: afunilamento, sinal do lama, dinâmica ao esforço."
- 26 a 30 mm com IG < 24 sem: "Limítrofe".
- Acima disso: "Adequado". Sem conduta terapêutica automática (C0-C1E-05).

### 5.6 Osso nasal e tricúspide do 1º trimestre (R14.34)

- Classificados só entre 11+0 e 13+6 semanas, como o ducto venoso. Fora disso: "Fora da janela do rastreio de primeiro trimestre — O protocolo deste módulo se aplica entre 11+0 e 13+6 semanas." Para osso nasal ausente: "Antes de 11 semanas o osso nasal pode ainda não estar ossificado; registro sem classificação como marcador." Para a tricúspide: "Pico de X cm/s registrado, sem classificação por este protocolo." Sem IG: "Informe a idade gestacional para interpretar…". Fora da janela, nada disso entra no laudo.

### 5.7 Osso nasal do 2º trimestre (R14.34)

- Entre 20+0 e 24+6 semanas: "FEBRASGO, Ultrassonografia morfológica do segundo trimestre (Protocolo nº 43, 2025; antes nº 78, 2018): normal a partir de 0,45 cm no exame de 20 a 24 semanas." Abaixo disso, "Osso nasal hipoplásico"; razão prega frontonasal/osso nasal ≥ 0,80, "Razão prega/ON aumentada".
- Fora da janela: "Fora da janela do corte de 0,45 cm — O corte de 0,45 cm da FEBRASGO vale no exame morfológico de 20 a 24 semanas (IG atual: …). O osso nasal cresce com a idade gestacional; aqui a medida fica registrada, sem classificação de hipoplasia."

### 5.8 Exibição de valores perto dos cortes (R14.35)

- Quando o valor medido e o corte arredondados a 2 casas pareceriam iguais com brutos diferentes, os dois são exibidos com mais casas (até 5). Exemplos: "1,499 MoM — Limítrofe" em vez de "1,50 MoM — Limítrofe"; CPR "0,846 · p5 = 0,848 · abaixo do p5"; IP médio uterino "1,585" acima do p95 "1,580". Vale para PSV, CPR, faixa de referência dos vasos e IP médio das uterinas. A classificação não mudou.

### 5.9 Colo na conclusão do laudo (R14.35)

- "Feto com peso adequado para a idade gestacional (percentil X), com achado materno: colo curto." Com achado fetal junto: "com achado(s) morfológico(s): ventriculomegalia e achado materno: colo curto." Título da síntese quando o colo é o único achado: "Peso adequado, achado materno".
