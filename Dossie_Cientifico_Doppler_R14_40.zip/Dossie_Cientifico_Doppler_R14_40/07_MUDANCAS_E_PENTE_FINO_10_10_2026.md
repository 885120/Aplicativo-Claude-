# Mudanças de 10/10/2026 (R14.36 → R14.40) e pente fino da R14.39

Data: 10/10/2026. Autor: Claude. Responsável clínico: Dr. Diogo S. Ribeiro (CRM 5789-AL).
Cada versão foi liberada pelo médico antes de ser aplicada. Patches `patch_r14_36.py` a `patch_r14_40.py` reconstroem cada versão byte a byte a partir da anterior.

| Versão | SHA-256 do `index.html` | O que entrou |
|---|---|---|
| R14.36 | `ab7a5936b26b3bdd9d4c08fd5c0032b896b42d32b766b0f6ad47737014a18dc1` | Via das uterinas, barrinha por lado, incisura por quadradinho |
| R14.37 | `55e4f80e0d137553aa0ea0e9a7e9504ab4a67263c95313102cf5c34db0816215` | Ergonomia, simetria, campo parado |
| R14.38 | `de9cafcd01f00ffcf2633ffb8d30fb33fd51d474ec0b6f476c588a2cfd0929c2` | Correções da bateria de testes |
| R14.39 | `1a92da24c4dd139df0f3a0ffb1c0f6caf462de557999b7fcae3b1c172b8c1373` | Tamanho do bebê para a paciente; "Próximo pendente" em todas as abas |
| R14.40 | `d5a9931092acab63cb59f95418f8992d7e9ca0d5591cdd10fb0863d926cfd0f5` | Limpeza do pente fino, sem efeito clínico |

SCHEMA_VERSION 14 e `sw.js` R14.23-SW2 (`868972f4…`) inalterados em todas.

## 1. Artérias uterinas (R14.36)

- **Via:** cada exame novo começa com **transabdominal** pré-selecionada (`VIA_UT='ta'`, `VIA_UT_PADRAO=true`), por decisão do médico: é a via de quase todos os exames do serviço. No 1º trimestre (IG < 14 semanas; sem IG, contexto de 1º trimestre), enquanto a via não for tocada, um aviso pede para confirmá-la. As duas vias são usadas nessa fase. Com a curva de Gómez, o aviso acrescenta que ela é transvaginal no 1º trimestre e que, para medida transabdominal, a curva compatível é Cavoretto. A compatibilidade curva × via × IG (`utRefCompativel`) continua decidindo se o app classifica: Gómez <15 sem só TV, 15–41 TA; Cavoretto TA 10–39 (CÓDIGO; fontes no `01`, seção 2.6).
- **Barrinha por lado:** sob cada artéria, uma barrinha de percentil **só de consulta**, colorida e ao vivo, pela mesma curva, via e IG do IP médio. O rótulo nunca contradiz o p95; quem classifica continua sendo o **IP médio** (decisão C0-B2). Sem via, ou com curva/via/IG incompatível, a barrinha não aparece.
- **Incisura:** um quadradinho por lado, marcado só quando presente. Estado por lado (`incSt`): marcado = presente; desmarcado com o IP daquele lado medido = ausente; sem IP = não avaliada. O laudo cita só a presença (uni/bilateral; "à direita; esquerda não avaliada" quando só um lado foi medido). Exame salvo no schema antigo é recuperado com aviso.
- **Efeito no laudo (diferencial R14.35 × R14.39, 300 exames aleatórios):** todas as diferenças vêm da incisura (95 laudos; 48 contadores de aba), como decidido. Nenhuma outra linha mudou.

## 2. Interface (R14.37–R14.38)

Aprovada sobre prints de antes/depois; **botões e fontes mantidos** (o médico recusou essa parte).

- Medidas começa pela biometria (síntese, sequência e guia foram para o fim da aba, onde não empurram os campos).
- Abas fixas no rodapé; somem enquanto se digita.
- "Confira antes de laudar": cada aviso mostra a 1ª frase e o restante abre em "por quê" (`chkParte`). O texto é o mesmo de antes, só dobrado: nunca corta dentro de negrito/itálico nem em abreviação, e aviso com resto curto fica inteiro. O aviso de Hadlock tem resumo próprio. Diferencial R14.36 × R14.37: 2.176 avisos, nenhum perdeu texto.
- Barra fixa **Copiar laudo · Copiar conclusão** na aba Laudo. A conclusão copiada é o trecho do laudo a partir de "CONCLUSÃO".
- Simetria: etiqueta à direita no cabeçalho dos cards; "· opcional" junto do título; unidade centrada no campo; Fíbula na grade; diástole umbilical em linha própria (barras alinhadas); pares de campos nivelados quando um rótulo quebra em 2 linhas (telas < 360 px).
- **Campo parado:** se algo acima do campo em edição cresce ou some, a página rola a mesma diferença (`ancFixa`). Antes, digitar na biometria podia deslocar o campo 140 px. Limite: no fim da página, se o conteúdo abaixo encolher, o navegador recorta a rolagem (até ~13 px).

## 3. Tamanho do bebê (R14.39)

- **Pedido do médico:** informar à paciente o tamanho do bebê, sem entrar no laudo.
- **Fórmula:** comprimento (cm) = 6,18 + 0,59 × fêmur (mm). Vintzileos AM, Campbell WA, Neckles S, Pike CL, Nochimson DJ. *The ultrasound femur length as a predictor of fetal length.* Obstet Gynecol 1984;64(6):779-82, PMID 6390277 (RESUMO: a fórmula está no próprio resumo).
- **Erro:** Milner LL et al., J Clin Ultrasound 1994;22:253-6, DOI 10.1002/jcu.1870220407 (RESUMO): entre seis funções publicadas, a de Vintzileos foi a melhor para gestação única, sem erro sistemático e com erro aleatório de ±6%. Hadlock FP et al., J Ultrasound Med 1984;3:1-3, DOI 10.7863/jum.1984.3.1.1 (RESUMO): relação linear, r² 0,66, desvio-padrão de 2,4 cm.
- **Faixa do fêmur 30–90 mm:** vem da calculadora de perinatology.com (SECUNDÁRIA), não do artigo. Os termos MeSH do artigo indicam 3º trimestre. O app aplica a faixa como limite de exibição e, além dela, respeita a plausibilidade do fêmur.
- **Limitação:** Lim JM et al., UOG 2000;15:131-7, DOI 10.1046/j.1469-0705.2000.00053.x (RESUMO): a relação fêmur × comprimento difere entre populações (até 1,1 cm). A fórmula não foi validada na população brasileira.
- **Hierarquia:** FEBRASGO, ISUOG, Rumack e CBR não trazem fórmula de comprimento fetal. A fonte está **fora da hierarquia** e foi autorizada explicitamente pelo médico em 10/10/2026.
- **Implementação (CÓDIGO):** linha "Para a paciente" sob o peso na aba Medidas, com número redondo e faixa ±6%; só no modo "pela biometria" e com fêmur 3,0–9,0 cm. Nunca no laudo, na conclusão ou na cópia (regra R14.8: o que vai ao laudo tem de estar na interface clínica, e este dado é só informativo). O Modo Paciente já mostrava "Comprimento" pela mesma fórmula desde a R14.5, sem limite de fêmur; passou a seguir a mesma faixa. Teste: 1.001 valores de fêmur (1,00–11,00 cm), nos dois navegadores.

## 4. Correções de interface (R14.38–R14.40)

- "Próximo pendente" ficava dentro da aba Laudo (`#p3`) e, na R14.37, atrás das barras do rodapé. Agora fica no `body`, aparece em todas as abas, acima das barras, e leva ao campo que falta.
- O aviso rápido ("Copiado") ficava sobre as abas; agora fica acima delas.
- "por quê" abre e fecha com Enter ou espaço.
- Em 320 px: nada vaza da tela; as etiquetas do cabeçalho do card descem para a 2ª linha.
- Lição registrada: regras novas com a mesma especificidade das antigas, declaradas antes delas no CSS, **perdem**. Isso aconteceu com `.prox`, `.toast` e `.qr .v`, todas corrigidas com `body` na frente.

## 5. Pente fino da R14.39 → R14.40

| Verificação | Resultado |
|---|---|
| Suíte de regressão (18 grupos), Chromium e WebKit | 63.832 checagens, 0 falhas (R14.39 e R14.40) |
| Diferencial R14.39 × R14.40 (200 exames) | laudo, conclusão, avisos, estado e contadores idênticos |
| Diferencial R14.35 × R14.39 (300 exames) | só a incisura difere, como decidido |
| Bateria de interface A–I (sobreposição, 320–430 px, campo parado, clique em tudo nos contextos A/B/gemelar, 1º tri, recuperação, cópia real, teclado, tema escuro) | sem falhas nos dois navegadores |
| Offline (service worker) e atualização online | abre a versão nova; sem rede, a última válida |
| Exame salvo na R14.36 recuperado na versão nova | laudo idêntico, com aviso de versão |
| Sintaxe (node) e ESLint (erros: no-undef, no-redeclare, no-dupe-keys etc.) | sem erro real; restam `z!==z` (teste de NaN, proposital) e `var` redeclarado em ramos diferentes |
| Cascata de CSS | duas regras novas sem efeito → corrigidas na R14.40 |
| IDs | nenhuma referência a ID inexistente |
| Textos da tela | sem espaço duplo, pontuação solta ou palavra repetida |

**Achado operacional, não do código:** em 10/10/2026, às 13:55, `index.html`, `CONTEXTO.md`, `README.md` e a suíte foram excluídos do GitHub sem reenvio. O site ficou em 404 (o service worker não mascara 404 com a internet ligada). O README passou a orientar: envie primeiro, apague depois.

## 6. Pendências

- Publicar a R14.40 (`index.html`, `CONTEXTO.md`, `README.md`, `suite_regressao_doppler.py`) e conferir o site.
- Testar em iPhone físico: teclado sobre as barras do rodapé, área segura (home indicator), campo parado com teclado aberto, datas, offline e atualização.
- D3 (zoom bloqueado): só com teste no aparelho.
- Tamanho do bebê: sem validação na população brasileira (seção 3).
