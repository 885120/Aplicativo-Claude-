# Extração legível de MODELOS_APROVADOS_DE_LAUDOS

Extração do corpo e tabelas em ordem documental. Consulte o DOCX original para layout, cabeçalhos, imagens e formatação.

MODELOS APROVADOS
DE LAUDOS ULTRASSONOGRÁFICOS

Base operacional do projeto Digitador de Laudos 2.0 / Ultralaudo AI

Responsável médico | Dr. Diogo S. Ribeiro - CRM 5789/AL
Versão | 1.0
Data de consolidação | 22/07/2026
Status | Referência interna para validação e uso médico

Documento sem dados identificáveis de pacientes




1. Natureza e regras de uso

Finalidade: Fornecer modelos normais padronizados para elaboração e auditoria de laudos, preservando o estilo do Dr. Diogo S. Ribeiro e a abrangência técnica definida pelo CBR.

Fonte primária dos dados do paciente: As anotações do médico, medidas objetivas, imagens documentadas, cálculos verificáveis e confirmações expressas. Estes modelos não autorizam presumir normalidade nem preencher dados ausentes.

Função dos modelos: Fornecer estrutura, ordem anatômica, terminologia e redação padronizada dos componentes efetivamente examinados. Trechos devem ser mantidos, removidos ou adaptados conforme o documento-fonte de cada exame.

Validação: Todo laudo gerado ou corrigido deve passar por conferência médica final antes de assinatura, impressão ou entrega.

REGRA DE SEGURANÇA: a ausência de informação nunca deve ser convertida em normalidade. Nenhum achado, medida, classificação, diagnóstico ou recomendação pode ser inserido sem base rastreável.

2. Hierarquia das fontes

Confirmação expressa do médico.

Documento-fonte do exame, incluindo PDF de anotações, medidas e imagens documentadas.

Princípios globais de rastreabilidade, não extrapolação e controle de inferência.

Manual Mestre de Auditoria de Laudos.

Modelos aprovados deste documento.

Conhecimento médico geral, apenas como apoio e nunca para preencher lacunas.

3. Convenções dos modelos

[CAMPO] indica dado que deve ser preenchido exclusivamente a partir da fonte.

Trechos entre chaves {OPÇÃO A / OPÇÃO B} são mutuamente exclusivos e exigem seleção médica.

Linhas iniciadas por “Opcional” só devem constar quando o item foi efetivamente avaliado e documentado.

Quando uma estrutura não foi avaliada ou não pôde ser caracterizada, registrar a limitação, em vez de descrevê-la como normal.

Os exames com Doppler devem indicar vaso/estrutura, índice, valor, lateralidade e interpretação segundo a referência aplicável.

Na obstetrícia de 2º e 3º trimestres, o PFE deve vir acompanhado do percentil e da tabela/curva utilizada. A idade gestacional previamente estabelecida não deve ser redatada pelas medidas atuais.

4. Fontes de elaboração

Base primária: anexos do e-mail “Fwd: modelos de laudos 2026”, recebido em 22/07/2026, incluindo modelos de abdome, vias urinárias, próstata, pelve/transvaginal, gestação, tireoide, mamas, parede abdominal e musculoesquelético. Dados de pacientes, cabeçalhos de clínicas, datas e assinaturas foram removidos.

Complementação normativa: Normatização de Exames de Ultrassonografia do CBR, Revisão 2026, cuja Parte II corresponde ao consenso CBR-FEBRASGO para ginecologia e obstetrícia; pareceres oficiais do CBR para ultrassonografia mamária e BI-RADS.

5. Índice dos modelos

Abdome e pelve

Abdome total

Abdome superior

Rins e vias urinárias

Próstata por via abdominal

Pelve feminina transabdominal

Transvaginal

Parede abdominal

Região inguinal

Partes moles

Obstetrícia

Gestação inicial endovaginal

Gestação de 2º/3º trimestres

Gestação com Dopplerfluxometria

Gestação gemelar

Translucência nucal

Perfil biofísico fetal

Colo uterino obstétrico

Pequenas partes

Tireoide

Mamas

Região cervical

Axila

Bolsa escrotal com Doppler

Glândulas salivares

Musculoesquelético

Ombro

Cotovelo

Punho

Joelho

Tornozelo

Pé/fáscia plantar

Músculo ou tendão localizado




1. Ultrassonografia de Abdome Total

Origem e harmonização: Adaptado de “ABDOME TOTAL NORMAL.doc” e “ABDOME TOTAL COMPLETO.doc”; abrangência atualizada conforme CBR 2026.

NOME: [NOME] / IDADE: [IDADE]    DN: [DD/MM/AAAA]    DATA: [DD/MM/AAAA] / ULTRASSONOGRAFIA DE ABDOME TOTAL / TÉCNICA / Exame realizado por via transabdominal com transdutor convexo multifrequencial, mediante varredura multiplanar. / ACHADOS / Fígado com dimensões e contornos preservados, apresentando ecogenicidade e ecotextura homogêneas, sem lesões focais detectáveis ao método. / Veia porta com calibre preservado. Veias hepáticas sem alterações evidentes. / Vias biliares intra e extra-hepáticas sem dilatação. / Vesícula biliar adequadamente distendida, com paredes finas e regulares, conteúdo anecoico, sem imagens calculosas. / Pâncreas com dimensões, contornos e ecotextura preservados nas porções visualizadas. / Baço com dimensões, contornos e ecotextura preservados. / Rim direito medindo [COMPRIMENTO] x [AP] cm e rim esquerdo medindo [COMPRIMENTO] x [AP] cm, em topografia habitual, com contornos regulares, espessura parenquimatosa preservada e diferenciação corticomedular mantida. Ausência de dilatação pielocalicinal e de imagens calculosas detectáveis. / Aorta abdominal e veia cava inferior com calibres preservados nos segmentos avaliados. / Bexiga com repleção [ADEQUADA/LIMITADA], paredes finas e regulares e conteúdo anecoico homogêneo. / Não se evidencia líquido livre na cavidade abdominal. / CONCLUSÃO / Exame ultrassonográfico de abdome total sem alterações significativas nas estruturas avaliadas.

PONTOS DE CONTROLE PARA AUDITORIA / Abdome total não inclui útero, ovários, próstata, vesículas seminais nem parede abdominal. / Não afirmar normalidade do pâncreas quando a visualização for limitada por interposição gasosa; descrever a limitação. / Resíduo pós-miccional somente quando efetivamente aferido ou clinicamente pertinente.




2. Ultrassonografia de Abdome Superior

Origem e harmonização: Derivado do modelo de abdome do e-mail e delimitado conforme CBR 2026.

NOME: [NOME] / IDADE: [IDADE]    DN: [DD/MM/AAAA]    DATA: [DD/MM/AAAA] / ULTRASSONOGRAFIA DE ABDOME SUPERIOR / TÉCNICA / Exame realizado por via transabdominal com transdutor convexo multifrequencial, mediante varredura multiplanar. / ACHADOS / Fígado com dimensões e contornos preservados, apresentando ecogenicidade e ecotextura homogêneas, sem lesões focais detectáveis ao método. / Veia porta com calibre preservado. / Vias biliares intra e extra-hepáticas sem dilatação. / Vesícula biliar adequadamente distendida, com paredes finas e regulares, conteúdo anecoico, sem imagens calculosas. / Pâncreas com dimensões, contornos e ecotextura preservados nas porções visualizadas. / Baço com dimensões, contornos e ecotextura preservados. / CONCLUSÃO / Exame ultrassonográfico de abdome superior sem alterações significativas nas estruturas avaliadas.

PONTOS DE CONTROLE PARA AUDITORIA / Abdome superior não inclui rins, bexiga, aorta abdominal, veia cava inferior, parede abdominal nem órgãos pélvicos.




3. Ultrassonografia dos Rins e Vias Urinárias

Origem e harmonização: Adaptado de “RINS E VIAS URINARIAS NORMAL.doc”; abrangência atualizada conforme CBR 2026.

NOME: [NOME] / IDADE: [IDADE]    DN: [DD/MM/AAAA]    DATA: [DD/MM/AAAA] / ULTRASSONOGRAFIA DOS RINS E VIAS URINÁRIAS / TÉCNICA / Exame realizado por via transabdominal com transdutor convexo multifrequencial, com avaliação renal bilateral e vesical. / ACHADOS / Rim direito em topografia habitual, medindo [COMPRIMENTO] x [AP] cm, com contornos regulares, espessura parenquimatosa preservada e diferenciação corticomedular mantida. / Rim esquerdo em topografia habitual, medindo [COMPRIMENTO] x [AP] cm, com contornos regulares, espessura parenquimatosa preservada e diferenciação corticomedular mantida. / Ausência de dilatação dos sistemas pielocalicinais e de imagens calculosas detectáveis ao método. / Bexiga com volume pré-miccional estimado em [VOLUME] mL, paredes finas e regulares e conteúdo anecoico homogêneo. / Opcional, quando aferido: volume pós-miccional estimado em [VOLUME] mL, correspondendo a resíduo de [PERCENTUAL]%. / CONCLUSÃO / Rins e bexiga sem alterações ultrassonográficas significativas. / Opcional, quando aferido: resíduo vesical pós-miccional de [VOLUME] mL.

PONTOS DE CONTROLE PARA AUDITORIA / Os ureteres e as adrenais são citados apenas quando houver achado demonstrável. / Não incluir próstata, útero ou ovários neste exame. / A ausência de cálculo ao ultrassom não exclui microlitíase ou cálculo ureteral não visualizado.




4. Ultrassonografia da Próstata por Via Abdominal

Origem e harmonização: Adaptado de “PRÓSTATA.doc”; conteúdo mínimo harmonizado com CBR 2026.

NOME: [NOME] / IDADE: [IDADE]    DN: [DD/MM/AAAA]    DATA: [DD/MM/AAAA] / ULTRASSONOGRAFIA DA PRÓSTATA POR VIA ABDOMINAL / TÉCNICA / Exame realizado por via transabdominal, com avaliação da bexiga, próstata e vesículas seminais, antes e após a micção. / ACHADOS / Bexiga com volume pré-miccional estimado em [VOLUME] mL, paredes finas e regulares e conteúdo anecoico homogêneo. / Próstata com contornos regulares e ecotextura homogênea, medindo [LONGITUDINAL] x [TRANSVERSO] x [AP] cm, com volume estimado em [VOLUME] cm³. / Ausência de lesões focais detectáveis ao método pela via abdominal. / Vesículas seminais simétricas, com dimensões e ecotextura preservadas. / Após a micção, o volume vesical residual foi estimado em [VOLUME] mL. / CONCLUSÃO / Próstata com volume estimado em [VOLUME] cm³, sem alterações focais detectáveis pela via abdominal. / Resíduo vesical pós-miccional de [VOLUME] mL.

PONTOS DE CONTROLE PARA AUDITORIA / Não declarar “volume normal para a idade” sem critério e correlação apropriados. / O ultrassom transabdominal não substitui avaliação clínica, PSA ou exame digital quando indicados. / Confirmar todas as três medidas antes do cálculo volumétrico.




5. Ultrassonografia da Pelve Feminina por Via Transabdominal

Origem e harmonização: Adaptado de “PELVE E ENDO NORMAL .doc”; abrangência conforme CBR 2026.

NOME: [NOME] / IDADE: [IDADE]    DN: [DD/MM/AAAA]    DATA: [DD/MM/AAAA] / ULTRASSONOGRAFIA DA PELVE FEMININA POR VIA TRANSABDOMINAL / TÉCNICA / Exame realizado por via transabdominal com bexiga repleta, mediante varredura multiplanar. / ACHADOS / Bexiga com paredes finas e regulares e conteúdo anecoico homogêneo. / Útero em [ANTEVERSÃO/RETROVERSÃO], com contornos regulares e ecotextura miometrial homogênea, medindo [LONGITUDINAL] x [AP] x [TRANSVERSO] cm, com volume estimado em [VOLUME] cm³. / Endométrio centrado e homogêneo, medindo [ESPESSURA] cm. / Ovário direito medindo [MEDIDAS] cm, com volume estimado em [VOLUME] cm³, apresentando morfologia e ecotextura preservadas. / Ovário esquerdo medindo [MEDIDAS] cm, com volume estimado em [VOLUME] cm³, apresentando morfologia e ecotextura preservadas. / Regiões anexiais sem massas. / Ausência de líquido livre significativo no fundo de saco posterior. / CONCLUSÃO / Útero e ovários sem alterações ultrassonográficas significativas. / Endométrio medindo [ESPESSURA] cm, a correlacionar com fase do ciclo menstrual, estado menopausal e uso hormonal, quando informados.

PONTOS DE CONTROLE PARA AUDITORIA / Não classificar a espessura endometrial como normal sem conhecer o contexto clínico pertinente. / Em massas ovarianas/anexiais, aplicar léxico e classificação recomendados (O-RADS/IOTA/IETA/MUSA) somente com achados suficientes.




6. Ultrassonografia Transvaginal

Origem e harmonização: Adaptado dos modelos de pelve/transvaginal do e-mail; conteúdo mínimo conforme CBR 2026.

NOME: [NOME] / IDADE: [IDADE]    DN: [DD/MM/AAAA]    DATA: [DD/MM/AAAA] / ULTRASSONOGRAFIA TRANSVAGINAL / TÉCNICA / Exame realizado por via endovaginal com transdutor multifrequencial, mediante varredura multiplanar. / ACHADOS / Útero em [ANTEVERSÃO/RETROVERSÃO], com contornos regulares e ecotextura miometrial homogênea, medindo [LONGITUDINAL] x [AP] x [TRANSVERSO] cm, com volume estimado em [VOLUME] cm³. / Colo uterino com morfologia preservada. / Endométrio centrado e homogêneo, medindo [ESPESSURA] cm. / Ovário direito medindo [MEDIDAS] cm, com volume estimado em [VOLUME] cm³, apresentando morfologia e ecotextura preservadas. / Ovário esquerdo medindo [MEDIDAS] cm, com volume estimado em [VOLUME] cm³, apresentando morfologia e ecotextura preservadas. / Regiões anexiais sem massas. / Ausência de líquido livre significativo no fundo de saco posterior. / CONCLUSÃO / Exame transvaginal sem alterações ultrassonográficas significativas. / Endométrio medindo [ESPESSURA] cm, a correlacionar com o contexto clínico.

PONTOS DE CONTROLE PARA AUDITORIA / A vagina não precisa ser descrita quando não houver achado demonstrável. / A avaliação transabdominal complementar não deve ser presumida; documentar apenas se realizada. / Doppler não deve ser inferido quando não solicitado/realizado.




7. Ultrassonografia da Parede Abdominal

Origem e harmonização: Adaptado de “PAREDE ABDOMINAL.doc”; abrangência delimitada conforme CBR 2026.

NOME: [NOME] / IDADE: [IDADE]    DN: [DD/MM/AAAA]    DATA: [DD/MM/AAAA] / ULTRASSONOGRAFIA DA PAREDE ABDOMINAL / TÉCNICA / Exame direcionado à parede abdominal anterior com transdutor linear multifrequencial, em repouso e durante manobras dinâmicas, incluindo Valsalva. / ACHADOS / Pele e tecido celular subcutâneo com espessura e ecogenicidade preservadas na região examinada. / Planos músculo-aponeuróticos da parede abdominal com espessura, continuidade e ecotextura preservadas. / Não se observam defeitos aponeuróticos ou protrusões herniárias durante as manobras realizadas. / Linha alba sem descontinuidade. Opcional, quando medido: distância entre as bordas mediais dos músculos retos abdominais de [MEDIDA] cm no nível [LOCAL]. / Ausência de coleções ou massas superficiais detectáveis. / CONCLUSÃO / Parede abdominal sem alterações ultrassonográficas significativas na região examinada.

PONTOS DE CONTROLE PARA AUDITORIA / Regiões inguinais constituem exame separado. / Quando houver diástase, informar nível e medida máxima; não concluir apenas por impressão visual. / Não incluir órgãos intra-abdominais ou pélvicos neste modelo.




8. Ultrassonografia da Região Inguinal

Origem e harmonização: Modelo complementado segundo a abrangência da Normatização CBR 2026.

NOME: [NOME] / IDADE: [IDADE]    DN: [DD/MM/AAAA]    DATA: [DD/MM/AAAA] / ULTRASSONOGRAFIA DA REGIÃO INGUINAL / TÉCNICA / Exame direcionado à região inguinal [DIREITA/ESQUERDA/BILATERAL] com transdutor linear multifrequencial, em repouso e durante Valsalva e ortostatismo, quando aplicável. / ACHADOS / Pele, tecido celular subcutâneo e planos músculo-aponeuróticos com aspecto preservado. / Canal inguinal sem protrusão de conteúdo abdominal durante as manobras dinâmicas. / Ausência de massas, coleções ou linfonodos com características atípicas na região examinada. / CONCLUSÃO / Região inguinal [DIREITA/ESQUERDA/BILATERAL] sem evidência de hérnia ou outras alterações ultrassonográficas significativas.

PONTOS DE CONTROLE PARA AUDITORIA / Registrar lateralidade e manobras efetivamente realizadas.




9. Ultrassonografia de Partes Moles

Origem e harmonização: Modelo genérico complementado segundo a delimitação regional do CBR.

NOME: [NOME] / IDADE: [IDADE]    DN: [DD/MM/AAAA]    DATA: [DD/MM/AAAA] / ULTRASSONOGRAFIA DE PARTES MOLES / TÉCNICA / Exame direcionado à região [LOCAL E LATERALIDADE] com transdutor linear multifrequencial, incluindo comparação contralateral quando pertinente. / ACHADOS / Pele e tecido celular subcutâneo com espessura e ecogenicidade preservadas. / Fáscias e planos musculares identificados apresentam continuidade e ecotextura mantidas. / Ausência de massas sólidas, coleções ou alterações císticas detectáveis na região examinada. / Opcional, quando Doppler foi realizado: não se observa hiperemia focal ao mapeamento colorido. / CONCLUSÃO / Partes moles da região [LOCAL] sem alterações ultrassonográficas significativas.

PONTOS DE CONTROLE PARA AUDITORIA / Especificar local e lateralidade; evitar o termo genérico sem delimitação anatômica. / Não declarar ausência de lesão fora da área efetivamente examinada.




10. Ultrassonografia Obstétrica Inicial (Endovaginal)

Origem e harmonização: Adaptado de “GESTAÇÃO INICIAL.doc” e atualizado pelo consenso CBR-FEBRASGO 2026.

NOME: [NOME] / IDADE: [IDADE]    DN: [DD/MM/AAAA]    DATA: [DD/MM/AAAA] / ULTRASSONOGRAFIA OBSTÉTRICA INICIAL (ENDOVAGINAL) / TÉCNICA / Exame realizado por via endovaginal com transdutor multifrequencial. / DUM informada: [DD/MM/AAAA / DESCONHECIDA]. Idade gestacional pela DUM: [SEMANAS E DIAS]. / ACHADOS / Útero gravídico em [ANTEVERSÃO/RETROVERSÃO], com morfologia preservada. / Saco gestacional intrauterino, de implantação [LOCAL], com contornos regulares. Diâmetro médio de [MEDIDA] mm, somente quando aplicável antes da visualização embrionária. / Visualiza-se [UM/DOIS] embrião(ões). Comprimento cabeça-nádegas (CCN) de [MEDIDA] mm, correspondente a [SEMANAS E DIAS]. / Atividade cardíaca embrionária presente, com frequência de [FC] bpm. / Movimentos embrionários [PRESENTES/NÃO APLICÁVEIS À IDADE GESTACIONAL]. / Vesícula vitelina com aspecto habitual. Membrana e cavidade amnióticas identificadas conforme a idade gestacional. / Trofoblasto/placenta em formação de localização [LOCAL], sem área de descolamento identificável. / Ovários com morfologia preservada. Corpo lúteo no ovário [DIREITO/ESQUERDO], quando identificado. / Regiões anexiais sem massas. Ausência de líquido livre significativo no fundo de saco posterior. / Opcional, quando avaliado: colo uterino medindo [MEDIDA] cm, fechado. / CONCLUSÃO / Gestação intrauterina [ÚNICA/GEMELAR], com vitalidade embrionária presente, estimada em [SEMANAS E DIAS] pelo CCN. / Data provável do parto pela ultrassonografia: [DD/MM/AAAA].

PONTOS DE CONTROLE PARA AUDITORIA / Após a visualização do embrião, a datação deve basear-se no CCN, não no diâmetro médio do saco gestacional. / Documentar DUM ou seu desconhecimento e aplicar os critérios de discordância definidos pelo consenso CBR-FEBRASGO. / Em gestação múltipla, definir corionicidade e amnionicidade.




11. Ultrassonografia Obstétrica de 2º e 3º Trimestres

Origem e harmonização: Adaptado de “GESTAÇÃO.doc” e “GESTAÇÃO COMPLETO.doc”; atualizado pelo consenso CBR-FEBRASGO 2026.

NOME: [NOME] / IDADE: [IDADE]    DN: [DD/MM/AAAA]    DATA: [DD/MM/AAAA] / ULTRASSONOGRAFIA OBSTÉTRICA DE 2º E 3º TRIMESTRES / TÉCNICA / Exame realizado por via transabdominal com transdutor convexo multifrequencial. / Idade gestacional estabelecida por [DUM/US PRÉVIA]: [SEMANAS E DIAS]. / ACHADOS / Feto único, em situação longitudinal e apresentação [CEFÁLICA/PÉLVICA/CÓRMICA]. / Atividade cardíaca fetal rítmica, com frequência de [FC] bpm. Movimentos fetais presentes. / Biometria fetal: DBP [MEDIDA] mm; CC [MEDIDA] mm; CA [MEDIDA] mm; CF [MEDIDA] mm; CH [MEDIDA] mm, quando aferido. / Peso fetal estimado em [PFE] g, correspondente ao percentil [PERCENTIL] para a idade gestacional, segundo a curva/tabela [REFERÊNCIA]. / Estruturas fetais avaliadas: calota craniana e estruturas intracranianas básicas; face nas porções acessíveis; quatro câmaras cardíacas e eixo cardíaco; estômago, rins e bexiga; parede abdominal; coluna e membros. Não se observam alterações evidentes nas estruturas adequadamente visualizadas. / Placenta de localização [LOCAL], com textura e maturidade compatíveis com a idade gestacional. Borda inferior a [DISTÂNCIA] cm do orifício interno do colo, quando pertinente. / Cordão umbilical com [TRÊS VASOS / NÚMERO NÃO CARACTERIZADO], inserção [CENTRAL/PARACENTRAL/MARGINAL], quando avaliada. / Líquido amniótico em volume [NORMAL], avaliado por [MAIOR BOLSÃO = MEDIDA cm / ILA = MEDIDA cm]. / Opcional, quando indicado: colo uterino medindo [MEDIDA] cm. / CONCLUSÃO / Gestação de [SEMANAS E DIAS], conforme datação obstétrica estabelecida. / Peso fetal estimado: [PFE] g, percentil [PERCENTIL] pela referência [TABELA/CURVA]. / Data provável do parto: [DD/MM/AAAA].

PONTOS DE CONTROLE PARA AUDITORIA / Alerta máximo: PFE sem percentil deve ser sinalizado, nunca interpretado como crescimento adequado. / A idade gestacional previamente estabelecida não deve ser alterada pelas medidas do exame atual. / Não denominar exame de rotina como morfológico nem afirmar exclusão de malformações.




12. Ultrassonografia Obstétrica com Dopplerfluxometria

Origem e harmonização: Modelo construído a partir do consenso CBR-FEBRASGO 2026, com atenção prioritária ao PFE e ao Doppler.

Modelo parametrizado. Antes de interpretar, conferir vaso, lateralidade, índice, valor, idade gestacional e referência; calcular o IP médio das artérias uterinas e o ICP = IP da ACM / IP da artéria umbilical, sem inverter a razão. A conclusão “normal” somente pode ser usada após essa conferência. Qualquer dúvida, ausência de percentil ou referência, ou inconsistência exige revisão médica.

NOME: [NOME] / IDADE: [IDADE]    DN: [DD/MM/AAAA]    DATA: [DD/MM/AAAA] / ULTRASSONOGRAFIA OBSTÉTRICA COM DOPPLERFLUXOMETRIA / TÉCNICA / Exame obstétrico de rotina associado à Dopplerfluxometria, realizado por via transabdominal. / Idade gestacional estabelecida: [SEMANAS E DIAS], por [DUM/US PRÉVIA]. / ACHADOS / Feto único, em apresentação [APRESENTAÇÃO], com atividade cardíaca rítmica e movimentos presentes. / Biometria: DBP [MEDIDA] mm; CC [MEDIDA] mm; CA [MEDIDA] mm; CF [MEDIDA] mm. / Peso fetal estimado em [PFE] g, percentil [PERCENTIL] pela referência [CURVA/TABELA]. / Placenta de localização [LOCAL]. Líquido amniótico avaliado por [MAIOR BOLSÃO/ILA], medindo [VALOR] cm. / Artéria uterina direita: IP [VALOR]. Artéria uterina esquerda: IP [VALOR]. IP médio das artérias uterinas: [VALOR], correspondente ao percentil [PERCENTIL/FAIXA] para a idade gestacional segundo [REFERÊNCIA]. / Artéria umbilical: IR [VALOR]; IP [VALOR], correspondente ao percentil [PERCENTIL/FAIXA]. Fluxo diastólico final [PRESENTE/AUSENTE/REVERSO]. / Artéria cerebral média: IR [VALOR]; IP [VALOR], correspondente ao percentil [PERCENTIL/FAIXA]. Velocidade sistólica máxima [VALOR] cm/s ([MoM], quando indicada). / Índice cérebro-placentário (ICP = IP da ACM / IP da artéria umbilical): [VALOR], correspondente ao percentil [PERCENTIL/FAIXA] segundo [REFERÊNCIA]. / Ducto venoso, quando indicado: IP [VALOR], onda “a” [POSITIVA/AUSENTE/REVERSA]. / CONCLUSÃO / Doppler das artérias uterinas [DENTRO/FORA] dos limites esperados para a idade gestacional. / Doppler fetoplacentário [DENTRO/FORA] dos limites esperados para a idade gestacional. / Índice cérebro-placentário [DENTRO/ABAIXO] da referência utilizada. / Peso fetal estimado: [PFE] g, percentil [PERCENTIL]. / Data provável do parto: [DD/MM/AAAA].




13. Ultrassonografia Obstétrica de Gestação Gemelar

Origem e harmonização: Adaptado de “GESTAÇÃO GEMELAR.doc” e atualizado com requisitos do consenso CBR-FEBRASGO 2026.

NOME: [NOME] / IDADE: [IDADE]    DN: [DD/MM/AAAA]    DATA: [DD/MM/AAAA] / ULTRASSONOGRAFIA OBSTÉTRICA DE GESTAÇÃO GEMELAR / TÉCNICA / Exame realizado por via transabdominal. Idade gestacional estabelecida: [SEMANAS E DIAS]. / ACHADOS / Gestação gemelar [DICORIÔNICA-DIAMNIÓTICA/MONOCORIÔNICA-DIAMNIÓTICA/MONOCORIÔNICA-MONOAMNIÓTICA], conforme [CRITÉRIO/DOCUMENTAÇÃO PRÉVIA]. / FETO 1: apresentação [APRESENTAÇÃO], FCF [FC] bpm, movimentos presentes. DBP [ ]; CC [ ]; CA [ ]; CF [ ]. PFE [ ] g, percentil [ ] pela referência [ ]. Líquido amniótico: maior bolsão [ ] cm. / FETO 2: apresentação [APRESENTAÇÃO], FCF [FC] bpm, movimentos presentes. DBP [ ]; CC [ ]; CA [ ]; CF [ ]. PFE [ ] g, percentil [ ] pela referência [ ]. Líquido amniótico: maior bolsão [ ] cm. / Discordância de peso fetal estimado: [PERCENTUAL]%. / Placenta(s) de localização [LOCALIZAÇÃO], com aspecto compatível com a idade gestacional. / Colos uterino e anexos: [DESCRIÇÃO, QUANDO AVALIADOS]. / CONCLUSÃO / Gestação gemelar [CORIONICIDADE/AMNIONICIDADE], com [SEMANAS E DIAS]. / Feto 1: PFE [ ] g, percentil [ ]. Feto 2: PFE [ ] g, percentil [ ]. Discordância de PFE: [ ]%. / Data provável do parto: [DD/MM/AAAA].

PONTOS DE CONTROLE PARA AUDITORIA / Corionicidade e amnionicidade são obrigatórias quando determináveis. / PFE e percentil devem ser informados separadamente para cada feto. / Não misturar medidas, placenta ou Doppler entre os fetos.




14. Ultrassonografia Obstétrica com Medida da Translucência Nucal

Origem e harmonização: Modelo complementado segundo o consenso CBR-FEBRASGO 2026.

NOME: [NOME] / IDADE: [IDADE]    DN: [DD/MM/AAAA]    DATA: [DD/MM/AAAA] / ULTRASSONOGRAFIA OBSTÉTRICA COM MEDIDA DA TRANSLUCÊNCIA NUCAL / TÉCNICA / Exame realizado entre 11 semanas e 13 semanas + 6 dias, por via [ABDOMINAL/ENDOVAGINAL]. / ACHADOS / Feto único, com CCN de [MEDIDA] mm, correspondente a [SEMANAS E DIAS]. / Atividade cardíaca presente, FCF [FC] bpm. Movimentos fetais presentes. / Translucência nucal medindo [MEDIDA] mm, correspondente ao percentil [PERCENTIL/FAIXA] para o CCN segundo [REFERÊNCIA]. / Osso nasal [PRESENTE/NÃO CARACTERIZADO]. / Crânio, foice cerebral, plexos coroides, parede abdominal, estômago, bexiga e quatro membros identificados nas condições do exame. / Placenta de localização [LOCAL]. Líquido amniótico em volume habitual. / Ovários e regiões anexiais sem alterações significativas. / CONCLUSÃO / Gestação de [SEMANAS E DIAS] pelo CCN. / Translucência nucal de [MEDIDA] mm, [INTERPRETAÇÃO] para o CCN segundo [REFERÊNCIA]. / Data provável do parto: [DD/MM/AAAA].

PONTOS DE CONTROLE PARA AUDITORIA / A medida deve seguir protocolo técnico validado e faixa de CCN de 45 a 84 mm.




15. Ultrassonografia Obstétrica com Perfil Biofísico Fetal

Origem e harmonização: Modelo complementado segundo o consenso CBR-FEBRASGO 2026.

NOME: [NOME] / IDADE: [IDADE]    DN: [DD/MM/AAAA]    DATA: [DD/MM/AAAA] / ULTRASSONOGRAFIA OBSTÉTRICA COM PERFIL BIOFÍSICO FETAL / TÉCNICA / Exame obstétrico associado à avaliação ultrassonográfica do perfil biofísico fetal, com observação por até 30 minutos. / ACHADOS / Movimentos corporais: [PRESENTES/AUSENTES], pontuação [0/2]. / Tônus fetal: [PRESENTE/AUSENTE], pontuação [0/2]. / Movimentos respiratórios: [PRESENTES/AUSENTES], pontuação [0/2]. / Líquido amniótico: maior bolsão vertical [MEDIDA] cm, pontuação [0/2]. / Pontuação ultrassonográfica total: [0/8, 2/8, 4/8, 6/8 ou 8/8]. / Demais dados obstétricos: [FETO, FCF, PLACENTA, BIOMETRIA/PFE QUANDO REALIZADOS]. / CONCLUSÃO / Perfil biofísico fetal ultrassonográfico: [PONTUAÇÃO]/8.

PONTOS DE CONTROLE PARA AUDITORIA / A reatividade cardíaca fetal não integra o PBF ultrassonográfico e exige cardiotocografia.




16. Ultrassonografia Transvaginal do Colo Uterino na Gestação

Origem e harmonização: Modelo complementado segundo o consenso CBR-FEBRASGO 2026.

NOME: [NOME] / IDADE: [IDADE]    DN: [DD/MM/AAAA]    DATA: [DD/MM/AAAA] / ULTRASSONOGRAFIA TRANSVAGINAL DO COLO UTERINO NA GESTAÇÃO / TÉCNICA / Exame realizado por via transvaginal, com avaliação dinâmica por 2 a 3 minutos e/ou compressão fúndica quando indicada. / ACHADOS / Colo uterino com comprimento funcional de [MEDIDA] mm, aferido ao longo da linha endocervical. / Orifício interno [FECHADO/COM FUNILAMENTO], com [DESCRIÇÃO E MEDIDAS, SE HOUVER]. / Membranas amnióticas sem protrusão pelo canal endocervical. / Sludge intra-amniótico [AUSENTE/PRESENTE]. / Ecotextura cervical preservada, sem alterações focais significativas. / CONCLUSÃO / Comprimento funcional do colo uterino: [MEDIDA] mm, sem sinais de funilamento ou protrusão de membranas.

PONTOS DE CONTROLE PARA AUDITORIA / Registrar técnica e presença/ausência de alterações dinâmicas.




17. Ultrassonografia da Tireoide

Origem e harmonização: Adaptado de “TIREOIDE NORMAL.doc”; atualizado conforme CBR 2026.

NOME: [NOME] / IDADE: [IDADE]    DN: [DD/MM/AAAA]    DATA: [DD/MM/AAAA] / ULTRASSONOGRAFIA DA TIREOIDE / TÉCNICA / Exame realizado com transdutor linear multifrequencial, abrangendo todos os segmentos da glândula tireoide. / ACHADOS / Tireoide em topografia habitual, com contornos regulares e ecogenicidade preservada. / Lobo direito medindo [LONGITUDINAL] x [AP] x [TRANSVERSO] cm, volume estimado em [VOLUME] cm³. / Lobo esquerdo medindo [LONGITUDINAL] x [AP] x [TRANSVERSO] cm, volume estimado em [VOLUME] cm³. / Istmo medindo [ESPESSURA] cm. / Volume tireoidiano total estimado em [VOLUME] cm³. / Parênquima com ecotextura homogênea, sem nódulos ou outras lesões focais detectáveis. / CONCLUSÃO / Tireoide sem alterações ultrassonográficas significativas.

PONTOS DE CONTROLE PARA AUDITORIA / Região cervical/linfonodos não está incluída neste exame, salvo solicitação específica. / Se houver nódulo, usar ACR TI-RADS e não manter este modelo normal. / Doppler somente quando solicitado/realizado.




18. Ultrassonografia das Mamas

Origem e harmonização: Adaptado de “MAMAS.doc”; atualizado conforme CBR 2026 e sistema BI-RADS.

NOME: [NOME] / IDADE: [IDADE]    DN: [DD/MM/AAAA]    DATA: [DD/MM/AAAA] / ULTRASSONOGRAFIA DAS MAMAS / TÉCNICA / Exame realizado com transdutor linear multifrequencial, incluindo varredura radial e antirradial das mamas e regiões retroareolares. / ACHADOS / Pele e tecido celular subcutâneo sem alterações significativas. / Parênquima mamário com padrão ecográfico [DESCRIÇÃO APROPRIADA À FAIXA ETÁRIA/COMPOSIÇÃO], sem distorção arquitetural. / Não se identificam nódulos sólidos, cistos complexos ou outras lesões focais suspeitas. / Regiões retroareolares sem ectasia ductal significativa. / Exame anterior [DISPONÍVEL/INDISPONÍVEL] para comparação. / CONCLUSÃO / Mamas sem achados ultrassonográficos suspeitos. Categoria BI-RADS® 1.

PONTOS DE CONTROLE PARA AUDITORIA / Axilas não estão incluídas no exame de mamas, a menos que solicitadas separadamente. / BI-RADS 1 só deve ser usado quando o exame for verdadeiramente negativo. / Não usar ultrassonografia como substituta automática da mamografia quando esta estiver indicada.




19. Ultrassonografia da Região Cervical

Origem e harmonização: Modelo complementado conforme a abrangência definida pelo CBR 2026.

NOME: [NOME] / IDADE: [IDADE]    DN: [DD/MM/AAAA]    DATA: [DD/MM/AAAA] / ULTRASSONOGRAFIA DA REGIÃO CERVICAL / TÉCNICA / Exame realizado com transdutor linear multifrequencial, abrangendo os compartimentos cervicais centrais e laterais. / ACHADOS / Planos cutâneos, subcutâneos e musculares cervicais sem alterações significativas. / Linfonodos cervicais com dimensões habituais e morfologia preservada, mantendo formato ovalado e hilo ecogênico, sem sinais de atipia ao método. / Lojas paratireoideanas sem lesões focais detectáveis. / Opcional, em tireoidectomia total: leito tireoidiano sem massas ou tecido nodular identificável. / CONCLUSÃO / Região cervical sem alterações ultrassonográficas significativas.

PONTOS DE CONTROLE PARA AUDITORIA / Este exame não inclui a tireoide, glândulas salivares ou vasos cervicais.




20. Ultrassonografia da Axila

Origem e harmonização: Modelo complementado conforme CBR 2026 e pareceres da Comissão Nacional de Mamografia.

NOME: [NOME] / IDADE: [IDADE]    DN: [DD/MM/AAAA]    DATA: [DD/MM/AAAA] / ULTRASSONOGRAFIA DA AXILA / TÉCNICA / Exame direcionado à axila [DIREITA/ESQUERDA/BILATERAL] com transdutor linear multifrequencial. / ACHADOS / Pele e tecido celular subcutâneo sem alterações significativas. / Linfonodos axilares identificados apresentam formato ovalado, hilo adiposo preservado e córtex fino e regular, sem sinais ultrassonográficos de atipia. / Ausência de massas ou coleções na região examinada. / CONCLUSÃO / Axila [DIREITA/ESQUERDA/BILATERAL] sem alterações ultrassonográficas significativas.

PONTOS DE CONTROLE PARA AUDITORIA / Registrar lateralidade e não confundir com o exame das mamas.




21. Ultrassonografia da Bolsa Escrotal com Doppler

Origem e harmonização: Modelo normal complementar para exame frequente.

NOME: [NOME] / IDADE: [IDADE]    DN: [DD/MM/AAAA]    DATA: [DD/MM/AAAA] / ULTRASSONOGRAFIA DA BOLSA ESCROTAL COM DOPPLER / TÉCNICA / Exame realizado com transdutor linear multifrequencial, associado ao mapeamento Doppler colorido e espectral. / ACHADOS / Testículo direito em topografia habitual, com contornos regulares e ecotextura homogênea, medindo [MEDIDAS] cm, volume estimado em [VOLUME] cm³. / Testículo esquerdo em topografia habitual, com contornos regulares e ecotextura homogênea, medindo [MEDIDAS] cm, volume estimado em [VOLUME] cm³. / Fluxo intratesticular presente e simétrico ao Doppler. / Epidídimos com dimensões e ecotextura preservadas. / Ausência de hidrocele significativa. / Veias do plexo pampiniforme sem ectasia ou refluxo durante Valsalva. / Paredes escrotais sem espessamento. / CONCLUSÃO / Bolsa escrotal sem alterações ultrassonográficas significativas.

PONTOS DE CONTROLE PARA AUDITORIA / Em dor aguda, documentar perfusão, cordão espermático e manobras conforme a suspeita clínica. / Varicocele exige medidas e avaliação dinâmica/refluxo, não apenas impressão visual.




22. Ultrassonografia das Glândulas Salivares

Origem e harmonização: Modelo complementado conforme a abrangência definida pelo CBR 2026.

NOME: [NOME] / IDADE: [IDADE]    DN: [DD/MM/AAAA]    DATA: [DD/MM/AAAA] / ULTRASSONOGRAFIA DAS GLÂNDULAS SALIVARES / TÉCNICA / Exame realizado com transdutor linear multifrequencial, abrangendo parótidas, submandibulares e sublinguais bilateralmente. / ACHADOS / Parótidas com dimensões, contornos, ecogenicidade e ecotextura preservados, sem lesões focais ou dilatação ductal. / Glândulas submandibulares com dimensões, contornos, ecogenicidade e ecotextura preservados, sem lesões focais ou dilatação ductal. / Regiões sublinguais sem alterações focais detectáveis. / Ausência de imagens calculosas identificáveis nos ductos avaliados. / CONCLUSÃO / Glândulas salivares sem alterações ultrassonográficas significativas.

PONTOS DE CONTROLE PARA AUDITORIA / Não inclui tireoide nem avaliação global dos linfonodos cervicais.




23. Ultrassonografia do Ombro

Origem e harmonização: Adaptado do arquivo musculoesquelético normal anexado ao e-mail; redação modernizada.

NOME: [NOME] / IDADE: [IDADE]    DN: [DD/MM/AAAA]    DATA: [DD/MM/AAAA] / ULTRASSONOGRAFIA DO OMBRO / TÉCNICA / Exame realizado com transdutor linear multifrequencial e manobras dinâmicas, no ombro [DIREITO/ESQUERDO]. / ACHADOS / Tendão da cabeça longa do bíceps com espessura e ecotextura preservadas, situado no sulco intertubercular, sem subluxação nas manobras dinâmicas. / Tendões subescapular, supraespinal, infraespinal e redondo menor com espessura, contornos e padrão fibrilar preservados, sem roturas ou calcificações. / Bursa subacromial-subdeltoidea sem distensão significativa. / Articulação acromioclavicular sem alterações relevantes ao método. / Ausência de derrame glenoumeral significativo. / Não se observa conflito subacromial nas manobras realizadas. / CONCLUSÃO / Ombro [DIREITO/ESQUERDO] sem alterações ultrassonográficas significativas.

PONTOS DE CONTROLE PARA AUDITORIA / Registrar lateralidade e limitações; ultrassom não avalia integralmente estruturas intra-articulares.




24. Ultrassonografia do Cotovelo

Origem e harmonização: Adaptado do arquivo musculoesquelético normal anexado ao e-mail; redação modernizada.

NOME: [NOME] / IDADE: [IDADE]    DN: [DD/MM/AAAA]    DATA: [DD/MM/AAAA] / ULTRASSONOGRAFIA DO COTOVELO / TÉCNICA / Exame realizado com transdutor linear multifrequencial no cotovelo [DIREITO/ESQUERDO]. / ACHADOS / Tendões extensores comuns na origem epicondilar lateral e flexores comuns na origem epicondilar medial com padrão fibrilar preservado. / Tendões distal do bíceps e do tríceps sem alterações significativas. / Nervo ulnar com calibre e ecotextura preservados no túnel cubital, sem subluxação nas manobras dinâmicas. / Ausência de derrame articular significativo, coleções ou massas nas regiões avaliadas. / Superfícies ósseas acessíveis sem irregularidades relevantes. / CONCLUSÃO / Cotovelo [DIREITO/ESQUERDO] sem alterações ultrassonográficas significativas.

PONTOS DE CONTROLE PARA AUDITORIA / Doppler só deve ser descrito quando realizado.




25. Ultrassonografia do Punho

Origem e harmonização: Adaptado do arquivo musculoesquelético normal anexado ao e-mail; redação modernizada.

NOME: [NOME] / IDADE: [IDADE]    DN: [DD/MM/AAAA]    DATA: [DD/MM/AAAA] / ULTRASSONOGRAFIA DO PUNHO / TÉCNICA / Exame realizado com transdutor linear multifrequencial no punho [DIREITO/ESQUERDO], incluindo avaliação dinâmica. / ACHADOS / Tendões dos seis compartimentos extensores com espessura e padrão fibrilar preservados, sem líquido significativo nas bainhas. / Tendões flexores com padrão fibrilar preservado. / Nervo mediano com ecotextura fascicular preservada, área de secção transversal de [MEDIDA] mm² na entrada do túnel do carpo, quando aferida. / Retináculo dos flexores sem abaulamento significativo. / Ausência de cistos sinoviais, massas ou coleções nas regiões examinadas. / CONCLUSÃO / Punho [DIREITO/ESQUERDO] sem alterações ultrassonográficas significativas.

PONTOS DE CONTROLE PARA AUDITORIA / Não concluir ausência de síndrome do túnel do carpo sem medidas e correlação clínica/neurofisiológica adequadas.




26. Ultrassonografia do Joelho

Origem e harmonização: Adaptado do arquivo musculoesquelético normal anexado ao e-mail; redação modernizada.

NOME: [NOME] / IDADE: [IDADE]    DN: [DD/MM/AAAA]    DATA: [DD/MM/AAAA] / ULTRASSONOGRAFIA DO JOELHO / TÉCNICA / Exame realizado com transdutor linear multifrequencial no joelho [DIREITO/ESQUERDO]. / ACHADOS / Tendões quadríceps e patelar com espessura e padrão fibrilar preservados, sem roturas ou calcificações. / Tendões da pata anserina com aspecto preservado, sem distensão bursátil significativa. / Ligamentos colaterais nas porções acessíveis sem descontinuidade. / Meniscos nas porções periféricas acessíveis com morfologia preservada. / Ausência de derrame articular significativo. / Fossa poplítea sem cistos ou coleções. / Cartilagem troclear acessível com espessura e contornos preservados. / CONCLUSÃO / Joelho [DIREITO/ESQUERDO] sem alterações ultrassonográficas significativas.

PONTOS DE CONTROLE PARA AUDITORIA / O ultrassom não substitui a ressonância para avaliação completa de meniscos, ligamentos cruzados e cartilagem profunda.




27. Ultrassonografia do Tornozelo

Origem e harmonização: Adaptado do arquivo musculoesquelético normal anexado ao e-mail; redação modernizada.

NOME: [NOME] / IDADE: [IDADE]    DN: [DD/MM/AAAA]    DATA: [DD/MM/AAAA] / ULTRASSONOGRAFIA DO TORNOZELO / TÉCNICA / Exame realizado com transdutor linear multifrequencial no tornozelo [DIREITO/ESQUERDO]. / ACHADOS / Tendão de Aquiles com espessura, contornos e padrão fibrilar preservados, sem rotura ou calcificação. / Tendões tibial posterior, flexor longo dos dedos e flexor longo do hálux com aspecto preservado no retromaleolar medial. / Tendões fibulares com aspecto preservado no retromaleolar lateral, sem subluxação nas manobras dinâmicas. / Tendões anteriores com padrão fibrilar preservado. / Ligamentos acessíveis sem descontinuidade evidente. / Ausência de derrame articular, coleções ou massas nas regiões avaliadas. / CONCLUSÃO / Tornozelo [DIREITO/ESQUERDO] sem alterações ultrassonográficas significativas.

PONTOS DE CONTROLE PARA AUDITORIA / Registrar a estrutura ou compartimento alvo quando o pedido for direcionado.




28. Ultrassonografia do Pé e Fáscia Plantar

Origem e harmonização: Modelo complementar para exame musculoesquelético frequente.

NOME: [NOME] / IDADE: [IDADE]    DN: [DD/MM/AAAA]    DATA: [DD/MM/AAAA] / ULTRASSONOGRAFIA DO PÉ E FÁSCIA PLANTAR / TÉCNICA / Exame realizado com transdutor linear multifrequencial no pé [DIREITO/ESQUERDO], com ênfase na região [LOCAL]. / ACHADOS / Fáscia plantar com espessura de [MEDIDA] mm na inserção calcânea, padrão fibrilar preservado e sem roturas. / Tendões avaliados com espessura e padrão fibrilar preservados. / Ausência de bursites, coleções ou massas nas regiões examinadas. / Superfícies ósseas acessíveis sem irregularidades relevantes. / CONCLUSÃO / Pé/fáscia plantar [DIREITO/ESQUERDO] sem alterações ultrassonográficas significativas.

PONTOS DE CONTROLE PARA AUDITORIA / Não interpretar a espessura fascial sem considerar técnica, local de medida e quadro clínico.




29. Ultrassonografia de Músculo ou Tendão Localizado

Origem e harmonização: Modelo genérico complementar para lesões musculotendíneas.

NOME: [NOME] / IDADE: [IDADE]    DN: [DD/MM/AAAA]    DATA: [DD/MM/AAAA] / ULTRASSONOGRAFIA DE MÚSCULO OU TENDÃO LOCALIZADO / TÉCNICA / Exame direcionado a [MÚSCULO/TENDÃO E LATERALIDADE] com transdutor linear multifrequencial, incluindo avaliação dinâmica e comparação contralateral quando pertinente. / ACHADOS / [MÚSCULO/TENDÃO] com espessura, contornos, ecogenicidade e arquitetura fibrilar preservados. / Transição miotendínea sem descontinuidade. / Ausência de rotura, hematoma, coleção ou calcificação detectável. / Opcional, quando Doppler foi realizado: ausência de hiperemia focal. / CONCLUSÃO / [MÚSCULO/TENDÃO] sem alterações ultrassonográficas significativas.

PONTOS DE CONTROLE PARA AUDITORIA / Delimitar com precisão a estrutura, o lado e a área examinada.




Apêndice A. Matriz de origem dos modelos

Grupo | Anexo do e-mail | Complementação
Abdome total/superior | ABDOME TOTAL NORMAL.doc; ABDOME TOTAL COMPLETO.doc | CBR 2026
Rins e vias urinárias | RINS E VIAS URINARIAS NORMAL.doc | CBR 2026
Próstata | PRÓSTATA.doc | CBR 2026
Pelve/transvaginal | PELVE E ENDO NORMAL .doc; PELVE E ENDO. completo.doc | CBR 2026; consenso CBR-FEBRASGO
Gestação | GESTAÇÃO INICIAL.doc; GESTAÇÃO.doc; GESTAÇÃO COMPLETO.doc; GESTAÇÃO GEMELAR.doc | Consenso CBR-FEBRASGO 2026
Tireoide | TIREOIDE NORMAL.doc | CBR 2026
Mamas | MAMAS.doc | CBR 2026; BI-RADS
Parede abdominal | PAREDE ABDOMINAL.doc | CBR 2026
Musculoesquelético | MUSCULO ESQUELETICOSLaudos normais .pdf | Revisão linguística e técnica do modelo-fonte
Modelos complementares | Não disponíveis como modelo normal específico no e-mail | CBR 2026 e princípios do Prompt Mestre

Apêndice B. Referências normativas

1. Colégio Brasileiro de Radiologia e Diagnóstico por Imagem (CBR). Normatização de Exames de Ultrassonografia do CBR, Revisão 2026, versão consolidada. Comissão Nacional de Ultrassonografia, 17 de junho de 2026. Fonte oficial

2. Parte II da Normatização CBR 2026: Exames em Ginecologia e Obstetrícia, consenso CBR-FEBRASGO. Fonte oficial

3. CBR. Parecer sobre Ultrassonografia de Mamas e Axilas. Fonte oficial

Observação final: este documento organiza modelos de texto e escopo. Não substitui a execução técnica do exame, a análise das imagens, as diretrizes completas, o julgamento médico ou a validação final de cada laudo.
