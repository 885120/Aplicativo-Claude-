# Contratos do app de laudos

Aplicar Manual Mestre v2.0 e os 29 modelos completos incluídos. Os modelos normais são estruturas de redação, não prova de normalidade. A calculadora produz texto sucinto; não é o contrato de completude do app principal.

## Dados e origem

Manter identificação segura do exame/paciente, origem do dado, versão do modelo, autorizações e log de alteração. Separar lotes; não completar lacunas usando outro paciente. Documentar dado recebido, leitura segura/provável/ilegível/conflitante, cálculo e interpretação.

Retenção de normalidade já presente: possível apenas se o trecho corresponder ao modelo, não houver contradição na fonte nem limitação. Inserção de nova afirmação de normalidade ausente da fonte/original/confirmação médica: proibida. Modelo não preenche medidas, percentis, Doppler ou diagnóstico.

## Obstetrícia

- IG estabelecida, origem e DPP rastreáveis; biometria atual não redata silenciosamente.
- DBP, CC, CA, CF com unidade; PFE em g, fórmula, curva, percentil e IG de referência identificados.
- PFE sem percentil é pendência, não crescimento adequado por silêncio.
- Placenta e líquido somente quando avaliados, com método/medida; limitações explícitas.
- Doppler: vaso, índice, valor, unidade quando aplicável, referência e domínio. Uterina direita/esquerda, via, média e componentes. Não calcular média de um só lado.
- ICP/CPR = IP ACM / IP AU; exigir os componentes válidos do mesmo exame. Não inferir incisura, diástole ou onda A só pelo IP.
- Fluxo ausente/reverso e DV crítico nunca omitidos ou suavizados. Coexistência de anemia não mascara gravidade hemodinâmica.
- Gemelar: corionicidade/amnionicidade documentadas quando determináveis; dados, PFE/percentil/curva, líquido e Doppler por feto, identificadores estáveis A/B.
- TN: CCN, técnica/via, curva e domínio; PBF ultrassonográfico /8 sem inventar cardiotocografia; colo com técnica e dinâmica quando avaliados.
- Conclusão deve corresponder a achados rastreáveis e nomear incompletude onde necessária.

O alerta genérico do Manual contra diagnóstico por percentil isolado não revoga o critério específico solitário PFE<p3 do consenso adotado. Usar a decisão específica adjudicada no seu domínio.

## Fluxo de auditoria e liberação

Preservar original → inventariar → parear com segurança → selecionar modelo exato → extrair fonte → auditar sem editar em três camadas → apresentar divergências → obter autorização médica → corrigir cópia → segunda auditoria → conferência médica final.

Classes A aprovado, B ajuste formal, C divergência estrutural, D fonte×DOCX, E confirmação médica, F inconsistência crítica, G não analisável. Não automatizar assinatura/entrega como consequência de cálculo passando.

Dados reais não entram em exemplos, logs públicos ou testes. Não enviar dados de pacientes a um provedor de IA/serviço externo sem política e autorização específicas. A implementação de autenticação, retenção, criptografia e exportação deve ser definida conforme a plataforma, sem alegar conformidade legal certificada neste pacote.
