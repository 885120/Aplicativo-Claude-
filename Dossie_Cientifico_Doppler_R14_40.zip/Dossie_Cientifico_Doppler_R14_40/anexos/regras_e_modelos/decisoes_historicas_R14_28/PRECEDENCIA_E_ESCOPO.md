# Precedência e escopo

Há três hierarquias diferentes, que não devem ser misturadas.

1. Dados do paciente: confirmação médica documentada resolve ambiguidades; documento-fonte fornece os dados individualizados. O modelo nunca cria medidas, lateralidade ou normalidade.
2. Ciência e política: adjudicação explícita atual do responsável e fontes identificadas. Hierarquia científica adotada FEBRASGO → CBR → ISUOG, complementares quando necessários, com atribuição. Manual v2.0 prevalece sobre a hierarquia simplificada impressa nos modelos.
3. Implementação: R14.28 é o baseline mais recente recebido, superior a snapshots R14–R14.27 para comportamento técnico. Código demonstra o que foi implementado, não valida por si só uma regra médica. Divergência entre código e decisão deve ser registrada, não resolvida silenciosamente.

## Substituições obrigatórias

| Tema | Material antigo | Decisão vigente |
|---|---|---|
| Oligo por MBV | ≤2,0 | <2,0 cm; igualdade não fecha |
| Poli por MBV | >8,0 | ≥8,0 cm; igualdade fecha |
| Poli por ILA | >25 | ≥24 cm |
| Gravidade do poli | Atribuição histórica | SMFM #46, tabela 2, autorização explícita |
| Hierarquia | Versões anteriores diversas | FEBRASGO → CBR → ISUOG |
| Peso | Φ aproximado | Φ preciso somente no caminho de percentil do peso |
| Testes exatos | Valores com ruído gerado | Entrada decimal real; oráculo independente |
| Oráculo v3 | X1–X11 omitidos | v3.1 inclui esses casos; quatro inalcançáveis documentados |
| Discordância exibida | Inteiro ou 2 casas sem verificação final | Escalar 0/2/3/4 casas; fallback preservando categoria |

O handoff R14 antigo e seu golden case de líquido estão supersedidos nesses itens. Não devem dirigir o desenvolvimento atual.

## Calculadora e app principal

O fechamento auditado refere-se ao motor da Calculadora Doppler. O app principal usa esse motor como referência semântica nos módulos correspondentes. Não copiar sua UI, IDs, estados globais, schema de persistência ou simplificações do texto sucinto automaticamente. O app principal deve cumprir os contratos de laudo completo do Manual e dos Modelos.

No pacote não há código-fonte do app principal. A escolha de plataforma e o conjunto de funcionalidades devem seguir o repositório existente ou uma decisão explícita do usuário; não foram redefinidos neste handoff.
