# Limites e pendências sem reabertura automática

## Encerrado no escopo auditado

F01 gate de peso do outro feto; F02 Φ preciso no peso; F03 estado de IG desconhecida com diástole ausente/reversa; F04 identidade do outro feto; F05 categoria e exibição da discordância. R14.28 encerra esses achados técnicos. As contagens de falha anteriores repetem causas; não representam milhares de defeitos diferentes.

## Operacional

iPhone/Safari físicos, atualização, recuperação, uso offline real no aparelho e validação clínica permanecem pendentes. WebKit Linux não é Safari/iPhone. Guardar como critérios de liberação, não como motivo para mudar curvas.

## Materiais ausentes

O repositório atual do app principal e o Prompt Mestre integral não foram anexados. Os DOCX e referências mencionam esse prompt; não é possível reconstruí-lo fielmente só dessas menções. PDFs de editoras não estão no corpus consolidado: referências preservam níveis de evidência e limites. O pacote não afirma redistribuir artigos não recebidos.

O PDF da suíte consolidada contém código cortado na margem direita, inclusive imports/strings e chamadas. Foi preservado e seu texto extraído, mas não foi promovido a um .py executável nem completado por adivinhação. O pacote de testes R14.28 contém scripts executáveis para vários grupos, com instruções de adaptação.

## Reconciliações locais registradas no CONTEXTO

A suíte legada 17/09 tem expectativas obsoletas e casos não adjudicados. UTD a1-inc ausente e classificação de entrada incompleta devem ser revisadas com a regra vigente e dados faltantes; não restaurar estado antigo só para passar teste. Outros itens listados como herdados/não verificados no CONTEXTO não são automaticamente defeitos novos nem decisões em aberto. Conferir ocorrência no código atual antes de agir.

Ciobanu versus tabelas/calculadora FMF/DeVore consta como dúvida documental residual; a referência adotada permanece Ciobanu 2019. PFE, uterinas e PSV não terem sido reauditados em uma rodada não revoga suas decisões. DEC-LONG-001 já identifica 21 dias como APP_POLICY; não abrir investigação para atribuí-la falsamente ao Delphi.

A ordem de referências não autoriza substituição automática de curva. Conflito específico deve registrar fonte, parâmetro, domínio e autorização. Hierarquia de modelos de laudo é diferente de hierarquia de evidência científica.

Rótulo de percentil próximo ao corte (ex. p10 com PIG) foi observação opcional, não correção autorizada na R14.28. No novo app registrar a decisão de apresentação antes de ampliar escopo, sem mudar a categoria.

Os oráculos são independentes de partes do motor, mas autoria comum limita independência científica. Varreduras finitas/heurísticas não demonstram ausência global de defeitos.
