# Política numérica do baseline

Separar valor original, normalização de unidades, cálculo bruto, classificação e formatação. Não arredondar medidas/percentis para decidir clínica.

cmpMedida(a,b) usa tolerância absoluta `16 × Number.EPSILON × max(1, |a|, |b|)`. Trata ruído IEEE-754 de conversão/interpolação; não é tolerância clínica, nem literalmente 16 ULPs em todas as escalas. Reimplementar conforme o tipo numérico da plataforma, com testes independentes de igualdade e vizinhança. Não usar para aceitar NaN/infinito: validade é pré-requisito.

valmm() permanece v×10 no baseline. A correção foi nos comparadores afetados, não arredondamento global. Em outra linguagem, definir unidades explicitamente sem alterar a resolução de entrada ou os cortes. Os 26 pontos registrados nas referências incluem CA, ossos, DIO, TN, razões, uterinas, PFN/ON, CT/CA, saco–CCN e categoria de discordância.

Percentil de peso usa phiPreciso via pctPesoFromZ. Phi genérico de outros módulos não foi trocado. Neutralização nominal preexistente `|z−Z|<1e-10` foi preservada: há 44 testemunhos residuais, até aproximadamente 47,4 ng do corte. Não afirmar comparação estritamente matemática universal, nem ampliar essa janela. Uma portabilidade que difira disso precisa declarar diferença intencional e obter adjudicação antes de fechar.

discCat usa comparação estável com 20/25. discFmt tenta 0, 2, 3 e 4 casas e aceita somente representação com mesma categoria do bruto; fallback <20%/<25%. Casas adicionais preservam coerência, não aumentam precisão clínica. O bruto 24,999999999999996 pode continuar abaixo de 25 em representação binária enquanto a categoria estável inclui a igualdade: não tratar teste que exige bruto ≥25 como contrato aprovado.

Na interface, step=1 de peso direto é resolução nominal, não validação suficiente: digitação/importação/programação podem produzir decimais. Defina validação explicitamente no novo app, sem converter silenciosamente valores inválidos em válidos ou redefinir o domínio dos testes.

Teste decimais digitados como texto real (“17,33”), abaixo/igual/acima, interpolação por dias, ambos fetos e todo consumidor ativo. Testar campo sem pré-requisitos não valida seu classificador.
