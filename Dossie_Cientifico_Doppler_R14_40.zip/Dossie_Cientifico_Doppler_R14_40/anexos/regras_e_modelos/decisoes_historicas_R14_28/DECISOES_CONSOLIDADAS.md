# Decisões clínicas e políticas consolidadas

Este índice transporta decisões já registradas. A descrição completa, domínios, evidência e limites estão em 02_FONTES/REFERENCIAS_R14_28.md e no baseline. Ele não substitui as equações/tabelas integrais nem cria novas indicações clínicas.

## Referências do motor

| Módulo | Referência adotada | Contrato de transferência |
|---|---|---|
| PFE | Hadlock 1985; modelo associado à curva selecionada | Preservar fórmula de quatro/três parâmetros conforme o caminho atual, unidades e seleção; não misturar método e curva |
| Percentil de peso | Hadlock 1991 / INTERGROWTH-21st | Hadlock SD em ln = 0,12; Φ preciso só no peso; curva ativa explícita |
| CA | INTERGROWTH-21st, Papageorghiou 2014 | Preservar tabelas, domínios e cortes brutos p3/p10/p90/p97; igualdade não satisfaz operador estrito |
| AU, ACM-IP e CPR | Ciobanu 2019 / FMF | 20+0–41+6; corte CPR por ciobanuCPRref, não por T_CPR |
| PSV-ACM | Mari 2000 | Velocidade em cm/s, MoM com referência e IG; sem inferir anemia de IP |
| Uterinas | Gómez / Cavoretto | Identificar via, lados e curva; média somente com os dois componentes válidos |
| DV 1º trimestre | Pruksanusak 2014 | PIV p5/p50/p95 = 0,69/0,92/1,13, CCN 45,9–75,5 mm; onda A independente do PIV |
| DV 2º/3º trimestre | Tongprasert 2012 | Preservar domínio e equação atuais |
| TN | Faria como padrão brasileiro / FMF 1998 alternativa | Curva ativa e CCN; sem interpretar fora do domínio |
| Órbitas | Sukonpan & Phupong 2008 | 15–40 semanas completas; p10/50/90; outlier é alerta, não diagnóstico |
| Ossos longos | Chitty & Altman 2002 | Curvas individuais; corte p3 estável; razão U/F não diagnostica encurtamento |
| Cerebelo/átrio | Snijders & Nicolaides 1994 | Preservar curvas/domínios e natureza do achado |
| UTD | Nguyen atualização 2021, publicada 2022 | Figura antenatal; não transportar cortes ureterais pós-natais |
| Placenta | Bonilla 1972 via reprodução Fetalmed | Descritiva, não reconstruir percentis |

## Tamanho, RCF e dupla fetal

- Terminologia do motor: RCF; não reintroduzir CIUR como rótulo automático. PIG/GIG são descrições de tamanho e não equivalem por si sós a toda a avaliação de RCF.
- PFE e CA são entradas independentes. Não afirmar avaliação global adequada com CA ausente. CA isolada pode sustentar apenas os critérios específicos já adotados.
- Critérios de RCF: preservar Gordijn/Delphi 2016 e ISUOG 2020; distinção precoce/tardia em 32 semanas; apresentação FEBRASGO paralela onde documentada. Não simplificar para “qualquer p<10 = RCF”.
- DEC-LONG-001: queda estritamente >50 pontos percentuais e intervalo ≥21 dias. Os 21 dias são APP_POLICY de comparabilidade do serviço, não uma frase literal do Delphi. Preservar referência/comparabilidade dos exames.
- sFGR: consenso Khalil 2019; PFE <p3 é critério solitário independentemente da corionicidade. Critério combinado MC 2/4 e DC 2/3 exige componentes válidos conforme o motor/oráculo, não só contagem de campos preenchidos.
- Corionicidade ausente não pode ser presumida. Dois fetos <p10 exigem nomenclatura SGA/PIG de ambos; sobreposição com critério Delphi é estado explícito de revisão, não decisão silenciosa.
- “Menor feto” tem estados atual/outro/empate/indeterminado; a AU do menor exige identificação formal e comparabilidade. Preservar a política bio×bio atual, sem estender a comparabilidade automaticamente a bio×direto.
- Cada feto conserva seu PFE, percentil, curva, método, CA, AU e exames. A↔B não pode mudar o resultado global nem transferir um achado para outro feto.
- Peso direto válido: finito e 50–7000 g inclusive, também no ramo do outro feto. Fora da faixa não entra em discordância/sFGR; registrar recusado.
- IG ausente com AEDF/REDF: estado aedf-ig-desconhecida, gravidade preservada e pedido de IG válida; não assumir RCF tardia.
- Discordância = (maior−menor)/maior ×100. Preservar bruto; categoria estável em 20 e 25; igualdade incluída. Número exibido deve permanecer na mesma categoria em cartão, corpo, guia e conclusão.

Não transcrevemos toda a tabela-verdade para prosa: o JSON v3.1 completo está em 04_TESTES/portaveis, com expectativas por caso, e as regras completas no baseline. Casos semânticos injetam estado e NÃO comprovam o cálculo numérico real.

## Líquido

Diagnóstico FEBRASGO nº43/2025, tabela 1: MBV <2 ou ILA <5 para oligo; MBV ≥8 ou ILA ≥24 para poli. Ausência da medida não é volume normal.

Poli por SMFM #46, tabela 2: MBV ≥8 e <12 leve; ≥12 e <16 moderado; ≥16 grave. ILA ≥24 e <30 leve; ≥30 e <35 moderado; ≥35 grave. Não inserir grau automático de oligo sem nova autorização. SMFM #46 tem páginas B2–B8, não B2–B18.

## Rebaixamentos que não podem voltar como diagnóstico

| Regra | Decisão |
|---|---|
| CC/CA Campbell | Descritivo por bloco real de duas semanas, 17–41; sem interpolação fracionária/normalidade/critério RCF |
| CF/CC | Somente numérico; faixa fixa 13,30–23,90 removida |
| CF/DBP | 71–87% como faixa publicada, nunca “normal”/IC90; gate ≥23+0 APP_POLICY |
| CF/CA | 20–24% faixa normal publicada; gate ≥22+0 APP_POLICY; não afirmar causalidade placentária isolada |
| U/F 0,90–1,10 | Classificador removido; sem rizomelia inferida |
| igBio ponderada | Heurística descritiva; sem cor/gravid./redatação/decisão clínica |
| Sequência Doppler obrigatória | Removida; territórios paralelos; sem “pulou etapa” |
| Ureter >4/>7 mm | Cortes antenatais removidos; medida descritiva, UTD qualitativo com pré-requisitos |

## FCF e políticas mantidas

FCF precoce: preservar camadas Doubilet/Silva & Bailão/Pettersen & Faria e suas faixas; 6+2 indeterminado e alocação dupla de meia semana são APP_POLICY. 14+0–19+6 descritiva; ≥20+0 faixa 110–160 é alerta de origem basal CTG, não curva US reconstruída.

Modo Paciente é comunicação, não laudo/síntese. Não exportar percentil, Doppler ou líquido nessa tela se ela for implementada. Comprimento estimado não entra no laudo clínico pelo mero fato de ser calculável.

Não avaliado ≠ normal. Sem referência ≠ alterado. Achado grave nunca desaparece por ordem de avaliação, anemia coexistente, dado faltante ou troca de aba.
