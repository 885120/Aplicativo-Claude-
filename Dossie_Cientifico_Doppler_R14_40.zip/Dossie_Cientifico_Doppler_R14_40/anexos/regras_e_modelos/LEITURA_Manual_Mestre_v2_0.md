# Extração legível de Manual_Mestre_v2_0

Extração do corpo e tabelas em ordem documental. Consulte o DOCX original para layout, cabeçalhos, imagens e formatação.

MANUAL MESTRE

DE AUDITORIA, CORREÇÃO CONTROLADA
E INTEGRAÇÃO COM MODELOS APROVADOS

Digitador de Laudos 2.0 / Ultralaudo AI

FINALIDADE / Padronizar a auditoria de laudos digitados a partir de documentos-fonte, integrar obrigatoriamente a biblioteca MODELOS_APROVADOS_DE_LAUDOS.docx e controlar toda correção até a liberação médica final. / Este manual organiza o processo. Não substitui a análise das imagens, o julgamento clínico nem a responsabilidade do médico.

Versão 2.0  |  22 de julho de 2026

Substitui integralmente o Manual Mestre de Auditoria de Laudos v1.0

Responsável médico: Dr. Diogo S. Ribeiro - CRM 5789/AL

Documento de uso interno, sujeito à validação médica e controle de versão




Controle documental

Elemento | Versão ativa | Função
Prompt Mestre do projeto | Versão vigente no projeto | Princípios globais, regras clínicas, padrões de redação e limites de inferência.
Manual Mestre de Auditoria | v2.0 - 22/07/2026 | Fluxo de auditoria, classificação, correção controlada, rastreabilidade e liberação.
Biblioteca de modelos aprovados | v1.0 - 22/07/2026 | Arquivo MODELOS_APROVADOS_DE_LAUDOS.docx: estrutura, escopo, terminologia, campos e pontos de controle.
Diretrizes normativas | Versões vigentes e identificadas | Parâmetros técnicos e científicos. FEBRASGO é a referência primária definida pelo projeto; fontes complementares devem ser explicitadas.

REGRA DE COMPATIBILIDADE / Este manual foi construído para uso conjunto com MODELOS_APROVADOS_DE_LAUDOS.docx, versão 1.0. Se houver divergência entre a hierarquia simplificada impressa naquele arquivo e este Manual v2.0, prevalece este manual. A versão do modelo utilizada deve ser registrada no relatório de cada lote.

Histórico de versões

Versão | Data | Alterações principais | Status
1.0 | 22/07/2026 | Criação do fluxo PDF × DOCX, protocolo de caligrafia e alertas obstétricos. | Substituída
2.0 | 22/07/2026 | Integração formal com MODELOS_APROVADOS_DE_LAUDOS.docx; auditoria em três camadas; regra de uso seguro de texto normal; nova classificação estrutural; catálogo de 29 modelos; comandos revisados. | Versão atual

Resumo operacional

FLUXO EM UMA LINHA / Receber o lote → preservar originais → inventariar → parear fonte e DOCX → selecionar o modelo aprovado correto → auditar sem editar em três camadas → classificar divergências → obter confirmação médica → corrigir cópias → auditar novamente → liberar para conferência médica e impressão.

Cada auditoria corresponde a um único e-mail e a um único lote. O documento-fonte registra os dados individualizados do exame; o DOCX é o laudo digitado; e o arquivo MODELOS_APROVADOS_DE_LAUDOS.docx define o padrão estrutural e textual aplicável. Nenhum arquivo será alterado antes da apresentação da auditoria e da autorização médica.

Sumário

1. Objetivo e escopo

2. Definições operacionais

3. Princípios globais e inegociáveis

4. Hierarquia das fontes

5. Papel do documento-fonte, do DOCX e do modelo aprovado

6. Organização dos lotes e arquivos

7. Fluxo de trabalho obrigatório

8. Protocolo de leitura da caligrafia

9. Auditoria em três camadas

10. Classificação das inconsistências

11. Checklist geral de auditoria

12. Alertas prioritários em obstetrícia

13. Auditoria de cálculos

14. Aplicação dos modelos aprovados

15. Catálogo dos modelos e controles essenciais

16. Relatório de auditoria

17. Confirmação médica

18. Correção controlada dos DOCX

19. Segunda auditoria e liberação

20. Aprendizado e controle de versões

21. Privacidade e retenção

22. Comandos operacionais recomendados

23. Checklist antes da impressão

24. Referências e aprovação




1. Objetivo e escopo

Este manual estabelece o método oficial do projeto para auditoria documental, estrutural, clínica e de fidelidade dos laudos ultrassonográficos digitados. Seu uso é obrigatório sempre que houver solicitação de auditoria, revisão, conferência ou correção de arquivos de laudos.

Verificar se cada arquivo corresponde ao paciente, ao exame e ao lote corretos.

Confirmar a transcrição fiel de medidas, achados, lateralidade, unidades e informações obstétricas.

Verificar a conformidade do DOCX com o modelo aprovado correspondente, sem transformar o modelo em fonte de dados do paciente.

Conferir coerência entre descrição, cálculos, interpretação, classificação e conclusão.

Identificar omissões, inclusões indevidas, campos residuais, erros numéricos, desvios estruturais e falhas de formatação.

Corrigir somente após autorização expressa, preservando os arquivos originais.

Manter registro reproduzível de todas as decisões e alterações.

LIMITAÇÃO ESSENCIAL / A auditoria de documentos não substitui a revisão das imagens quando a solução de uma divergência depende do aspecto ultrassonográfico. Nesses casos, o status obrigatório é NECESSITA DE CONFIRMAÇÃO MÉDICA ou REVISÃO DAS IMAGENS.

2. Definições operacionais

Termo | Definição operacional
Documento-fonte | Registro primário produzido durante o exame: PDF, formulário, anotação manuscrita, texto ditado, planilha, imagem documentada ou confirmação expressa do médico.
Fonte exaustiva | Documento que pretende registrar todos os achados e dados necessários ao laudo. A ausência de item equivale apenas a ausência de informação, nunca a normalidade.
Fonte não exaustiva | Documento que registra sobretudo dados individualizados, medidas e achados relevantes, enquanto o DOCX pode conter texto normal padronizado previamente validado. Seu uso exige as regras restritivas deste manual.
Laudo digitado | Arquivo DOC ou DOCX elaborado a partir do documento-fonte e recebido para conferência.
Modelo aprovado | Modelo versionado do arquivo MODELOS_APROVADOS_DE_LAUDOS.docx que define estrutura, escopo, terminologia, campos e pontos de controle para um tipo de exame.
Auditoria de fidelidade | Comparação entre documento-fonte e DOCX para verificar se os dados do paciente foram transcritos corretamente.
Auditoria de conformidade estrutural | Comparação do DOCX com o modelo aprovado aplicável, verificando escopo, ordem, campos, trechos residuais e terminologia.
Auditoria interna | Verificação da coerência do próprio laudo: identificação, anatomia, lateralidade, cálculos, descrição, classificação, conclusão e formatação.
Correção controlada | Edição de uma cópia do laudo, limitada aos pontos autorizados e seguida por nova auditoria.
Dado derivado | Valor calculado a partir de medidas legíveis, fórmula definida e referência identificada.
Confirmação médica | Decisão expressa do médico diante de informação ilegível, ambígua, ausente, discrepante, estruturalmente incerta ou tecnicamente suspeita.
Liberação médica final | Aprovação do médico responsável antes de assinatura, impressão ou entrega.

3. Princípios globais e inegociáveis

PRINCÍPIO GLOBAL DE RASTREABILIDADE, NÃO EXTRAPOLAÇÃO E CONTROLE DE INFERÊNCIA / Nenhum dado ausente poderá ser preenchido por plausibilidade, padrão clínico, associação habitual, texto de modelo ou completamento automático. / A ausência de informação nunca será convertida em normalidade. / Toda descrição, interpretação, classificação, diagnóstico, recomendação ou conclusão deve ser rastreável a dado fornecido, medida objetiva, cálculo verificável, achado documentado, modelo previamente validado para estrutura ou fonte normativa identificada. / Informações clínicas são contexto e não autorização para presumir achados, gravidade, complicações ou repercussões.

Separar sempre dado recebido, leitura do dado, cálculo, interpretação e hipótese diagnóstica.

Não alterar valor objetivo apenas para tornar o laudo aparentemente coerente.

Não corrigir lateralidade, medida, diagnóstico ou classificação por probabilidade.

Não usar outro paciente, outro lote ou outro modelo para preencher lacunas.

Não considerar o texto do DOCX como prova de que uma anotação manuscrita foi lida corretamente.

Sinalizar valores atípicos ou tecnicamente suspeitos e solicitar repetição ou confirmação quando necessário.

Não apresentar associação típica de doença como achado real sem suporte explícito.

Preservar a responsabilidade final do médico em todas as etapas.

4. Hierarquia das fontes

Prioridade | Fonte | Regra
1 | Confirmação expressa do médico responsável | Resolve ambiguidades específicas do lote quando registrada de forma clara.
2 | Documento-fonte do exame | Fonte primária para identificação, medidas, achados, lateralidade e dados individualizados daquele paciente.
3 | Princípios globais e Prompt Mestre do projeto | Definem rastreabilidade, segurança, não extrapolação e regras clínicas permanentes.
4 | Manual Mestre de Auditoria v2.0 | Define o fluxo, as camadas de auditoria, as classificações e o controle das correções.
5 | Diretriz normativa ou científica identificada | FEBRASGO é a referência primária definida pelo projeto. Quando não houver parâmetro específico, utilizar CBR, ISUOG, FMF ou outra fonte complementar, deixando isso explícito.
6 | MODELOS_APROVADOS_DE_LAUDOS.docx | Orienta estrutura, escopo, terminologia, campos e redação padronizada. Não cria dados individualizados.
7 | Conhecimento geral do modelo de IA | Apenas apoio. Nunca prevalece sobre as fontes anteriores nem preenche lacunas.

CONFLITO ENTRE FONTES / Quando houver conflito, não escolher silenciosamente. Registrar a divergência, indicar as fontes envolvidas e solicitar decisão médica. Uma diretriz pode orientar a interpretação de um dado, mas não pode inventar o dado ausente.

5. Papel do documento-fonte, do DOCX e do modelo aprovado

5.1 Documento-fonte

É soberano para dados individualizados: medidas, lateralidade, achados positivos, limitações, idade gestacional, DPP, peso fetal, percentil, Doppler e recomendações específicas.

Pode ser exaustivo ou não exaustivo. Essa condição não deve ser presumida apenas pela aparência do documento.

Informações ilegíveis ou contraditórias não devem ser resolvidas por comparação com o DOCX.

5.2 DOCX recebido

É o objeto auditado e não a fonte primária dos achados.

Pode conter texto normal padronizado legítimo, erros de digitação, campos residuais, omissões ou informações de outro paciente.

Todo trecho alterado deverá ser comparado com sua versão original após a correção.

5.3 Modelo aprovado

Define o tipo correto de exame, seu escopo, a ordem anatômica e a redação padronizada.

Ajuda a reconhecer trechos pertencentes a outro exame, campos não preenchidos e estruturas indevidamente incluídas ou omitidas.

Não é evidência de que uma estrutura foi examinada ou está normal naquele paciente.

Campos entre colchetes exigem dados rastreáveis. Opções mutuamente exclusivas exigem seleção baseada na fonte ou confirmação médica.

Trechos opcionais só podem ser usados quando o item foi efetivamente avaliado e documentado.

5.4 Regra para texto normal em fontes não exaustivas

REGRA DE RETENÇÃO, REDAÇÃO E INSERÇÃO / RETENÇÃO: texto normal já existente no DOCX pode ser mantido quando corresponde exatamente ao modelo aprovado do exame, não é contradito pela fonte e não há limitação documentada. / REDAÇÃO: a linguagem de um trecho normal já existente pode ser ajustada ao modelo sem ampliar o escopo nem acrescentar estruturas. / INSERÇÃO: é proibido inserir nova afirmação de normalidade que não esteja no documento-fonte, no DOCX original ou em confirmação expressa do médico. / DADOS INDIVIDUALIZADOS: medidas, classificações, percentis, diagnósticos e Doppler nunca podem ser obtidos do modelo.

Essa regra evita dois erros opostos: marcar todo texto normal como inventado apenas porque o manuscrito é abreviado, ou usar o modelo como tinta invisível para preencher o que nunca foi documentado.

5.5 Quando o modelo não pode ser aplicado

Tipo de exame ou via de acesso diferente.

Exame incompleto, limitado ou direcionado a uma região menor.

Achado patológico que exige substituição do trecho normal correspondente.

Ausência de modelo exato na biblioteca.

Conflito entre o modelo e uma instrução médica específica.

Campos obrigatórios sem dados rastreáveis.

AUSÊNCIA DE MODELO EXATO / Não escolher o modelo mais parecido por conveniência. Registrar “modelo aprovado não disponível para este exame”, aplicar as regras gerais e solicitar definição antes de uma reconstrução ampla.

6. Organização dos lotes e arquivos

Cada e-mail será tratado como um lote independente. Os arquivos permanentes do projeto devem conter somente regras, modelos e referências sem dados reais de pacientes.

Pasta | Conteúdo | Regra
00_FONTE | PDF ou outro documento-fonte do lote. | Não editar. Evitar credenciais, QR codes, telefones e dados não necessários.
01_DOCX_ORIGINAIS | Todos os DOCX recebidos no e-mail. | Não sobrescrever nem renomear após o início da auditoria, salvo cópia registrada.
02_DOCX_REVISADOS | Cópias corrigidas após autorização. | Adicionar o sufixo _REVISADO.
03_RELATORIO | Inventário, pareamentos, divergências, confirmações e log de alterações. | Manter até o encerramento do lote.
04_PRONTOS_PARA_IMPRESSAO | Originais aprovados e revisados liberados pelo médico. | Somente após a revisão final.

Padrão recomendado para a pasta principal: AAAA-MM-DD_LOCALIDADE. Exemplo: 2026-07-21_MARIBONDO.

7. Fluxo de trabalho obrigatório

7.1 Recebimento e integridade

Criar ou duplicar a pasta do lote.

Salvar o documento-fonte em 00_FONTE e os DOCX em 01_DOCX_ORIGINAIS.

Confirmar que todos os arquivos abrem e não estão corrompidos.

Registrar a quantidade esperada de exames, quando informada.

Registrar as versões ativas do Manual Mestre e dos Modelos Aprovados.

7.2 Inventário antes da auditoria clínica

Contar os pacientes ou exames identificados no documento-fonte.

Contar os DOCX recebidos.

Identificar arquivos duplicados, ausentes, vazios, corrompidos ou com nomes divergentes.

Não iniciar a auditoria clínica antes de resolver o inventário.

7.3 Pareamento

Associar cada página ou conjunto de páginas ao DOCX correspondente.

Usar nome completo ou identificador inequívoco como critério principal.

Usar tipo de exame, data, sexo e idade apenas como critérios auxiliares.

Interromper o pareamento quando houver risco de unir pacientes diferentes.

7.4 Seleção do modelo aprovado

Identificar o tipo exato de exame e a via de acesso.

Selecionar o modelo de mesmo nome e escopo na biblioteca.

Registrar o modelo e a versão no relatório.

Não usar modelo de abdome total para abdome superior, mamas para axilas, tireoide para região cervical ou exame com Doppler para exame sem Doppler.

7.5 Extração segura do documento-fonte

Registrar somente o que estiver presente e suficientemente legível.

Separar identificação, medidas, achados, limitações, conclusão anotada e recomendações.

Em obstetrícia, separar idade gestacional, método de datação, biometria, PFE, percentil, placenta, líquido e cada vaso Doppler.

7.6 Auditoria sem edição

Executar as três camadas descritas no capítulo 9.

Classificar cada divergência.

Apresentar o relatório antes de qualquer alteração.

Aguardar autorização médica.

7.7 Correção e segunda auditoria

Gerar cópia _REVISADO apenas dos arquivos autorizados.

Alterar somente os pontos aprovados.

Registrar todas as mudanças.

Comparar novamente fonte, original, revisado, modelo e autorização.

REGRA DE SEGURANÇA DO PAREAMENTO / Não utilizar semelhança aproximada para unir pacientes diferentes. Nomes semelhantes, abreviados ou parcialmente legíveis exigem confirmação.

8. Protocolo de leitura da caligrafia

Categoria | Critério | Conduta
Leitura segura | Palavra, abreviação, número e lateralidade inequivocamente legíveis. | Pode ser utilizado na auditoria.
Leitura provável, não segura | Há hipótese plausível, mas outra leitura é possível. | Não corrigir. Apresentar hipótese e solicitar confirmação.
Ilegível | Não é possível reconhecer o conteúdo com segurança. | Não utilizar como dado. Classificar como confirmação médica.
Conflitante | Duas anotações ou partes da fonte se contradizem. | Não escolher. Solicitar decisão médica.
Rótulo ausente | Número ou índice sem identificação inequívoca. | Não atribuir por posição ou ordem habitual.

Não completar abreviações desconhecidas por associação habitual.

Não transformar número parcialmente visível em medida exata.

Não inferir vírgula, casa decimal ou unidade pela faixa esperada.

Não usar a ordem costumeira das anotações para nomear vasos do Doppler sem rótulo.

Quando possível, ampliar visualmente a página; se a dúvida persistir, manter como dúvida.

9. Auditoria em três camadas

9.1 Camada 1 - Fidelidade: documento-fonte × DOCX

Paciente, exame, data, sexo e idade.

Medidas, unidades, casas decimais e lateralidade.

Achados presentes, omitidos ou alterados.

Informação adicionada sem suporte.

Conclusão incompatível com a fonte.

Dados obstétricos, percentil e Doppler.

9.2 Camada 2 - Conformidade: DOCX × modelo aprovado

Tipo de exame, via, escopo anatômico e ordem das estruturas.

Campos residuais, colchetes, opções não selecionadas e texto pertencente a outro modelo.

Presença indevida ou ausência estrutural de órgãos conforme o exame.

Terminologia, títulos, técnica e formato da conclusão.

Trecho normal que contradiz achado positivo ou limitação.

Pontos de controle específicos impressos no modelo correspondente.

9.3 Camada 3 - Coerência interna e clínica

Descrição e conclusão concordantes.

Cálculos reproduzíveis.

Classificação compatível com os atributos descritos.

Recomendações rastreáveis.

Terminologia com grau de certeza adequado.

Ausência de contradições entre parágrafos.

ORDEM OBRIGATÓRIA / Primeiro compreender a fonte, depois comparar com o DOCX, em seguida verificar o modelo e, por último, analisar a coerência interna. Ler o DOCX antes da fonte pode induzir interpretação da caligrafia.

10. Classificação das inconsistências

Classe | Descrição | Exemplos
A. APROVADO | Fidelidade, estrutura e coerência satisfatórias. | Sem divergências relevantes.
B. AJUSTE FORMAL | Erro sem repercussão clínica. | Ortografia, pontuação, espaçamento, título ou formatação.
C. DIVERGÊNCIA ESTRUTURAL | DOCX não corresponde ao modelo aprovado ou ao escopo correto. | Órgão indevido, campo residual, modelo de outro exame, trecho obrigatório ausente.
D. DIVERGÊNCIA FONTE × DOCX | Diferença em dado individualizado ou interpretação. | Omissão de achado, medida divergente, lateralidade trocada, conclusão incompatível.
E. CONFIRMAÇÃO MÉDICA | Não é possível decidir com segurança apenas pelos arquivos. | Caligrafia ambígua, rótulo ausente, medida suspeita, modelo aplicável incerto.
F. INCONSISTÊNCIA CRÍTICA | Potencial para alterar paciente, diagnóstico, prognóstico ou conduta. | Paciente errado, erro obstétrico relevante, achado inventado, fluxo Doppler ausente ou reverso alterado.
G. NÃO ANALISÁVEL | Falta material suficiente para auditar. | Arquivo ausente, corrompido, sem correspondência ou ilegível.

A categoria C não significa automaticamente erro clínico. Um desvio do modelo pode ser justificado por limitação, exame direcionado ou decisão médica. A justificativa deve ser registrada.

11. Checklist geral de auditoria

11.1 Identificação e contexto documental

☐  Nome ou identificador do paciente.

☐  Data de nascimento, idade e sexo quando presentes.

☐  Data, tipo, via e local do exame.

☐  Nome do arquivo compatível com o conteúdo.

☐  Duplicidade ou mistura de pacientes.

☐  Pareamento seguro.

☐  Modelo aprovado e versão registrados.

11.2 Fidelidade ao documento-fonte

☐  Todos os achados legíveis transcritos.

☐  Nenhuma medida, unidade ou lateralidade alterada.

☐  Nenhum achado individualizado acrescentado sem base.

☐  Limitações e observações preservadas.

☐  Recomendação específica mantida quando documentada.

11.3 Conformidade com o modelo aprovado

☐  Escopo anatômico correto.

☐  Ausência de estruturas de outro exame.

☐  Campos e opções resolvidos.

☐  Técnica compatível com a via realizada.

☐  Texto normal não conflita com achados.

☐  Conclusão segue o padrão sem repetir desnecessariamente a descrição.

11.4 Anatomia e lateralidade

☐  Direita e esquerda em todas as estruturas pares.

☐  Correspondência entre descrição, medidas e conclusão.

☐  Compatibilidade entre sexo, idade e estruturas descritas.

☐  Local anatômico e lado presentes em partes moles e musculoesquelético.

11.5 Números, unidades e cálculos

☐  Vírgula, ponto e casas decimais.

☐  Unidades corretas: mm, cm, mL, g, semanas e dias, índices adimensionais.

☐  Volumes, médias, razões e percentis.

☐  Idade gestacional e DPP.

☐  Valor atípico ou tecnicamente suspeito sinalizado.

11.6 Descrição, interpretação e conclusão

☐  Toda conclusão tem suporte na descrição.

☐  Achados positivos não desapareceram.

☐  Diagnósticos e classificações usam os critérios aplicáveis.

☐  Informação clínica não substitui achado.

☐  Recomendações não foram geradas automaticamente.

12. Alertas prioritários em obstetrícia

ALERTA PRIORITÁRIO 1 - PERCENTIL DO PESO FETAL ESTIMADO / Sempre que houver PFE e idade gestacional, conferir se o percentil foi informado, qual curva foi utilizada e se o resultado é reproduzível. PFE sem percentil não pode ser interpretado como crescimento adequado por silêncio.

Confirmar a idade gestacional de referência e sua origem.

Conferir o PFE em gramas e a biometria utilizada, quando disponível.

Identificar a fórmula de peso e a curva/tabela de percentil adotadas.

Verificar se o percentil está na descrição e/ou conclusão conforme o padrão.

Quando ausente, registrar: “PFE presente, percentil não informado”.

Calcular apenas se PFE, idade gestacional e referência estiverem definidos e o cálculo puder ser reproduzido.

Não preencher como p50, adequado ou normal por aproximação.

Se o percentil estiver presente, conferir semana, arredondamento, unidade e curva.

Diferenciar resultado percentílico de diagnóstico clínico. Não diagnosticar restrição de crescimento apenas por um percentil isolado ou por uma omissão.

ALERTA PRIORITÁRIO 2 - DOPPLER OBSTÉTRICO / Todo exame com Doppler deve ser revisado vaso por vaso. Um número isolado não pode ser classificado sem confirmar vaso, índice, lateralidade, idade gestacional e referência.

Confirmar o vaso: artéria umbilical, artéria cerebral média, artérias uterinas direita e esquerda, ducto venoso ou outro.

Confirmar o índice: IP/PI, IR/RI, relação S/D, velocidade sistólica máxima ou outra medida.

Conferir casa decimal, unidade quando aplicável e transcrição.

Conferir idade gestacional e curva de referência específica.

Conferir lateralidade das uterinas e calcular o IP médio somente quando ambas estiverem identificadas.

Conferir o índice cerebroplacentário quando solicitado ou informado: IP da ACM dividido pelo IP da artéria umbilical.

Não calcular média ou razão quando faltar componente, houver dúvida de rótulo ou medidas de exames diferentes.

Verificar fluxo diastólico da artéria umbilical quando houver alteração qualitativa.

Verificar onda a do ducto venoso e outras características qualitativas quando registradas.

Não inferir incisura protodiastólica das uterinas pela medida isolada.

Não usar ponto de corte fixo para todas as idades gestacionais quando a referência é dependente da gestação.

Fluxo diastólico ausente ou reverso, alteração do ducto venoso ou outro padrão crítico nunca pode ser omitido, suavizado ou corrigido por plausibilidade.

Situação | Classe mínima | Conduta
PFE sem percentil | D ou E | Calcular somente com idade gestacional e referência válidas; caso contrário, confirmar.
Percentil incompatível com PFE e idade gestacional | E | Rever peso, idade, curva e arredondamento.
Doppler com número sem vaso ou índice | E | Não atribuir pela ordem habitual.
Uterinas com lateralidade trocada | D | Comparar fonte e corrigir após autorização.
IP médio das uterinas incorreto | D | Recalcular usando apenas valores identificados.
Índice cerebroplacentário incorreto | D | Recalcular com IP ACM ÷ IP AU.
Fluxo diastólico ausente/reverso omitido | F | Interromper liberação e solicitar revisão médica imediata.
Interpretação “normal” sem referência identificável | E | Rever conforme a referência adotada.

13. Auditoria de cálculos

Todo cálculo deve ser reproduzível e baseado em medidas legíveis. Quando houver divergência, registrar os componentes, a fórmula, o resultado encontrado e o valor presente no DOCX.

Volumes: conferir as dimensões, a unidade, a constante e o arredondamento definidos no modelo ou protocolo.

Médias: conferir cada componente e o divisor.

Razões: conferir numerador, denominador, identidade das medidas e ordem da fórmula.

Idade gestacional e DPP: conferir data do exame, idade informada e método de datação.

Percentis: conferir curva, idade de referência, peso e arredondamento.

Resíduo pós-miccional: conferir se os volumes pré e pós estão identificados.

Quando a fórmula não estiver definida no projeto ou no modelo, não escolher silenciosamente; solicitar definição.

DADO MEDIDO × DADO CALCULADO / O relatório deve identificar claramente o que foi medido, o que foi calculado e o que foi interpretado. Um cálculo correto não autoriza um diagnóstico que dependa de outros critérios.

14. Aplicação dos modelos aprovados

14.1 Seleção

Selecionar o modelo exato pelo nome do exame, via e presença de Doppler.

Registrar: arquivo MODELOS_APROVADOS_DE_LAUDOS.docx, versão 1.0, e o número/nome do modelo aplicado.

Quando um exame combinar módulos, registrar todos os modelos utilizados.

Não misturar escopos apenas porque os textos são semelhantes.

14.2 Uso durante a auditoria

Comparar títulos, técnica, ordem anatômica, campos, opções, conclusão e pontos de controle.

Usar o modelo para detectar trechos residuais e estruturas indevidas.

Preservar dados individualizados da fonte mesmo quando diferirem do texto normal.

Substituir texto normal conflitante por descrição do achado somente após confirmação da leitura e autorização.

Não copiar um modelo inteiro sobre o laudo original para corrigir um único item.

14.3 Reconstrução ampla de laudo

Uma reconstrução completa só será realizada quando o DOCX estiver estruturalmente inadequado ou pertencer a outro exame. Antes da edição, devem existir:

pareamento seguro do paciente;

inventário completo dos dados legíveis;

modelo aprovado exato;

lista das informações ausentes;

autorização médica para reconstrução;

revisão integral após a geração.

PROIBIÇÃO DE SUBSTITUIÇÃO CEGA / Não substituir em massa todos os DOCX pelo modelo normal. A correção deve preservar dados legítimos do paciente e impedir que achados sejam apagados.

15. Catálogo dos modelos e controles essenciais

Os textos completos e os pontos de controle detalhados permanecem no arquivo MODELOS_APROVADOS_DE_LAUDOS.docx. A tabela abaixo funciona como mapa obrigatório de seleção e auditoria.

Nº | Modelo aprovado | Controles essenciais
1 | Abdome total | Escopo correto; excluir órgãos pélvicos e parede abdominal; não chamar pâncreas limitado de normal.
2 | Abdome superior | Não incluir rins, bexiga, aorta/VCI, parede abdominal ou pelve.
3 | Rins e vias urinárias | Lateralidade e medidas; ureteres/adrenais apenas se demonstráveis; não incluir órgãos pélvicos.
4 | Próstata por via abdominal | Três dimensões, volume e bexiga; resíduo só com volumes identificados; não declarar normalidade para idade sem critério.
5 | Pelve feminina transabdominal | Contexto do endométrio; medidas uterinas/ovarianas; classificação de massas anexiais quando aplicável.
6 | Transvaginal | Via correta; avaliação transabdominal complementar somente se realizada; vagina apenas quando pertinente.
7 | Parede abdominal | Região inguinal é exame separado; diástase exige nível e medida; não incluir órgãos internos.
8 | Região inguinal | Lateralidade e manobras realizadas; defeito e conteúdo apenas quando documentados.
9 | Partes moles | Local e lateralidade exatos; conclusão limitada à área examinada.
10 | Obstétrica inicial endovaginal | Datação pelo CCN após embrião visível; DUM/critério de datação; vitalidade e localização.
11 | Obstétrica de 2º e 3º trimestres | PFE com percentil e curva; não redatar gestação; biometria, placenta e líquido coerentes.
12 | Obstétrica com Dopplerfluxometria | Vaso, índice, lateralidade, idade e referência; uterinas, IP médio, ACM, AU, ICP e padrões qualitativos.
13 | Gestação gemelar | Corionicidade/amnionicidade; dados, PFE e percentil separados por feto; não misturar placentas ou biometria.
14 | Translucência nucal | Faixa técnica adequada; CCN e técnica; não interpretar medida isolada fora do protocolo.
15 | Perfil biofísico fetal | Componentes ultrassonográficos e pontuação; reatividade cardíaca exige cardiotocografia.
16 | Colo uterino na gestação | Via transvaginal, medida e alterações dinâmicas/manobras registradas.
17 | Tireoide | Região cervical não incluída automaticamente; nódulo exige atributos e ACR TI-RADS; Doppler só se realizado.
18 | Mamas | Axilas são exame separado; BI-RADS coerente com o achado de maior suspeição; BI-RADS 1 apenas em exame verdadeiramente negativo.
19 | Região cervical | Não incluir tireoide, glândulas salivares ou vasos cervicais sem solicitação específica.
20 | Axila | Lateralidade; não confundir com exame das mamas.
21 | Bolsa escrotal com Doppler | Medidas e perfusão bilateral; dor aguda exige avaliação apropriada; varicocele requer medidas e dinâmica/refluxo.
22 | Glândulas salivares | Não incluir tireoide nem avaliação global de linfonodos cervicais.
23 | Ombro | Lateralidade, manobras e limitações; ultrassom não avalia integralmente estruturas intra-articulares.
24 | Cotovelo | Lateralidade e compartimentos; Doppler somente quando realizado.
25 | Punho | Estruturas e lado; não excluir túnel do carpo sem medidas e correlação adequadas.
26 | Joelho | Escopo ultrassonográfico; não substituir RM para meniscos, cruzados e cartilagem profunda.
27 | Tornozelo | Lateralidade e compartimento-alvo quando o pedido for direcionado.
28 | Pé e fáscia plantar | Local da medida, técnica e contexto; não interpretar espessura fascial isoladamente.
29 | Músculo ou tendão localizado | Estrutura, lado e área examinada precisamente delimitados.

16. Relatório de auditoria

16.1 Resumo do lote

Campo | Conteúdo
Lote | Data, localidade e origem do e-mail.
Fonte | Nome do PDF ou documento-fonte.
Modelos | Arquivo e versão dos modelos utilizados.
Contagem | Pacientes na fonte, DOCX, pareamentos seguros, duvidosos e ausentes.
Resultado | Aprovados, formais, estruturais, divergentes, críticos e não analisáveis.

16.2 Registro por paciente

Campo | Conteúdo obrigatório
Arquivo | Nome exato do DOCX.
Paciente/identificador | Conforme fonte.
Exame e modelo | Tipo auditado e modelo aplicado.
Pareamento | Seguro, duvidoso ou não realizado.
Classificação | A, B, C, D, E, F ou G.
Local do problema | Cabeçalho, técnica, estrutura, medida, conclusão, Doppler etc.
Fonte | Dado legível e página.
DOCX | Trecho ou valor atual.
Modelo | Regra estrutural relevante, quando aplicável.
Natureza | Omissão, inclusão, lateralidade, cálculo, estrutura, interpretação, formatação etc.
Proposta | Correção sugerida sem executar.
Ação | Aprovar, corrigir após autorização, confirmar ou revisar imagens.

16.3 Log de alteração

Arquivo | Texto original | Texto revisado | Motivo | Base autorizadora
[arquivo] | [trecho] | [novo trecho] | [divergência] | [fonte / cálculo / confirmação / modelo]

17. Confirmação médica

As perguntas devem resolver uma divergência por vez e apresentar o contexto necessário sem induzir resposta.

MODELO DE PERGUNTA / Paciente: [nome ou identificador] / Arquivo e exame: [DOCX / tipo] / Documento-fonte: [página e dado cuja leitura é duvidosa] / DOCX atual: [trecho] / Modelo aplicável: [nome, se relevante] / Dúvida objetiva: [uma pergunta] / Opções: confirmar leitura A, confirmar leitura B, revisar imagem ou manter sem alteração.

Não agrupar ambiguidades diferentes em uma pergunta vaga.

Registrar a resposta no relatório do lote.

Não transformar ausência de resposta em autorização.

Quando a resposta modificar dado derivado, recalcular e revisar a conclusão.

18. Correção controlada dos DOCX

Preservar o arquivo original sem alterações.

Criar cópia com sufixo _REVISADO.

Alterar somente documentos e pontos expressamente autorizados.

Manter a formatação original, salvo correção formal aprovada.

Usar o modelo aprovado para estrutura e redação, sem ampliar escopo.

Não introduzir achado, medida, diagnóstico, classificação ou recomendação nova.

Quando corrigir achado positivo, remover o trecho normal conflitante no mesmo local.

Não utilizar substituição global entre arquivos ou pacientes.

Registrar texto anterior, texto novo, motivo e base.

Interromper a edição se surgir nova dúvida.

CORREÇÃO DE PERCENTIL OU DOPPLER / Qualquer alteração de PFE, percentil, idade gestacional, vaso, índice, lateralidade, IP médio, ICP ou interpretação Doppler exige recálculo, revisão da conclusão e segunda auditoria obrigatória.

19. Segunda auditoria e liberação

Todo arquivo revisado deve ser comparado com quatro referências: documento-fonte, DOCX original, modelo aprovado e autorização médica.

☐  Confirmar que a correção foi aplicada no paciente e no local corretos.

☐  Confirmar que nenhum trecho não autorizado foi alterado.

☐  Recalcular valores derivados afetados.

☐  Verificar se o modelo correto foi mantido.

☐  Revisar novamente conclusão, PFE, percentil e Doppler.

☐  Classificar como LIBERADO PARA CONFERÊNCIA MÉDICA FINAL ou AINDA NECESSITA DE REVISÃO.

☐  Somente após a conferência médica copiar o arquivo para 04_PRONTOS_PARA_IMPRESSAO.

REGRA FINAL / Nenhum arquivo será classificado como pronto para impressão sem conferência e liberação do médico responsável.

20. Aprendizado e controle de versões

Correções específicas de um paciente não se tornam regras permanentes. Nova regra só será incorporada após validação expressa do médico e publicação de nova versão do documento correspondente.

Registrar a proposta de nova regra e sua origem.

Distinguir exceção individual de padrão reutilizável.

Definir se a mudança pertence ao Prompt Mestre, ao Manual ou aos Modelos Aprovados.

Atualizar número da versão, data e histórico.

Registrar compatibilidade entre versões do manual e dos modelos.

Remover ou arquivar versões antigas para evitar conflito.

Revisar periodicamente referências normativas.

20.1 Quando atualizar o Manual

Mudança no fluxo de auditoria, classificação, hierarquia, autorização ou privacidade.

Novo alerta de segurança transversal.

Nova regra de integração entre fonte, DOCX e modelos.

20.2 Quando atualizar os Modelos Aprovados

Novo tipo de exame.

Mudança de escopo, terminologia, campos ou texto normal.

Atualização normativa específica de um exame.

Nova forma de conclusão ou ponto de controle.

21. Privacidade e retenção

Utilizar somente dados necessários para pareamento e auditoria.

Evitar CPF, endereço, telefone, chaves de acesso, senhas, QR codes e credenciais quando não forem indispensáveis.

Manter lotes reais fora dos arquivos permanentes de conhecimento do projeto.

Não reutilizar informações de um paciente em outro lote.

Excluir ou remover os arquivos do ambiente de trabalho após salvamento local, impressão e encerramento, conforme a política aplicável.

Preservar confidencialidade, sigilo profissional e proteção de dados.

Não inserir exemplos reais de pacientes em futuras versões do manual ou dos modelos.

22. Comandos operacionais recomendados

22.1 Inventário e pareamento

ATIVE O MODO AUDITORIA.

Consulte obrigatoriamente:
1. Manual_Mestre_de_Auditoria_de_Laudos_v2.0.docx
2. MODELOS_APROVADOS_DE_LAUDOS.docx

Este material corresponde a um único e-mail e a um único lote.
O documento de 00_FONTE é a fonte primária.
Os arquivos de 01_DOCX_ORIGINAIS são os laudos digitados.

Nesta etapa:
- não altere arquivos;
- conte os exames da fonte e os DOCX;
- identifique duplicidades, ausências e arquivos corrompidos;
- pareie cada registro pelo nome ou identificador inequívoco;
- identifique o tipo de exame e o modelo aprovado correspondente;
- apresente a tabela de pareamento;
- aguarde minha aprovação.


22.2 Auditoria comparativa em três camadas

O inventário e os pareamentos estão aprovados.

Prossiga sem alterar arquivos:
1. Compare documento-fonte × DOCX.
2. Compare DOCX × modelo aprovado correspondente.
3. Verifique coerência interna, cálculos, classificação e conclusão.

Não complete caligrafia, números, lateralidade ou campos por plausibilidade.
Não marque automaticamente como erro o texto normal já existente no DOCX quando ele corresponde ao modelo correto, não é contradito pela fonte e não amplia o escopo.

Nos exames obstétricos:
- confira obrigatoriamente PFE, percentil, curva e idade gestacional;
- revise todo Doppler vaso por vaso;
- confira uterinas, IP médio, artéria umbilical, ACM, ICP e padrões qualitativos quando presentes.

Classifique cada laudo de A a G e apresente as divergências.
Aguarde minha autorização.


22.3 Correção controlada

Corrija somente os documentos e pontos que autorizei.

- preserve os originais;
- crie cópias com o sufixo _REVISADO;
- utilize o modelo aprovado apenas para estrutura e redação autorizadas;
- não acrescente dados ou normalidades;
- não altere outros trechos;
- registre texto original, texto revisado, motivo e base;
- interrompa se surgir nova dúvida.


22.4 Auditoria final

Faça uma segunda auditoria dos arquivos revisados.

Compare:
1. documento-fonte;
2. DOCX original;
3. arquivo revisado;
4. modelo aprovado;
5. minhas autorizações.

Não faça novas alterações.
Recalcule valores derivados afetados.
Revise novamente PFE, percentil e Doppler.
Informe quais estão:
- LIBERADOS PARA CONFERÊNCIA MÉDICA FINAL;
- AINDA NECESSITAM DE REVISÃO.


23. Checklist antes da impressão

☐  Paciente, exame e arquivo corretos.

☐  Fonte e DOCX pareados com segurança.

☐  Modelo aprovado e versão registrados.

☐  Todas as divergências resolvidas ou explicitamente mantidas.

☐  Medidas, unidades, casas decimais e lateralidade conferidas.

☐  Cálculos reproduzidos.

☐  Descrição e conclusão coerentes.

☐  Texto normal não contradiz achados ou limitações.

☐  PFE e percentil conferidos ou ausência devidamente sinalizada.

☐  Doppler obstétrico revisado vaso por vaso.

☐  Arquivo revisado não contém alterações não autorizadas.

☐  Liberação médica final registrada.

24. Referências e aprovação

24.1 Documentos internos

Prompt Mestre do projeto Digitador de Laudos 2.0 / Ultralaudo AI.

Manual Mestre de Auditoria de Laudos v2.0.

MODELOS_APROVADOS_DE_LAUDOS.docx, versão 1.0, consolidado em 22/07/2026.

Anexos do e-mail “modelos de laudos 2026”, utilizado como base dos modelos do projeto.

24.2 Referências técnicas e normativas

FEBRASGO: referência primária definida pelo projeto para ginecologia e obstetrícia.

Colégio Brasileiro de Radiologia e Diagnóstico por Imagem: Normatização de Exames de Ultrassonografia, revisão vigente.

Consenso CBR-FEBRASGO para exames ginecológicos e obstétricos.

ISUOG Practice Guidelines para biometria, crescimento fetal, Doppler e ultrassonografia do terceiro trimestre, quando necessária fonte complementar.

FMF e outras referências específicas somente quando o parâmetro não estiver definido na fonte primária, com identificação explícita.

A versão das referências deverá ser verificada quando houver mudança normativa ou quando um cálculo, classificação ou ponto de corte depender da atualização.

24.3 Aprovação

Responsável | Data | Assinatura/validação
Dr. Diogo S. Ribeiro - CRM 5789/AL | ____/____/________ | ________________________________________

ENTRADA EM VIGOR / Este documento substitui integralmente o Manual Mestre de Auditoria de Laudos v1.0 após sua validação e inclusão como fonte ativa do projeto. A instrução do projeto deve apontar para o arquivo Manual_Mestre_de_Auditoria_de_Laudos_v2.0.docx.
