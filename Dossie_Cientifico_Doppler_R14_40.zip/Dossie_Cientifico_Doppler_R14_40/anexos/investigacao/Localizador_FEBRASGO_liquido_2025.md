# Identificação da fonte de líquido

Título: Ultrassonografia obstétrica do terceiro trimestre da gestação. Femina, 2025. DOI 10.61622/0100-7254536202507.

Local: Table 1, p.833. PDF acessado por recuperação textual, cinco páginas impressas 831–835. A página editorial apresenta 831–840: divergência de metadados registrada, sem alteração da paginação usada para localizar a tabela.

Conteúdo diretamente acessado na tabela: MBV oligo <2 cm, normal ≥2 e <8, poli ≥8; ILA oligo <5 cm, normal ≥5 e <24, poli ≥24. Concorda com os cortes aprovados. Não reabre a decisão.

Página: https://femina.org.br/article/ultrassonografia-obstetrica-do-terceiro-trimestre-da-gestacao/

PDF: https://femina.org.br/wp-content/uploads/sites/12/articles_xml/0100-7254-femina-53-6-0831/0100-7254-femina-53-6-0831.pdf

Download físico tentado: HTTP 403. Esse PDF não está incluído neste ZIP. Não foi obtida captura visual. O PDF morfológico recuperado 821–830 é outro documento; número “43” não deve ser usado sozinho como identificador.
