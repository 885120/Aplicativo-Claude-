#!/usr/bin/env python3
"""Reprodução independente de Ciobanu S1: dias, log10 e precisão publicada.

Não usa funções do app. Não reconstrói a carta de 2021. Biblioteca padrão.
Uso: python3 ciobanu_s1_conferencia.py
"""
from pathlib import Path
from decimal import Decimal as D, localcontext
from statistics import NormalDist
import csv
import json
import math

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'dados'
PI=D('3.1415926535897932384626433832795028841971693993751058209749445923078164062862089986280348253421170679')


def cdf(z,precision=80):
    with localcontext() as ctx:
        ctx.prec=precision+12
        z=D(z)
        if abs(z)>4:raise ValueError('fora do domínio verificado')
        term=total=z
        n=0
        while abs(term)>=D(10)**(-precision-5):
            n+=1
            term*=-(z*z)/2*D(2*n-1)/D(n*(2*n+1))
            total+=term
            if n>1500:raise ArithmeticError('série não convergiu')
        value=D('.5')+total/(2*PI).sqrt()
        ctx.prec=precision
        return +value


def quantile(p,precision=80):
    with localcontext() as ctx:
        ctx.prec=precision
        p=D(p)
        if p==D('.5'):return D(0)
        lo,hi=D(-4),D(4)
        for _ in range(280):
            mid=(lo+hi)/2
            if cdf(mid,precision)<p:lo=mid
            else:hi=mid
        return +(lo+hi)/2


def read(name):
    with (DATA/name).open(encoding='utf-8',newline='') as f:
        return list(csv.DictReader(f))


def write(name,rows):
    with (DATA/name).open('w',encoding='utf-8',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows([{k:format(v,'.24g') if isinstance(v,D) else v for k,v in row.items()} for row in rows])


def poly(record,d):
    names=('intercepto','dia','dia2','dia3')
    value=sum(D(record[k])*d**i for i,k in enumerate(names))
    # Intervalo por célula, sob hipótese de coeficientes arredondados ao
    # mais próximo. Zero estrutural não é tratado como número arredondado.
    uncertainty=sum(D(1).scaleb(D(record[k]).as_tuple().exponent)*D('.5')*d**i
                    for i,k in enumerate(names) if record[k]!='0')
    return value,uncertainty


def run():
    with localcontext() as ctx:
        ctx.prec=80
        coef=read('ciobanu_s1_coeficientes.csv')
        assert len(coef)==6
        records={(r['vaso'],r['parametro']):r for r in coef}
        zs={p:quantile(D(p)/100) for p in (5,50,95)}
        for p,z in zs.items():
            assert abs(float(z)-NormalDist().inv_cdf(p/100))<3e-15
            assert abs(z-quantile(D(p)/100,65))<D('1e-62')
        def calc(v,d,p):
            median,dm=poly(records[v,'mediana'],d)
            sigma,ds=poly(records[v,'dp_log10'],d)
            assert sigma-ds>0
            if v=='AU':
                assert median-dm>0
                mu=median.log10();lo_mu=(median-dm).log10();hi_mu=(median+dm).log10()
            else:mu=median;lo_mu=median-dm;hi_mu=median+dm
            z=zs[p]
            value=D(10)**(mu+z*sigma)
            lo_z=min(z*(sigma-ds),z*(sigma+ds))
            hi_z=max(z*(sigma-ds),z*(sigma+ds))
            return value,D(10)**(lo_mu+lo_z),D(10)**(hi_mu+hi_z)
        plus0=[]
        supplied=read('ciobanu_45_comparacoes_idades_diferentes.csv')
        for row in supplied:
            v,p,d=row['vaso'],int(row['percentil']),D(row['IG_valor_informado_dias'])
            value,lo,hi=calc(v,d,p)
            given=D(row['valor_informado_pedido_mais0'])
            diff=value-given
            plus0.append({'IG_dias':d,'IG_semanas':int(d)//7,'vaso':v,'percentil':p,
                          'calculado_S1':value,'valor_informado_pedido':given,
                          'diferenca':diff,'compatibilidade_3_casas':abs(diff)<=D('.0005'),
                          'nota':'valor informado pelo usuário; HTML R14.32 não executado'})
        write('ciobanu_45_resultados_mais0.csv',plus0)
        same=[]
        original=read('ciobanu2019_tabela2_original.csv')
        for row in original:
            d=D(row['ig_dias'])
            for v in ('AU','ACM','CPR'):
                for p in (5,50,95):
                    value,lo,hi=calc(v,d,p)
                    table=D(row[f'{v}_p{p}']);diff=value-table
                    overlap=lo<=table+D('.0005') and hi>=table-D('.0005')
                    same.append({'IG_dias':d,'semana_rotulo':row['semana_rotulo'],'vaso':v,'percentil':p,
                                 'calculado_S1':value,'tabela_original_mesma_IG':table,
                                 'diferenca_assinada':diff,'diferenca_absoluta':abs(diff),
                                 'diferenca_relativa_pct_tabela':diff/table*100,
                                 'compativel_arredondamento_celula_0_001':abs(diff)<=D('.0005'),
                                 'limite_inferior_hipotese_coeficientes_arredondados':lo,
                                 'limite_superior_hipotese_coeficientes_arredondados':hi,
                                 'intervalo_celula_compativel_hipotese_coeficientes':overlap,
                                 'nota':'intervalo por célula; não prova coeficiente único para todas as linhas nem causa histórica'})
        write('ciobanu_198_comparacoes_mesma_IG.csv',same)
        maxima={}
        for v in ('AU','ACM','CPR'):
            for p in (5,50,95):
                sub=[r for r in same if r['vaso']==v and r['percentil']==p]
                worst=max(sub,key=lambda r:r['diferenca_absoluta'])
                maxima[f'{v}_p{p}']={k:format(worst[k],'.24g') if isinstance(worst[k],D) else worst[k]
                    for k in ('IG_dias','calculado_S1','tabela_original_mesma_IG','diferenca_assinada','diferenca_relativa_pct_tabela')}
        result={'precisao_decimal':80,'modelo':'mediana AU numérica linear; medianas ACM/CPR em log10; DP das três em log10 por quadrática; IG em dias',
                'origem_coeficientes':'cópia recuperada da Table S1; não ajustados à Table 2',
                'recalculos_mais0':len(plus0),'compativeis_valores_informados_mais0':sum(r['compatibilidade_3_casas'] for r in plus0),
                'comparacoes_mesma_IG':len(same),'compativeis_so_arredondamento_celula':sum(r['compativel_arredondamento_celula_0_001'] for r in same),
                'compativeis_intervalo_coeficientes_por_celula':sum(r['intervalo_celula_compativel_hipotese_coeficientes'] for r in same),
                'hipotese_intervalo':'coeficientes arredondados ao mais próximo na precisão impressa; análise por célula; não prova um único vetor nem explica historicamente a correspondência',
                'maximos_por_vaso_percentil':maxima,'carta_devore_acessada':False,'replica_acessada':False,'HTML_R14_32_executado':False}
        (ROOT/'resumo_ciobanu.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
        print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__=='__main__':run()
