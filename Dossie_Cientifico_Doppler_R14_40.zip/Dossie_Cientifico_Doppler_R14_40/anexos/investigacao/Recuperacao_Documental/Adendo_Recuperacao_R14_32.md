# Documentos recuperados e atualização da investigação R14.32

**Adendo documental e numérico — 6 de outubro de 2026**

## Resultado da busca

Recuperei a cópia do suplemento de Ciobanu 2019 que contém as **Tabelas S1, S2 e S3**. Ela já estava no acervo do projeto e também dentro de dois pacotes anteriores. O arquivo foi aberto, seus coeficientes foram transcritos e os cálculos foram reproduzidos independentemente.

Também recuperei os protocolos **FEBRASGO nº 43, de 2025, e nº 90, de 2026**, além do SMFM Consult nº 70, de 2024. Estes documentos estão no pacote, com sua proveniência e seus hashes.

**Ainda não localizei o HTML nem o dossiê identificado como R14.32, os textos originais da carta e da réplica de 2021, a planilha de DeVore ou o texto integral de Mari 1995.** O histórico recuperável contém relatos sobre alguns desses materiais; relatos de IA não substituem os documentos.

Este adendo atualiza a afirmação anterior de que o suplemento S1 não havia sido acessado. Não substitui o restante do relatório anterior, não representa auditoria da implementação R14.32 e não declara a teoria encerrada. Nenhum código do app foi alterado.

## Alcance efetivo da procura

- Consulta ao histórico de conversas recuperável nesta sessão, com buscas por versão, autores e documentos faltantes.
- Inventário dos 393 itens da pasta “Digitador de laudos 2.0” e dos diretórios disponíveis no acervo.
- Inventário de 132 arquivos HTML e dos metadados de 78 arquivos ZIP disponíveis. O inventário não equivale à leitura integral desses 210 arquivos.
- Mapeamento dos arquivos acessíveis em /workspace; inspeção de diretórios internos de 51 conteúdos ZIP distintos, inclusive pacotes aninhados. Cópias com o mesmo hash foram deduplicadas.
- Leitura dos dois DOCX anexados nesta sessão: Manual Mestre de Auditoria de Laudos v2.0 e Modelos Aprovados de Laudos, incluindo parágrafos e tabelas.
- Abertura dos documentos candidatos relevantes e leitura dos trechos primários usados neste adendo. Pacotes sem fontes pertinentes não foram tratados como evidência científica.

Essa busca cobre o acervo que os recursos desta sessão conseguem recuperar. Não permite afirmar que todo o histórico da conta, arquivos de outros dispositivos ou pastas não conectadas foram examinados.

## Situação das peças faltantes

| Pendência | Situação | O que permite concluir |
|---|---|---|
| Ciobanu 2019: Tabelas S1–S3 | RECUPERADA E ACESSADA | Transcrição dos coeficientes e conferência de p5/p50/p95 nas mesmas idades. |
| HTML e dossiê R14.32 | NÃO LOCALIZADOS | Não é possível verificar qual função ou versão de curva essa implementação usa. Foram identificados arquivos anteriores, incluindo R14.28. |
| DeVore 2021, DOI 10.1002/uog.23578, pp.349–350 | NÃO LOCALIZADO O TEXTO RELEVANTE | Não acessei a argumentação da carta; não posso atribuir a ela uma causa ou recomendação. |
| uog23578-sup-0001-AppendixS1.xlsx | NÃO LOCALIZADA | Não acessei os dados da planilha de DeVore. |
| Wright, Wright e Nicolaides 2021, DOI 10.1002/uog.23579, pp.350–351 | NÃO LOCALIZADO O TEXTO RELEVANTE | Não acessei a resposta; a representação recomendada pelos autores permanece desconhecida. |
| Mari 1995: texto integral, métodos e nomograma | NÃO LOCALIZADO | O domínio original e os coeficientes completos do nomograma continuam pendentes. |
| Hadlock 1985: tabelas originais de coeficientes | NÃO LOCALIZADAS NESTA BUSCA | Não encerra a conferência da fórmula biométrica de três/quatro parâmetros. |
| INTERGROWTH 2020, DOI 10.1002/uog.22000: corpo e S1/S2 | NÃO LOCALIZADOS | Não encerra a identificação da distribuição específica associada ao PFE de Hadlock. |

“Não localizado” significa ausência de recuperação nesta busca, e não inexistência do documento ou refutação de uma decisão aprovada.

## Ciobanu: fonte efetivamente recuperada

**Fonte primária reproduzida:** Ciobanu A, Wright A, Syngelaki A, Wright D, Akolekar R, Nicolaides KH. Fetal Medicine Foundation reference ranges for umbilical artery and middle cerebral artery pulsatility index and cerebroplacental ratio. Ultrasound in Obstetrics & Gynecology. 2019;53:465–472. DOI **10.1002/uog.20157**. Local: suplemento, **Table S1**, nota e seis linhas de coeficientes; artigo principal, Métodos pp.466–467 e Tabela 2 p.468.

**Nível real de acesso:** cópia DOCX do suplemento fornecida anteriormente no acervo do projeto. Foi lida integralmente como documento; S1 foi transcrita e utilizada nos cálculos. Não houve autenticação por novo download da editora nesta busca. S2 e S3 foram identificadas e lidas, mas não receberam uma auditoria numérica integral.

**Trecho literal curto da nota de S1:**

> “UA-PI median is numerical coefficient”

A nota distingue a mediana numérica da AU das medianas em log10 da ACM e da CPR. Os desvios-padrão são da variável transformada em log10; não se aplica uma segunda exponenciação ao desvio-padrão. A idade usada nos polinômios é em **dias**.

| Componente | Constante | d | d² | d³ |
|---|---|---|---|---|
| Mediana AU, linear | 1,6473 | −0,003005 | 0 | 0 |
| DP AU, log10 | 0,08713 | −0,0002936 | 0,0000009355 | 0 |
| Mediana ACM, log10 | 0,3117 | −0,007100 | 0,00006345 | −0,0000001443 |
| DP ACM, log10 | 0,1708 | −0,001199 | 0,000003211 | 0 |
| Mediana CPR, log10 | −0,3564 | 0,0003969 | 0,00003199 | −0,00000009266 |
| DP CPR, log10 | 0,1948 | −0,001220 | 0,000003262 | 0 |

Para AU: mediana = 1,6473 − 0,003005·d; μ = log10(mediana). Para ACM e CPR: μ é o polinômio de mediana indicado acima. Para as três: σ é o polinômio de DP indicado acima; **percentil = 10^(μ + z·σ)**. z corresponde ao quantil da normal padrão. Os resultados de IP e de CPR são adimensionais. O cálculo preserva precisão interna e só arredonda na apresentação.

## Conferência independente

**Estado: PARCIALMENTE CONFIRMADA.** Os coeficientes e os 45 valores informados em semanas +0 estão confirmados pela cópia acessada. A comparação na mesma idade da tabela foi executada, mas o argumento histórico e a recomendação da correspondência de 2021 permanecem não resolvidos.

O script usa aritmética Decimal com 80 dígitos, quantis normais calculados independentemente e teste de estabilidade a 65 dígitos. Os coeficientes são os impressos em S1, sem ajuste aos números da tabela e sem copiar a função do app como oráculo.

| IG | AU p5 / p50 / p95 | ACM p5 / p50 / p95 | CPR p5 / p50 / p95 |
|---|---|---|---|
| 24+0 | 0,896 / 1,142 / 1,457 | 1,339 / 1,681 / 2,109 | 1,094 / 1,492 / 2,035 |
| 28+0 | 0,826 / 1,058 / 1,356 | 1,492 / 1,867 / 2,335 | 1,316 / 1,789 / 2,431 |
| 32+0 | 0,752 / 0,974 / 1,262 | 1,510 / 1,919 / 2,440 | 1,432 / 1,978 / 2,731 |
| 36+0 | 0,676 / 0,890 / 1,172 | 1,328 / 1,748 / 2,301 | 1,370 / 1,960 / 2,804 |
| 40+0 | 0,599 / 0,806 / 1,084 | 0,972 / 1,351 / 1,876 | 1,121 / 1,693 / 2,558 |

**45/45 valores coincidem com os valores informados, a três casas decimais.** Isso confirma a reprodução desses números, não a execução do HTML R14.32.

A Tabela 2 publica âncoras em +3 dias: por exemplo, 171 dias = 24+3. Portanto, a linha “24 semanas” não é uma observação em 24+0. Recalculei as 22 linhas em suas idades exatas, para os três vasos e três percentis: **198 comparações**.

- 74/198 cálculos ficam na célula de arredondamento de ±0,0005 do número tabulado com três casas.
- 124/198 têm resíduos além dessa célula. Logo, o arredondamento do resultado final, sozinho, não explica toda a diferença.
- Sob a hipótese explícita de que cada coeficiente foi arredondado ao mais próximo na precisão impressa, os intervalos propagados são compatíveis com **198/198 células**, considerando também a precisão da tabela.

A última verificação é **por célula**. Não prova que um único conjunto de coeficientes não arredondados reproduza simultaneamente todas as linhas, não prova a causa histórica das diferenças e não substitui a carta e a réplica. Coeficientes arredondados podem acumular diferença em termos de d² e d³; atribuir isso aos autores sem ler a correspondência seria inferência indevida.

### Maiores resíduos nos cortes p5/p95

Diferença = cálculo com S1 impresso − Tabela 2 na mesma idade. Percentual relativo ao valor tabulado. Os CSVs contêm todas as 198 comparações, inclusive p50.

| Corte | IG exata | S1 calculado | Tabela 2 | Diferença | Relativa |
|---|---|---|---|---|---|
| AU p5 | 30+3 | 0,781387692 | 0,782 | -0,000612308 | -0,0783% |
| AU p95 | 30+3 | 1,298359772 | 1,299 | -0,000640228 | -0,0493% |
| ACM p5 | 36+3 | 1,296793858 | 1,300 | -0,003206142 | -0,2466% |
| ACM p95 | 40+3 | 1,816664927 | 1,821 | -0,004335073 | -0,2381% |
| CPR p5 | 39+3 | 1,165713355 | 1,167 | -0,001286645 | -0,1103% |
| CPR p95 | 39+3 | 2,613142442 | 2,615 | -0,001857558 | -0,0710% |

**Separação da evidência:** o suplemento e as âncoras em dias são conteúdo original acessado; os números e intervalos acima são cálculo independente; a compatibilidade com precisão de coeficientes é uma interpretação condicional do cálculo. A explicação de DeVore e a preferência dos autores não foram acessadas. As cópias em três locais são o mesmo documento, não três fontes científicas independentes.

**Certeza:** alta para a transcrição e a reprodução dos 45 números; alta para os resíduos calculados com os coeficientes impressos; condicionada à hipótese de arredondamento na análise de intervalos; insuficiente para afirmar a recomendação dos autores em 2021.

**Proposta para o app, sujeita à decisão médica:** preservar a representação aprovada até obter a correspondência; documentar S1, a unidade em dias e a distinção entre +0 e +3; confrontar a função real da R14.32 com estes CSVs quando seu HTML estiver disponível. Não propor troca de curva com base apenas em comparação entre idades diferentes.

## Referências brasileiras recuperadas

### FEBRASGO nº 43 — documento oficial de 2025

**Fonte:** Federação Brasileira das Associações de Ginecologia e Obstetrícia, Comissão Nacional Especializada de Ultrassonografia em Ginecologia e Obstetrícia. Ultrassonografia morfológica do segundo trimestre. Femina. 2025;53(6):821–830. Protocolo de Obstetrícia nº 43. **DOI não identificado no documento.** Texto integral recuperado; localização das passagens abaixo: p.822 e p.828 impressas, páginas 2 e 8 do PDF.

**Original, p.822, biometria do átrio ventricular:**

> “normal < 10 mm”

O trecho informa medida interna-interna e normalidade abaixo de 10 mm. Não localizei nas seções pertinentes acessadas uma regra automática de reavaliação em 3–4 semanas para átrio isolado de 9–9,9 mm. A ausência dessa regra neste protocolo não prova ausência em toda a literatura. A questão documental do retorno automático permanece aberta, sem transformar uma faixa operacional já aprovada em diagnóstico novo.

**Original, p.828, rastreamento do colo:**

> “com medida do colo ≤ 25 mm antes de 24 semanas”

O contexto é de mulheres assintomáticas, gestação única e sem história de parto pré-termo, com recomendações preventivas nesse cenário. Sustenta a necessidade de contexto de IG e população; não estabelece por si só uma categoria diagnóstica universal após 24 semanas. Não confere categorias universais de ≤15 mm ou 26–30 mm.

**Inferência/proposta:** explicitar IG e contexto no rótulo e na documentação do app; não extrapolar automaticamente a conduta desta população para qualquer colo ou gestação. Certeza alta para as passagens; decisão de texto/conduta pertence ao médico. Esta recuperação não altera a hierarquia FEBRASGO → CBR → ISUOG.

### FEBRASGO nº 90 — documento oficial de 2026

**Fonte:** Federação Brasileira das Associações de Ginecologia e Obstetrícia, Comissão Nacional Especializada em Medicina Fetal. Restrição do crescimento fetal. Femina. 2026;54(5):391–399. Protocolo de Obstetrícia nº 90. **DOI não identificado no documento.** Cópia integral recuperada; identidade e versão lidas na p.391, página 1 do PDF.

O arquivo foi incluído para disponibilizar a fonte brasileira. Não foi feita nesta busca uma reconciliação integral dos algoritmos de RCF, nem uma revisão das decisões aprovadas. Recuperar a referência não valida automaticamente sua implementação.

### SMFM Consult nº 70 — complemento, não substituto da FEBRASGO

**Fonte:** Society for Maternal-Fetal Medicine; Biggio J; SMFM Publications Committee. SMFM Consult Series #70: Management of short cervix in individuals without a history of spontaneous preterm birth. American Journal of Obstetrics and Gynecology. 2024. DOI **10.1016/j.ajog.2024.05.006**. Cópia integral de 12 páginas recuperada; título e recomendações na primeira página, DOI na última.

Foi incluído como material complementar para a lacuna do colo. Não substitui a hierarquia brasileira e não foi usado para modificar a conduta do app nesta rodada.

## Proveniência e documentos entregues

| Arquivo recuperado | Onde estava | Uso nesta rodada |
|---|---|---|
| uog20157-sup-0002-Tables.docx | Cópia avulsa em “Digitador de laudos 2.0”; também em Auditoria_C0B1_schema7_2026-09-20.zip e CONTINUIDADE_Digitador_Laudos_2_0_2026-09-24.zip | S1 transcrita; S2/S3 identificadas e lidas. As três cópias verificadas têm os mesmos bytes. |
| FEBRASGO_43_2025_morfologico.pdf | PACOTE_CLAUDE_POS_B2f1_2026-09-23.zip, pasta 05_FONTES_R3/fontes | Passagens do átrio e colo conferidas. |
| FEBRASGO_RCF_2026.pdf | Mesmo pacote, pasta 05_FONTES_R3/fontes | Identificação e versão conferidas; teoria de RCF preservada. |
| SMFM_70_2024_colo.pdf | Mesmo pacote, pasta 05_FONTES_R3/fontes | Documento complementar recuperado. |

SHA-256 do suplemento recuperado: **462701e98e87380826d9f86e3497636abf3af595a7553e7ac9c9136d2c433ffb**. Os demais hashes e os caminhos internos exatos constam em proveniencia_documentos.csv e SHA256SUMS.txt.

## Manual Mestre e Modelos Aprovados

Os dois anexos desta sessão foram lidos diretamente. O Manual Mestre, seção 24, registra a FEBRASGO como referência primária do projeto, seguida de CBR/consenso CBR-FEBRASGO, ISUOG como complemento e FMF para lacunas. O documento registra os Modelos Aprovados como versão 1.0, consolidada em 22/07/2026.

O Apêndice B dos Modelos lista referências normativas do CBR, incluindo a Parte II do consenso CBR-FEBRASGO. São indicações de fontes; não equivalem ao texto integral dessas diretrizes. Nenhum dos dois DOCX contém o suplemento ou a correspondência original faltante, nem identifica uma implementação R14.32.

Esses arquivos são regras e modelos operacionais do projeto, não evidência científica primária. Foram preservados sem alteração em documentos_operacionais/. Sua disponibilidade resolve a antiga ausência destes anexos no acervo desta investigação, mas não as lacunas científicas remanescentes.

## O que mudou e o que falta

A lacuna de acesso ao suplemento S1 está resolvida. A conferência dos coeficientes e dos 45 valores em +0 foi executada. A comparação na mesma IG está disponível em CSV, com diferenças e limites explícitos. As fontes FEBRASGO recuperadas permitem melhorar a rastreabilidade das passagens já pertinentes.

Continuam necessários para fechar os itens respectivos: HTML/dossiê R14.32; carta DeVore e sua planilha; réplica Wright/Wright/Nicolaides; original completo de Mari 1995; tabelas de Hadlock 1985 e materiais de INTERGROWTH 2020 se essa combinação estiver implementada.

**Nenhum erro novo da implementação R14.32 foi demonstrado**, porque ela não está disponível. Também não há nova decisão clínica. Devem permanecer preservadas as curvas e decisões aprovadas até conferência documental específica e decisão do médico responsável.
