# Recuperação documental R14.32

Este pacote é um adendo à investigação anterior. Não é o aplicativo R14.32 nem uma nova aprovação clínica.

Abra primeiro Adendo_Recuperacao_R14_32.pdf. Os originais recuperados estão em fontes/. Os cálculos independentes e suas hipóteses estão em ciobanu_s1_conferencia.py; os resultados completos estão em dados/ e resumo_ciobanu.json. proveniencia_documentos.csv registra a origem das cópias.

Para reproduzir os cálculos, use Python 3.11 ou posterior e execute:

    python3 ciobanu_s1_conferencia.py

O cálculo usa apenas a biblioteca padrão. Não usa nem modifica o motor do app. build_pdf.py gera o PDF a partir do Markdown, usando ReportLab e DejaVu Sans.

SHA256SUMS.txt confere os arquivos originais do pacote antes de qualquer regeneração. A assinatura aplicada ao PDF disponibilizado separadamente pode mudar seus bytes em relação à cópia interna do ZIP.

Ainda faltam: HTML/dossiê R14.32; carta DeVore 2021, sua planilha e réplica; original completo de Mari 1995; tabelas de Hadlock 1985 e corpo/suplementos de INTERGROWTH 2020, conforme uso real do app. Não trate relatos de IA localizados no histórico como fontes científicas.

Os dois DOCX de regras e modelos, recebidos nesta sessão, estão preservados sem alteração em documentos_operacionais/. Não são usados como prova científica primária.
