#!/usr/bin/env python3
"""Conferência documental, sem usar funções do app e sem dependências externas.

Executar: python3 calculos_independentes.py
Entrada: CSVs transcritos das publicações, em dados/.
Saída: CSVs de conferência e resumo_calculos.json.
Ciobanu: nenhum coeficiente de S1 foi presumido. Sua reprodução está bloqueada.
"""
from pathlib import Path
from decimal import Decimal as D, localcontext
import csv
import json
import math
from statistics import NormalDist

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "dados"
PI = D("3.1415926535897932384626433832795028841971693993751058209749445923078164062862089986280348253421170679")
PCTS = (3, 5, 10, 25, 50, 75, 90, 95, 97)


def normal_cdf(z, precision=80):
    """Integral da densidade normal, por série de Taylor; Decimal.

    Domínio deste estudo: |z| < 4. Não é aproximação copiada do app.
    Série: Phi(z)=1/2+[sum((-1)^n*z^(2n+1)/(2^n*n!*(2n+1)))]/sqrt(2*pi).
    """
    with localcontext() as ctx:
        ctx.prec = precision + 12
        z = D(z)
        if abs(z) > 4:
            raise ValueError("z fora do domínio verificado da série")
        term = z
        total = term
        n = 0
        epsilon = D(10) ** (-precision - 5)
        while True:
            n += 1
            term *= -(z*z)/2 * D(2*n-1)/D(n*(2*n+1))
            total += term
            if abs(term) < epsilon:
                break
            if n > 1500:
                raise ArithmeticError("série não convergiu")
        result = D("0.5") + total/(2*PI).sqrt()
        ctx.prec = precision
        return +result


def normal_quantile(p, precision=80):
    with localcontext() as ctx:
        ctx.prec = precision
        p = D(p)
        if p == D("0.5"):
            return D(0)
        if not D("0.001") < p < D("0.999"):
            raise ValueError("p fora do domínio verificado")
        lo, hi = D(-4), D(4)
        for _ in range(280):
            mid = (lo+hi)/2
            if normal_cdf(mid, precision) < p:
                lo = mid
            else:
                hi = mid
        return +(lo+hi)/2


def hadlock_median(week):
    week = D(week)
    return (D("0.578")+D("0.332")*week-D("0.00354")*week*week).exp()


def hadlock_percentile(week, z):
    week = D(week)
    return (D("0.578")+D("0.332")*week-D("0.00354")*week*week+D("0.12")*z).exp()


def mari_median(week):
    return (D("2.31")+D("0.046")*D(week)).exp()


def mari_coefficient_rounding_feasibility(original):
    """Cálculo condicional de compatibilidade da precisão publicada.

    Não estima coeficientes originais nem propõe trocar a fórmula.
    Pergunta: existe a,b que arredondem a 2.31 e 0.046 e reproduzam
    todas as células escolhidas, admitindo +/-0.05 cm/s na publicação?
    Resolve a interseção exata de restrições lineares após ln().
    """
    output = {}
    groups = {
        "somente_12_medianas": {"mom_1": D(1)},
        "48_celulas_multiplicacao_direta": {"mom_1": D(1), "mom_1_29": D("1.29"), "mom_1_50": D("1.5"), "mom_1_55": D("1.55")},
    }
    for name, factors in groups.items():
        # Restrição da precisão decimal do intercepto a.
        cells = [(D(0), D("2.305"), D("2.315"))]
        for row in original:
            for key, factor in factors.items():
                value = D(row[key])
                cells.append((D(row["ig_semanas"]), ((value-D("0.05"))/factor).ln(), ((value+D("0.05"))/factor).ln()))
        b_lower, b_upper = D("0.0455"), D("0.0465")
        same_week_ok = True
        for wi, li, ui in cells:
            for wj, lj, uj in cells:
                diff = wi-wj
                if diff > 0:
                    b_lower = max(b_lower, (li-uj)/diff)
                elif diff < 0:
                    b_upper = min(b_upper, (li-uj)/diff)
                elif li > uj:
                    same_week_ok = False
        feasible = b_lower <= b_upper and same_week_ok
        result = {
            "viavel_sob_hipotese_de_arredondamento": feasible,
            "limite_inferior_b": plain(b_lower), "limite_superior_b": plain(b_upper),
            "hipotese": "coeficientes arredondados ao mais próximo; células +/-0.05; MoM multiplicado sem arredondamento intermediário",
            "interpretacao": "possibilidade matemática, não evidência sobre o processamento original",
        }
        if feasible:
            b = (b_lower+b_upper)/2
            a_lower = max(lower-b*w for w, lower, upper in cells)
            a_upper = min(upper-b*w for w, lower, upper in cells)
            a = (a_lower+a_upper)/2
            if not all(lower <= a+b*w <= upper for w, lower, upper in cells):
                raise AssertionError("testemunho hipotético não satisfaz restrições")
            result["a_testemunho_hipotetico_nao_original"] = plain(a)
            result["b_testemunho_hipotetico_nao_original"] = plain(b)
        output[name] = result
    return output


def plain(x):
    if isinstance(x, D):
        return format(x, ".24g")
    return x


def write_csv(filename, rows):
    with (DATA/filename).open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        for row in rows:
            writer.writerow({k: plain(v) for k, v in row.items()})


def read_csv(filename):
    with (DATA/filename).open(encoding="utf-8", newline="") as f:
        return list(csv.DictReader(f))


def run():
    with localcontext() as ctx:
        ctx.prec = 80
        zs = {p: normal_quantile(D(p)/100) for p in PCTS}
        # Verificação contra implementação independente de dupla precisão.
        normal = NormalDist()
        checks = []
        for p, z in zs.items():
            double_z = normal.inv_cdf(p/100)
            error = abs(float(z)-double_z)
            if error > 3e-15:
                raise AssertionError((p, "quantil divergente", error))
            checks.append({"percentil": p, "z_decimal": plain(z), "z_statistics": double_z, "erro_abs": error})
            z65 = normal_quantile(D(p)/100, precision=65)
            if abs(z-z65) > D("1e-62"):
                raise AssertionError((p, "precisão 65/80 não converge"))

        orig = read_csv("hadlock1991_tabela1_original.csv")
        assert len(orig) == 31 and [int(x["ig_semanas"]) for x in orig] == list(range(10, 41))
        rows, anchors, witnesses, ordering = [], [], [], []
        for row in orig:
            week = int(row["ig_semanas"])
            values = [D(row[f"p{p}"]) for p in (3, 10, 50, 90, 97)]
            if values != sorted(values):
                ordering.append({"semana": week, "valores_p3_p10_p50_p90_p97": [plain(x) for x in values]})
            for p in (3, 10, 50, 90, 97):
                calculated = hadlock_percentile(week, zs[p])
                table = D(row[f"p{p}"])
                diff = calculated-table
                mu = hadlock_median(week).ln()
                implied = normal_cdf((table.ln()-mu)/D("0.12"))*100
                entry = {
                    "ig_semanas": week, "percentil_nominal": p,
                    "tabela_original_g": table, "equacao_sigma_log_0_12_g": calculated,
                    "diferenca_assinada_g": diff, "diferenca_absoluta_g": abs(diff),
                    "diferenca_relativa_pct_tabela": diff/table*100,
                    "compatibilidade_arredondamento_1g": "sim" if abs(diff) <= D("0.5") else "nao",
                    "percentil_da_tabela_no_modelo_log": implied,
                    "nota": "anomalia de ordenação literal p97; não corrigida" if week == 30 and p == 97 else "",
                }
                rows.append(entry)
                if week in (24, 28, 32, 36, 40):
                    anchors.append(entry)
            if week in (24, 28, 32, 36, 40):
                for p in (3, 10):
                    low = D(row[f"p{p}"])
                    high = hadlock_percentile(week, zs[p])
                    weight = ((low+high)/2).to_integral_value()
                    model_pct = normal_cdf((weight.ln()-hadlock_median(week).ln())/D("0.12"))*100
                    witnesses.append({
                        "ig_semanas": week, "peso_g": weight, "corte_nominal": p,
                        "corte_tabela_g": low, "corte_equacao_g": high,
                        "percentil_equacao": model_pct,
                        "abaixo_corte_tabela": "sim" if weight < low else "nao",
                        "abaixo_corte_equacao": "sim" if weight < high else "nao",
                        "consequencia": "classificação pode diferir; implementação R14.32 não recebida",
                    })
        write_csv("hadlock_conferencia_155_celulas.csv", rows)
        write_csv("hadlock_ancoras_25_celulas.csv", anchors)
        write_csv("hadlock_testemunhos_condicionais.csv", witnesses)
        write_csv("quantis_normais_verificacao.csv", checks)

        mari_orig = read_csv("mari2000_tabela3_original.csv")
        assert len(mari_orig) == 12
        mari_rows = []
        factors = {"mom_1": D(1), "mom_1_29": D("1.29"), "mom_1_50": D("1.5"), "mom_1_55": D("1.55")}
        for row in mari_orig:
            week = int(row["ig_semanas"])
            for key, factor in factors.items():
                calculated = mari_median(week)*factor
                published = D(row[key])
                diff = calculated-published
                mari_rows.append({
                    "ig_semanas": week, "fator_MoM": factor,
                    "tabela_original_cm_s": published, "calculado_cm_s": calculated,
                    "diferenca_assinada_cm_s": diff, "diferenca_absoluta_cm_s": abs(diff),
                    "diferenca_relativa_pct_tabela": diff/published*100,
                    "compatibilidade_arredondamento_0_1": "sim" if abs(diff) <= D("0.05") else "nao",
                })
        write_csv("mari_conferencia_48_celulas.csv", mari_rows)
        mari_precision = mari_coefficient_rounding_feasibility(mari_orig)
        mari_witnesses = []
        for week, velocity in ((24,"45.8"),(36,"79.7"),(40,"96.0")):
            row = next(r for r in mari_orig if int(r["ig_semanas"]) == week)
            velocity = D(velocity)
            cutoff = mari_median(week)*D("1.5")
            published = D(row["mom_1_50"])
            mari_witnesses.append({
                "IG_semanas": week, "PSV_cm_s": velocity,
                "mediana_formula_cm_s": mari_median(week),
                "MoM_formula": velocity/mari_median(week),
                "limiar_1_5_formula_cm_s": cutoff,
                "limiar_1_5_tabela_cm_s": published,
                "diferenca_limires_cm_s": cutoff-published,
                "acima_formula_1_5": velocity > cutoff,
                "acima_limiar_tabela": velocity > published,
                "interpretacao": "discordância entre representações publicadas; não é diagnóstico nem auditoria R14.32",
            })
        write_csv("mari_testemunhos_condicionais.csv", mari_witnesses)

        ciobanu = read_csv("ciobanu2019_tabela2_original.csv")
        assert len(ciobanu) == 22
        assert all(int(r["ig_dias"]) == 7*int(r["semana_rotulo"])+3 for r in ciobanu)
        # Valores fornecidos no pedido: NÃO são execução nem validação do HTML R14.32.
        reported = {
            24: {"AU": ("0.896", "1.142", "1.457"), "ACM": ("1.339", "1.681", "2.109"), "CPR": ("1.094", "1.492", "2.035")},
            28: {"AU": ("0.826", "1.058", "1.356"), "ACM": ("1.492", "1.867", "2.335"), "CPR": ("1.316", "1.789", "2.431")},
            32: {"AU": ("0.752", "0.974", "1.262"), "ACM": ("1.510", "1.919", "2.440"), "CPR": ("1.432", "1.978", "2.731")},
            36: {"AU": ("0.676", "0.890", "1.172"), "ACM": ("1.328", "1.748", "2.301"), "CPR": ("1.370", "1.960", "2.804")},
            40: {"AU": ("0.599", "0.806", "1.084"), "ACM": ("0.972", "1.351", "1.876"), "CPR": ("1.121", "1.693", "2.558")},
        }
        age_rows = []
        for row in ciobanu:
            week = int(row["semana_rotulo"])
            if week not in reported:
                continue
            for vessel in ("AU", "ACM", "CPR"):
                for i, p in enumerate((5, 50, 95)):
                    supplied = D(reported[week][vessel][i])
                    table = D(row[f"{vessel}_p{p}"])
                    diff = supplied-table
                    age_rows.append({
                        "vaso": vessel, "percentil": p, "semana_rotulo": week,
                        "IG_valor_informado_dias": week*7, "IG_tabela_dias": int(row["ig_dias"]),
                        "valor_informado_pedido_mais0": supplied, "tabela_original_mais3": table,
                        "diferenca_bruta": diff, "diferenca_absoluta": abs(diff),
                        "diferenca_relativa_pct_tabela": diff/table*100,
                        "interpretacao": "IDADES DIFERENTES; não é teste da equação nem defeito do app",
                    })
        write_csv("ciobanu_45_comparacoes_idades_diferentes.csv", age_rows)
        blocked = []
        for row in ciobanu:
            for vessel in ("AU", "ACM", "CPR"):
                for p in (5, 50, 95):
                    blocked.append({
                        "vaso": vessel, "percentil": p, "IG_dias": row["ig_dias"],
                        "tabela_original": row[f"{vessel}_p{p}"],
                        "equacao_recalculada": "", "diferenca_mesma_IG": "",
                        "estado": "BLOQUEADO: coeficientes da Tabela S1 não acessados",
                    })
        write_csv("ciobanu_198_comparacoes_mesma_IG_PENDENTES.csv", blocked)
        plus0 = []
        for week in (24,28,32,36,40):
            for vessel in ("AU","ACM","CPR"):
                for percentile in (5,50,95):
                    plus0.append({"IG_semanas":week,"IG_dias":7*week,"vaso":vessel,"percentil":percentile,"resultado_independente":"","estado":"BLOQUEADO: Tabela S1 não acessada; valores do pedido não são oráculo"})
        write_csv("ciobanu_45_recalculos_mais0_PENDENTES.csv", plus0)

        metrics = {
            "precisao_decimal": 80,
            "arredondamento": "somente saída; calculado vs publicado sem arredondamento prévio",
            "hadlock": {
                "celulas": len(rows),
                "compativeis_com_arredondamento_1g": sum(r["compatibilidade_arredondamento_1g"] == "sim" for r in rows),
                "por_percentil": {},
                "anomalias_ordenacao": ordering,
                "medianas": {str(w): plain(hadlock_median(w)) for w in (24,28,32,36,40)},
                "multiplicador_mais_1DP": plain(D("0.12").exp()),
                "multiplicador_menos_1DP": plain(D("-0.12").exp()),
                "coeficiente_variacao": plain((D("0.0144").exp()-1).sqrt()),
                "multiplicador_media_aritmetica_mediana": plain(D("0.0072").exp()),
            },
            "mari": {
                "celulas": len(mari_rows),
                "compativeis_arredondamento_0_1": sum(r["compatibilidade_arredondamento_0_1"] == "sim" for r in mari_rows),
                "max_diferenca_cm_s": plain(max(r["diferenca_absoluta_cm_s"] for r in mari_rows)),
                "arredondamento_coeficientes_analise_condicional": mari_precision,
                "dominio_diagnostico_2000": "15–36 semanas; não confundir com Tabela 3 18–40",
            },
            "ciobanu": {
                "linhas_tabela2": 22, "celulas_tabela2": 462,
                "todas_ancoras_mais3": True,
                "comparacoes_exemplo_IGs_diferentes": len(age_rows),
                "comparacoes_p5_p50_p95_mesma_IG_pendentes": len(blocked),
                "equacoes_recalculadas": False,
                "motivo": "Tabela S1, carta e réplica não acessadas; não inventar coeficientes ou recomendação",
            },
            "verificacao_numerica": {
                "quantis_statistics_normaldist": len(checks),
                "max_erro_quantile_dupla_precisao": max(c["erro_abs"] for c in checks),
                "quantis_decimal_65_vs_80": "9/9 convergentes dentro de 1e-62",
                "efw_conferencia_dupla_precisao": True,
            },
            "implementacao_R14_32_auditada": False,
        }
        for p in (3,10,50,90,97):
            sub = [r for r in rows if r["percentil_nominal"] == p]
            valid = [r for r in sub if not r["nota"]]
            metrics["hadlock"]["por_percentil"][str(p)] = {
                "celulas": len(sub),
                "compativeis_arredondamento_1g": sum(r["compatibilidade_arredondamento_1g"] == "sim" for r in sub),
                "max_diferenca_abs_g": plain(max(r["diferenca_absoluta_g"] for r in sub)),
                "intervalo_percentil_implicito_excluindo_anomalia": [plain(min(r["percentil_da_tabela_no_modelo_log"] for r in valid)), plain(max(r["percentil_da_tabela_no_modelo_log"] for r in valid))],
            }
        for r in rows:
            w,p = r["ig_semanas"],r["percentil_nominal"]
            double_result = math.exp(.578+.332*w-.00354*w*w+.12*normal.inv_cdf(p/100))
            if abs(double_result-float(r["equacao_sigma_log_0_12_g"])) > 3e-10:
                raise AssertionError("falha na conferência independente de dupla precisão")
        (ROOT/"resumo_calculos.json").write_text(json.dumps(metrics, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
        print(json.dumps(metrics, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    run()
