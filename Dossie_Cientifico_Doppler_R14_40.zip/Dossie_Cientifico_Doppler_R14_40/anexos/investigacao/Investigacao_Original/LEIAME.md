# Investigação científica e conferência numérica — R14.32

Data: 06/10/2026. Este pacote documenta uma investigação seletiva. Não contém uma versão nova do aplicativo e não modifica decisões clínicas.

## Comece pelo relatório

- Relatorio_Investigacao_R14_32.pdf: relatório para leitura, com respostas, fontes, estados de acesso, limites e propostas.
- Relatorio_Investigacao_R14_32.md: conteúdo editável do mesmo relatório.
- inventario_arquivos.csv: 56 arquivos efetivamente disponíveis, com tamanho e SHA-256. Não foi identificado HTML nem dossiê científico completo R14.32.
- fontes/registro_de_acesso.json e .csv: 20 referências, localização e nível real de acesso. Metadados, resumo, tradução e original integral estão distinguidos.

## Repita os cálculos

Os cálculos usam apenas a biblioteca padrão de Python. Ambiente de execução desta entrega: Python 3.12.14.

```bash
python3 calculos_independentes.py
python3 gerar_relatorio.py
```

Execute a partir da pasta descompactada. Os scripts também localizam seus próprios arquivos quando executados de outra pasta. O primeiro comando regenera os CSVs calculados e resumo_calculos.json. O segundo regenera o relatório Markdown, o registro CSV das fontes e a conferência tabular das uterinas.

As entradas primárias transcritas estão em:

- dados/ciobanu2019_tabela2_original.csv: 22 linhas, 462 valores; idades em dias, todas em +3.
- dados/hadlock1991_tabela1_original.csv: 31 linhas de 10 a 40 semanas; preserva o literal anômalo de p97 em 30 semanas, sem corrigi-lo.
- dados/mari2000_tabela3_original.csv: 12 linhas, quatro colunas MoM, de 18 a 40 semanas.

As saídas incluem todas as 155 comparações Hadlock e 48 comparações Mari, diferenças absolutas/relativas, testemunhos condicionais e verificação independente dos quantis normais. Decimal usa 80 dígitos; arredondamento ocorre apenas na saída. Os testes de precisão verificam a aritmética, não a validade clínica do modelo nem a implementação do app.

## Ciobanu: bloqueio explícito

Os dois CSVs com PENDENTES no nome deixam os resultados independentes em branco. Eles não são testes que passaram. A Tabela S1 e os textos relevantes de DeVore e da réplica não foram acessados. Nenhum coeficiente foi presumido nem ajustado a partir da tabela.

ciobanu_45_comparacoes_idades_diferentes.csv registra valores informados em +0 versus valores publicados em +3. Essa diferença bruta não demonstra discordância na mesma IG e não constitui defeito da implementação.

## Gere o PDF, se necessário

O PDF já está incluído. Para regenerá-lo, instale ReportLab e disponha das fontes DejaVu Sans. A geração desta entrega utilizou ReportLab 4.4.9.

```bash
python3 build_pdf.py
```

A pasta padrão de fontes é /usr/share/fonts/truetype/dejavu. Em outro sistema, defina DEJAVU_FONT_DIR para uma pasta com DejaVuSans.ttf e DejaVuSans-Bold.ttf. As variantes Oblique e BoldOblique são opcionais; o script usa as fontes regular/negrito se essas variantes não estiverem instaladas. A geração do PDF não é necessária para repetir os cálculos.

## Integridade e limites

SHA256SUMS.txt registra os hashes dos arquivos do pacote, exceto o próprio manifesto. Após descompactar em Linux, execute:

```bash
sha256sum -c SHA256SUMS.txt
```

Não foram redistribuídos artigos integrais protegidos. Os endereços consultados e as localizações estão no registro de fontes e no relatório. Os valores transcritos são entradas documentais; é possível confrontá-los com as publicações indicadas.

Nenhum erro específico da implementação R14.32 foi demonstrado, porque o HTML dessa versão não foi recebido. As consequências para o app são condicionais. Alterações de referência, limiar, operador ou regra exigem decisão do médico responsável. O relatório não declara a teoria globalmente encerrada.
