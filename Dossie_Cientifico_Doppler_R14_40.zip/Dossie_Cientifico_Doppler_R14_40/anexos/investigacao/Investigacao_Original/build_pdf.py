#!/usr/bin/env python3
"""Converte o relatório Markdown em PDF; não faz cálculo clínico.

Dependência: ReportLab. Fontes: DejaVu Sans, instaladas no sistema.
Uso: python3 build_pdf.py
"""
from pathlib import Path
import html
import os
import re

from reportlab.lib import colors
from reportlab.lib.styles import ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak,
)

ROOT = Path(__file__).resolve().parent
WIDTH, HEIGHT = 595.276, 841.890
MARGIN = 40
CONTENT = WIDTH - 2*MARGIN
FONT_DIR = Path(os.environ.get("DEJAVU_FONT_DIR", "/usr/share/fonts/truetype/dejavu"))


def prepare_fonts():
    for name, file in (
        ("DV", "DejaVuSans.ttf"), ("DVB", "DejaVuSans-Bold.ttf"),
        ("DVI", "DejaVuSans-Oblique.ttf"), ("DVBI", "DejaVuSans-BoldOblique.ttf"),
    ):
        path = FONT_DIR/file
        if not path.is_file() and name in ("DVI", "DVBI"):
            path = FONT_DIR/("DejaVuSans.ttf" if name == "DVI" else "DejaVuSans-Bold.ttf")
        pdfmetrics.registerFont(TTFont(name, str(path)))
    pdfmetrics.registerFontFamily("DV", normal="DV", bold="DVB", italic="DVI", boldItalic="DVBI")


def markup(text):
    # Processar links antes do texto impede transformar DOI dentro de href.
    links = []
    def keep_link(match):
        label = html.escape(match[1])
        url = html.escape(match[2], quote=True)
        links.append(f'<link href="{url}" color="#17617E">{label}</link>')
        return f"ZZLINKTOKEN{len(links)-1}ZZ"
    text = re.sub(r"\[([^\]]+)\]\((https?://[^)]+)\)", keep_link, text)
    text = html.escape(text)
    text = re.sub(r"\*\*(.*?)\*\*", r"<b>\1</b>", text)
    text = re.sub(r"`([^`]+)`", r"\1", text)
    text = re.sub(
        r"(10\.\d{4,9}/[A-Za-z0-9.\-/()]+[A-Za-z0-9])",
        lambda m: f'<link href="https://doi.org/{m[1]}" color="#17617E">{m[1]}</link>', text,
    )
    for i, link in enumerate(links):
        text = text.replace(f"ZZLINKTOKEN{i}ZZ", link)
    return text


def table_widths(headers):
    n = len(headers)
    if n == 7:
        weights = [45, 73, 79, 79, 79, 79, 79]
    elif n == 6:
        weights = [45, 94, 85, 100, 85, 106]
    elif n == 5:
        weights = [80, 85, 85, 73, 192]
    elif n == 4:
        weights = [102, 138, 138, 138]
    elif n == 3 and headers[0] == "Prioridade":
        weights = [45, 211, 259]
    elif n == 3 and headers[0] == "IG":
        weights = [55, 200, 260]
    elif n == 3 and headers[0].startswith("Pendência"):
        weights = [160, 125, 230]
    elif n == 3:
        weights = [145, 175, 195]
    else:
        weights = [1]*n
    return [CONTENT*x/sum(weights) for x in weights]


def footer(canvas, doc):
    canvas.saveState()
    canvas.setStrokeColor(colors.HexColor("#DCE5EB"))
    canvas.line(MARGIN, 42, WIDTH-MARGIN, 42)
    canvas.setFont("DV", 7.5)
    canvas.setFillColor(colors.HexColor("#607486"))
    canvas.drawString(MARGIN, 29, "INVESTIGAÇÃO DOCUMENTAL E NUMÉRICA • R14.32 • 06/10/2026")
    canvas.drawRightString(WIDTH-MARGIN, 29, str(doc.page))
    canvas.restoreState()


def run():
    prepare_fonts()
    body = ParagraphStyle("Body", fontName="DV", fontSize=9.4, leading=13.3,
                          spaceAfter=6, textColor=colors.HexColor("#243447"))
    title = ParagraphStyle("Title", parent=body, fontName="DVB", fontSize=21,
                           leading=26, spaceAfter=15, textColor=colors.HexColor("#123B50"))
    h2 = ParagraphStyle("H2", parent=body, fontName="DVB", fontSize=14,
                        leading=18.5, spaceBefore=12, spaceAfter=9, keepWithNext=True,
                        textColor=colors.HexColor("#123B50"))
    h3 = ParagraphStyle("H3", parent=h2, fontSize=10.6, leading=14.5,
                        spaceBefore=9, spaceAfter=6)
    cell = ParagraphStyle("Cell", parent=body, fontSize=8, leading=11.2, spaceAfter=0)
    small_cell = ParagraphStyle("SmallCell", parent=cell, fontSize=7.8, leading=10.6)
    quote = ParagraphStyle("Quote", parent=body, leftIndent=12, rightIndent=6,
                           borderColor=colors.HexColor("#3F7E98"), borderWidth=.6,
                           borderPadding=7, backColor=colors.HexColor("#F2F7FA"),
                           spaceBefore=5, spaceAfter=12)

    lines = (ROOT/"Relatorio_Investigacao_R14_32.md").read_text(encoding="utf-8").splitlines()
    story = []
    i = 0
    while i < len(lines):
        line = lines[i].strip()
        if not line:
            i += 1
            continue
        if line.startswith("|"):
            rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                parts = [s.strip() for s in lines[i].strip().strip("|").split("|")]
                if not all(re.fullmatch(r"[-:]+", s) for s in parts):
                    rows.append(parts)
                i += 1
            if not all(len(row) == len(rows[0]) for row in rows):
                raise ValueError("Tabela Markdown com número de colunas inconsistente")
            style = small_cell if len(rows[0]) >= 5 else cell
            cells = [[Paragraph(markup(value), style) for value in row] for row in rows]
            table = Table(cells, colWidths=table_widths(rows[0]), repeatRows=1, hAlign="LEFT")
            table.setStyle(TableStyle([
                ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#E6F0F5")),
                ("VALIGN", (0,0), (-1,-1), "TOP"),
                ("LEFTPADDING", (0,0), (-1,-1), 6),
                ("RIGHTPADDING", (0,0), (-1,-1), 6),
                ("TOPPADDING", (0,0), (-1,-1), 6),
                ("BOTTOMPADDING", (0,0), (-1,-1), 6),
                ("LINEBELOW", (0,0), (-1,0), .7, colors.HexColor("#3F7E98")),
                ("LINEBELOW", (0,1), (-1,-1), .3, colors.HexColor("#DCE5EB")),
            ]))
            story.extend([table, Spacer(1,9)])
            continue
        if line.startswith("# "):
            story.append(Paragraph(markup(line[2:]), title))
        elif line.startswith("## "):
            section = line[3:]
            if re.match(r"(?:3|4|5|6|7|11|14)\. ", section):
                story.append(PageBreak())
            story.append(Paragraph(markup(section), h2))
        elif line.startswith("### "):
            story.append(Paragraph(markup(line[4:]), h3))
        elif line.startswith("> "):
            story.append(Paragraph(markup(line[2:]), quote))
        elif line.startswith("- "):
            story.append(Paragraph("• "+markup(line[2:]), body))
        else:
            story.append(Paragraph(markup(line), body))
        i += 1

    out = ROOT/"Relatorio_Investigacao_R14_32.pdf"
    document = SimpleDocTemplate(
        str(out), pagesize=(WIDTH, HEIGHT), rightMargin=MARGIN, leftMargin=MARGIN,
        topMargin=42, bottomMargin=57,
        title="Investigação científica seletiva — Calculadora Doppler Obstétrico R14.32",
        author="OpenAI — investigação documental e cálculo independente",
        subject="Fontes originais, limitações de acesso e propostas sujeitas à decisão médica",
        invariant=1,
    )
    document.build(story, onFirstPage=footer, onLaterPages=footer)
    print(out)


if __name__ == "__main__":
    run()
