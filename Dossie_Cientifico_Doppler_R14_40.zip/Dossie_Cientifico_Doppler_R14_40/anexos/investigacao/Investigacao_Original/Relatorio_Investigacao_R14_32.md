# Investigação científica seletiva e conferência numérica — R14.32

Calculadora Doppler Obstétrico • SUS • Relatório de 06/10/2026

**Resultado:** a investigação resolveu parte das pendências, demonstrou diferenças documentais relevantes e identificou os arquivos exatos que ainda faltam. Não constitui fechamento científico global nem auditoria da implementação R14.32. Nenhum código, curva, operador ou decisão clínica foi alterado.

## 1. Inventário e alcance efetivo

Inventariei **56 arquivos disponíveis**: 2 DOCX, 11 ZIP, 7 HTML, 8 Markdown, 13 TXT, 2 Python, 2 JavaScript, 1 PDF e 10 imagens. O inventário completo, com tamanho e SHA-256, está em inventario_arquivos.csv. Pesquisei também os nomes dos conteúdos dos ZIPs.

**Não identifiquei HTML nem dossiê científico completo R14.32** nesse conjunto. Os HTML e pacotes identificáveis pertencem ao acervo histórico, principalmente R14.23–R14.28. Os dois DOCX operacionais são 01-MODELOS_APROVADOS_DE_LAUDOS-1-.docx e 02-Manual_Mestre_de_Auditoria_de_Laudos_v2.0-1-.docx. Não os utilizei como evidência científica primária. Relatórios anteriores de IA e números de testes não sustentam as conclusões deste relatório.

Por isso, “resultado comparado” significa resultado publicado ou valor informado no pedido, sempre identificado. **Não executei o HTML R14.32 e não demonstrei defeito específico dessa implementação.** Qualquer consequência para classificação no app é condicional até receber a versão exata.

Mantive a hierarquia de diretrizes **FEBRASGO → CBR → ISUOG**. Para as lacunas específicas investigadas, não obtive texto pertinente FEBRASGO/CBR que definisse preferência por essas curvas ou as categorias operacionais discutidas. Isso não demonstra que tal documento não exista. Usei ISUOG e, explicitamente como complementos, SMFM, estudos originais, FMF e documento NHS England/RCOG. A conferência matemática recorreu às publicações que originaram cada modelo.

## 2. Síntese dos estados

| Pendência examinada | Estado | Conclusão delimitada |
|---|---|---|
| Ciobanu: âncoras da Tabela 2 | CONFIRMADA | Todas as 22 linhas estão em +3 dias; não em +0. |
| Ciobanu: coeficientes, discrepância verdadeira e recomendação de 2021 | NÃO RESOLVIDA | Tabela S1, carta, planilha e réplica não acessadas. |
| Hadlock: equação, σlog e medianas | CONFIRMADA | Original integral confirma coeficientes e DP 0,12; medianas reproduzidas. |
| Hadlock: identidade dos percentis da equação e tabela | REFUTADA | Diferenças nos cortes p3/p10 não são arredondamento das células a 1 g. |
| Hadlock: origem exata da incoerência e melhor representação clínica | NÃO RESOLVIDA | Nem o artigo de 1991 nem a análise de 2026 resolvem a intenção original. |
| Hadlock/INTERGROWTH: versões e associação | PARCIALMENTE CONFIRMADA | Há padrão específico de 2020 para Hadlock; versão usada no app desconhecida. |
| PSV: fórmula e limiar; validação até 40+6 | PARCIALMENTE CONFIRMADA | Fórmula/1,5 MoM confirmados; estudo diagnóstico de 2000 cobriu 15–36 semanas. |
| PSV: fórmula impressa versus Tabela 3 | CONFIRMADA | Há diferenças reproduzidas; causa e coeficientes originais completos não resolvidos. |
| Uterinas: valores, técnica e preferência de diretriz | PARCIALMENTE CONFIRMADA | Valores conferidos; adequar curva à técnica. Preferência exclusiva não demonstrada. |
| Átrio isolado 9–9,9 mm: retorno automático | NÃO RESOLVIDA | Não localizei respaldo primário para regra automática de 3–4 semanas. |
| Ventriculomegalia: graduação e intervalos decimais | PARCIALMENTE CONFIRMADA | Graduação nominal confirmada; tradução decimal precisa ser declarada operacional. |
| Colo: ≤15 mm e 26–30 mm universais | PARCIALMENTE CONFIRMADA | Há cortes contextuais; não demonstram categorias universais em qualquer IG. |

“REFUTADA” refere-se à identidade matemática entre representações, não à validade clínica de toda a referência. “NÃO RESOLVIDA” não significa que uma decisão aprovada esteja errada.

## 3. Prioridade 1 — Ciobanu 2019 e correspondência de 2021

### Resposta direta

A Tabela 2 foi acessada integralmente: a linha “24 semanas” está em **171 dias = 24+3**, e o mesmo deslocamento ocorre em todas as linhas. Não consegui acessar S1 nem os corpos da carta e réplica; portanto, não posso quantificar a discordância verdadeira nem afirmar qual representação os autores recomendam.

**Estado:** âncoras CONFIRMADAS; comparação equação/tabela e recomendação dos autores NÃO RESOLVIDAS.

### Fonte, localização e acesso

Ciobanu A, Wright A, Syngelaki A, Wright D, Akolekar R, Nicolaides KH. UOG 2019;53:465–472. DOI **10.1002/uog.20157**. Original integral: Métodos pp.466–467; Tabela 2 p.468. Os coeficientes são remetidos à Tabela S1, cujo arquivo não acessei. [R01]

DeVore GR. UOG 2021;57:349–350. DOI **10.1002/uog.23578**. Acessei metadados e a descrição editorial de Appendix S1, não a argumentação nem os dados. Wright A, Wright D, Nicolaides KH. UOG 2021;57:350–351. DOI **10.1002/uog.23579**. Não acessei o corpo da réplica. [R02–R03]

**Trecho literal curto — Ciobanu, p.467:**

> “the regression coefficients are given in Table S1.”

**Nenhum trecho da carta ou réplica é apresentado**, pois não acessei seu texto relevante. A descrição editorial de uma planilha não equivale a ler suas células.

### Original, reprodução, cálculo e inferência

**Original acessado:** transformação log10/Gaussiana; relações de mediana e dispersão descritas nos Métodos; 22 âncoras em dias na Tabela 2. A codificação exata da variável dos coeficientes, a expressão executável de cada componente e sua precisão dependem de S1. Não transcrevi nem reconstruí coeficientes por ajuste da tabela.

**Valores primários da Tabela 2, apresentados com a precisão publicada:**

| IG exata | AU p5 / p50 / p95 | ACM p5 / p50 / p95 | CPR p5 / p50 / p95 |
|---|---|---|---|
| 24+3 (171 dias) | 0,889 / 1,134 / 1,446 | 1,360 / 1,705 / 2,137 | 1,121 / 1,526 / 2,079 |
| 28+3 (199 dias) | 0,818 / 1,049 / 1,346 | 1,504 / 1,883 / 2,357 | 1,336 / 1,817 / 2,471 |
| 32+3 (227 dias) | 0,744 / 0,965 / 1,252 | 1,503 / 1,915 / 2,441 | 1,436 / 1,988 / 2,753 |
| 36+3 (255 dias) | 0,668 / 0,881 / 1,162 | 1,300 / 1,718 / 2,272 | 1,353 / 1,944 / 2,795 |
| 40+3 (283 dias) | 0,591 / 0,797 / 1,075 | 0,931 / 1,302 / 1,821 | 1,086 / 1,653 / 2,514 |

**Valores informados no pedido:** os números atribuídos ao app em 24/28/32/36/40+0 permanecem dados não verificados da implementação. Não foram usados como prova de correção da equação. O CSV ciobanu_45_comparacoes_idades_diferentes.csv registra a diferença bruta desses números contra as linhas +3, com aviso em todas as linhas.

**Cálculo independente de idade:** 24 × 7 = 168 dias; a linha original tem 171 dias. Exemplo: AU p95 informado em 24+0 = 1,457; Tabela 2 em 24+3 = 1,446; diferença bruta = 0,011, ou 0,761% do valor tabelado. Esse par tem IG diferente. Não é uma divergência da carta nem um testemunho de defeito.

**Inferência:** uma comparação correta exige mesma IG e mesma definição de mediana/dispersão, antes de avaliar o arredondamento publicado. Ainda não determinei quanto da diferença bruta decorre da idade e quanto poderia decorrer de modelos distintos. Não afirmo que todo resíduo se explique por +3 dias.

### Situação dos cálculos solicitados

| Solicitação | Resultado desta investigação |
|---|---|
| Transcrição dos coeficientes/unidades/variável de S1 | Não executada: documento não acessado. |
| Equações em cinco idades +0, três medidas, três percentis | 45 resultados independentes ainda pendentes. |
| Equações nos dias exatos de todas as linhas | 198 comparações p5/p50/p95 ainda pendentes. |
| Transcrição integral da Tabela 2 | 22 linhas, 462 valores, com IG em dias. |
| Separação de erro por idade | Deslocamento +3 confirmado; parcela numérica não isolada. |
| Arredondamento e verdadeira discordância modelo/tabela | Não determinados sem coeficientes e correspondência. |
| Argumento de DeVore e resposta/recomendação dos autores | Não determinados; não deduzidos do título ou referências. |

O arquivo ciobanu_198_comparacoes_mesma_IG_PENDENTES.csv contém células calculadas em branco, não zeros. Não localizei uma correção acessível que pudesse ser aplicada; isso não afirma inexistência de errata.

**Certeza e limitações:** alta para a IG das linhas; insuficiente para a tese matemática da carta. Foram tentados editora, suplementos, fontes públicas institucionais e FMF. Os arquivos relevantes continuaram inacessíveis; não houve contorno de autenticação ou pagamento.

**Divergências entre fontes:** não avaliáveis diretamente no ponto em disputa, por falta dos textos de 2021. A diferença +0 versus +3 demonstrada acima deve ser retirada de qualquer contagem de discordância de modelo.

**Proposta sujeita à decisão médica:** manter provisoriamente a representação aprovada e identificar sua versão. Não trocar equação por tabela a partir das comparações com idade diferente. Fechar este item somente após obter uog20157-sup-0002-Tables.docx, uog23578-sup-0001-AppendixS1.xlsx e os corpos dos dois artigos de 2021.

## 4. Prioridade 2 — Hadlock 1991: dispersão e percentis

### Resposta direta

O original confirma **ln(PFE em g) = 0,578 + 0,332 × IG − 0,00354 × IG²**, com DP **0,12 no modelo logarítmico**. As cinco medianas informadas conferem. Os percentis derivados desse modelo não reproduzem a Tabela 1, especialmente p3/p10; isso tem potencial de mudar classificação, mas não demonstra qual versão a R14.32 executa.

**Estado:** parâmetros e medianas CONFIRMADOS; identidade equação/tabela REFUTADA; melhor escolha clínica e causa original NÃO RESOLVIDAS.

### Fonte primária, localização e trecho

Hadlock FP, Harrist RB, Martinez-Poyer J. Radiology 1991;181:129–133. DOI **10.1148/radiology.181.1.1887021**. Original integral: Resultados p.131, equação e DP; Tabela 1 p.130; Figura 2 p.130, resíduos relativos. População: 392 gestantes, predominantemente brancas de classe média, com exclusão de gestação múltipla. [R04]

**Trecho literal curto — Resultados, p.131:**

> “standard deviation = 0.12”

### Separação do significado de ±12,7%

**Original:** o artigo também descreve os resíduos relativos ao peso previsto como ±12,7%, 1 DP. Não explica um processamento adicional que reconcilie todos os percentis da tabela com os parâmetros impressos.

**Cálculo independente, assumindo a distribuição lognormal informada:** μ(IG) = 0,578 + 0,332 × IG − 0,00354 × IG²; mediana = exp(μ); percentil p = exp(μ + 0,12 × Φ⁻¹(p/100)). IG está em semanas, não em notação “semanas.dias”. Não confundir 24+3 com 24,3 semanas.

| Quantidade matemática | Resultado com σlog = 0,12 | Significado |
|---|---|---|
| Mediana | exp(μ) | p50; não é a média aritmética da lognormal. |
| Média aritmética | exp(μ) × 1,007225982 | 0,7226% acima da mediana. |
| Coeficiente de variação | 0,120433299 | 12,0433%; não 12,7% por identidade matemática. |
| +1 DP no espaço log | ×1,127496852 | +12,7497% sobre a mediana. |
| −1 DP no espaço log | ×0,886920437 | −11,3080% sobre a mediana. |

**Inferência delimitada:** a proximidade de exp(0,12) − 1 com 12,7% não prova que essa foi a derivação do número do artigo. Os resíduos percentuais descritos originalmente e os limites multiplicativos da lognormal são quantidades diferentes. É inadequado converter automaticamente “±12,7%” em σlog = 0,127 ou em DP linear de 12%.

### Medianas e percentis recalculados

| IG | Mediana calculada (g) | Inteiro informado e publicado (g) |
|---|---|---|
| 24+0 | 669,787 | 670 |
| 28+0 | 1.210,320 | 1.210 |
| 32+0 | 1.952,840 | 1.953 |
| 36+0 | 2.813,431 | 2.813 |
| 40+0 | 3.619,170 | 3.619 |

Conferi todas as **155 células da Tabela 1, 10–40 semanas**, preservando a precisão interna. As 31 medianas diferem no máximo 0,475 g, compatíveis com publicação a 1 g. No p3 e p10, nenhuma das 31 células de cada coluna é reproduzida apenas por esse arredondamento. No p90 também há diferenças numéricas menores; não as equiparo automaticamente à discrepância clínica das caudas inferiores.

| IG | Representação | p3 (g) | p10 (g) | p50 (g) | p90 (g) | p97 (g) |
|---|---|---|---|---|---|---|
| 24+0 | Tabela | 503 | 556 | 670 | 784 | 838 |
| 24+0 | Equação | 534,464 | 574,313 | 669,787 | 781,134 | 839,373 |
| 28+0 | Tabela | 908 | 1.004 | 1.210 | 1.416 | 1.513 |
| 28+0 | Equação | 965,788 | 1.037,795 | 1.210,320 | 1.411,525 | 1.516,765 |
| 32+0 | Tabela | 1.465 | 1.621 | 1.953 | 2.285 | 2.441 |
| 32+0 | Equação | 1.558,291 | 1.674,473 | 1.952,840 | 2.277,483 | 2.447,287 |
| 36+0 | Tabela | 2.110 | 2.335 | 2.813 | 3.291 | 3.516 |
| 36+0 | Equação | 2.245,009 | 2.412,391 | 2.813,431 | 3.281,140 | 3.525,774 |
| 40+0 | Tabela | 2.714 | 3.004 | 3.619 | 4.234 | 4.524 |
| 40+0 | Equação | 2.887,957 | 3.103,277 | 3.619,170 | 4.220,826 | 4.535,521 |

Nas cinco idades exibidas, os cortes p3 da equação excedem a tabela em aproximadamente 6,26–6,41%; os p10 em 3,29–3,37%. Em 40+0, a diferença é **173,957 g no p3** e **99,277 g no p10**. Percentis, diferenças absolutas/relativas e percentil implícito de cada célula estão em hadlock_conferencia_155_celulas.csv.

**Defeito documental demonstrado:** na linha 30 semanas, o p97 impresso é **1.649 g**, inferior ao p90 **1.824 g**. Conferi a impressão em imagem e preservei o literal no CSV. Não o corrigi silenciosamente. Isso só se torna defeito do app se essa célula anômala for efetivamente utilizada.

### Testemunhos e consequência condicional

| Entrada | Corte original | Corte da equação | Diferença | Resultado condicional |
|---|---|---|---|---|
| 32+0; 1512 g; p3 | 1.465,000 g | 1.558,291 g | 93,291 g | Acima do corte da tabela; abaixo do corte da equação |
| 32+0; 1648 g; p10 | 1.621,000 g | 1.674,473 g | 53,473 g | Acima do corte da tabela; abaixo do corte da equação |

**Entrada → fonte/fórmula → resultado → comparação:** 32+0, PFE 1.648 g; pela equação acima, o percentil é aproximadamente 7,862923 (valor preciso no CSV); o p10 calculado é 1.674,473 g e o tabelado 1.621 g. O peso está abaixo do p10 da equação e acima do p10 da tabela. A diferença entre os cortes é aproximadamente 53,473 g.

**Possível consequência:** alteração de elegibilidade ao critério de peso <p10 ou <p3. Não é confirmação automática de RCF nem comparação com uma execução do app. A versão de referência, a IG e os demais critérios continuam necessários.

### Análise primária de 2026

Adu-Bredu TK, Twumasi C, Mathewlynn S, Impey L, Ioannou C. BJOG 2026, Early View, 30/06/2026. DOI **10.1111/1471-0528.70296**. Texto integral acessado: Métodos 2.1–2.3, Tabelas 1–2 e Discussão 4.2–4.4. [R05]

**Trecho literal curto — Discussão 4.3:**

> “our study is not designed to determine which one is preferable.”

**Original de 2026:** análise funcional/PFFR-GAM e auditoria retrospectiva de 21.874 gestações únicas em Oxford, com exames entre 35+0 e 36+6. A tabela identificou 4,2% abaixo de p10, contra 7,2% pela equação; para p3, 0,8% contra 2,3%. Não há dados originais para reconstruir a causa da incoerência de 1991. A coorte clínica não valida todos os períodos gestacionais nem o SUS.

**Reprodução secundária:** as fórmulas de 1991 reapresentadas no artigo de 2026 são uma reprodução do trabalho antigo; nesta investigação, os coeficientes foram conferidos também diretamente em 1991. **Cálculo independente:** os resultados deste pacote não reutilizam o código R do estudo de 2026 nem a função do app.

**Inferência:** ampliar a fração classificada abaixo dos cortes pode ampliar seguimento e demanda no SUS. A diferença de classificação não prova benefício perinatal universal nem autoriza troca automática. A palavra “Mean” usada na notação de 2026 não muda a distinção matemática entre exp(μ) e média aritmética de uma lognormal.

**Certeza:** alta para coeficientes, medianas e divergências calculadas; baixa para reconstruir a intenção histórica e escolher uma versão clinicamente superior para a população brasileira.

**Proposta para o app:** se a versão aprovada for a equação, identificá-la como “Hadlock 1991 — percentis derivados da equação, σlog = 0,12”. Separar identificador de fórmula do PFE de identificador da curva de percentil. Não alegar identidade com a Tabela 1. Submeter qualquer mudança de referência a revisão médica e avaliação do efeito sobre classificação e demanda local.

## 5. Peso por Hadlock 1985 e associação com INTERGROWTH

### Resposta direta e estado

Calcular o PFE por uma fórmula de biometria e calcular seu percentil por uma distribuição de peso são operações diferentes. Existe publicação específica de INTERGROWTH para PFE estimado por Hadlock; portanto, essa associação não é automaticamente incorreta. Sem HTML R14.32 e sem coeficientes da versão de 2020, a associação concreta permanece **PARCIALMENTE CONFIRMADA**.

**Fontes e acesso:** Hadlock FP et al., AJOG 1985;151:333–337, DOI **10.1016/0002-9378(85)90298-4**: não acessei suas tabelas originais de coeficientes. Stirnemann J et al., UOG 2017;49:478–486, DOI **10.1002/uog.17347**, Resultados p.479 e Tabela 2: texto original acessado. Stirnemann J, Salomon LJ, Papageorghiou AT, UOG 2020;56:946–948, DOI **10.1002/uog.22000**: metadados e gráfico oficial acessados; corpo e S1/S2 não acessados. [R06–R08]

**Trecho literal curto — título editorial de 2020, não corpo do artigo:**

> “INTERGROWTH-21st standards for Hadlock's estimation of fetal weight”

**Original de 2017:** o modelo nativo estima PFE com CC e CA, sem CF, e publica sua própria distribuição. **Metadados de 2020:** confirmam outra publicação destinada à estimativa de Hadlock; não permitem certificar seus coeficientes sem ler o suplemento. **Cálculo:** não recalculei variantes biométricas de 1985/2017/2020 por falta da associação implementada. **Inferência:** o rótulo genérico “INTERGROWTH” é insuficiente para rastrear a combinação de modelos.

**Certeza:** alta para a existência de versões diferentes; insuficiente para certificar a fórmula/curva usada na R14.32. Não presumir equivalência entre padrões nem acusar uma combinação válida apenas por usar Hadlock.

### Evidência primária nova: alerta institucional de dezembro de 2025

**Estado:** existência e conteúdo do alerta CONFIRMADOS; aplicação ao app/SUS NÃO RESOLVIDA.

Donald Peebles; NHS England/RCOG. Carta oficial **Intergrowth estimated fetal weight charts**, 10/12/2025, PRN02254, pp.1–2. Documento institucional primário integral; **não é artigo de revista e não possui DOI identificado**. Utilizado como complemento de lacuna, sem substituir FEBRASGO/CBR/ISUOG. [R09]

**Trecho literal curto — p.1:**

> “Intergrowth EFW charts can lead to a lower screen positive rate”

**Original:** a orientação aos serviços ingleses alcança versões de PFE INTERGROWTH 2017 e 2020 e solicita migração, motivada por menor identificação abaixo de p10. O documento não é um estudo brasileiro nem demonstra qual implementação está no app.

**Inferência:** essa é evidência documental nova pertinente à escolha da curva, suficiente para propor revisão médica seletiva caso uma dessas versões esteja em uso. **Proposta:** identificar primeiro a versão e apresentar o alerta ao responsável; não executar troca automática, importar condutas inglesas ou alterar cortes com base apenas nesta investigação.

## 6. Prioridade 3 — PSV da ACM: nomograma, domínio e desempenho

### Resposta direta

A fórmula **exp(2,31 + 0,046 × IG)** e o limiar de referência **1,5 MoM** estão em Mari 2000. O estudo diagnóstico incluiu encaminhamentos entre **15 e 36 semanas**; a tabela até 40 não valida por si só desempenho até 40+6. Também confirmei diferença entre a fórmula impressa e a Tabela 3, cuja origem exata continua pendente.

**Estado:** fórmula/limiar CONFIRMADOS; validação universal do domínio do app PARCIALMENTE CONFIRMADA; causa da diferença numérica NÃO RESOLVIDA.

### Fontes, localização e trecho

Mari G, Deter RL, Carpenter RL et al. NEJM 2000;342:9–14. DOI **10.1056/NEJM200001063420102**. Original integral: Study Subjects p.9; Reference Ranges p.10; Tabela 3 p.12; discussão p.13. [R10]

**Trecho literal curto — p.10:**

> “MCA-PSV = e(2.31 + 0.046 GA)”

### Quatro domínios que não devem ser confundidos

| Componente | O que foi diretamente acessado | O que não fica validado por isso |
|---|---|---|
| Nomograma anterior de Mari 1995 | Resumo original: 135 fetos normais; DOI 10.1046/j.1469-0705.1995.05060400.x. | IG exata da construção e coeficientes completos: não acessei Métodos. |
| Fórmula utilizada em 2000 | Equação em p.10, atribuída ao nomograma anterior. | Ausência de extrapolação nos extremos de IG. |
| Coorte diagnóstica de 2000 | Encaminhamentos 15–36 semanas; 111 fetos analisados. | Mesmo desempenho até 40+6 ou após transfusões. |
| Tabela 3 de 2000 | Valores em 18, 20, …, 40 semanas. | Validação diagnóstica individual para todas as IG tabeladas. |

O resumo de Mari 1995 é fonte primária apenas para o conteúdo que contém; não atribuo a ele uma faixa de IG ausente do texto acessado. A faixa 18–40 dos 265 fetos normais para hemoglobina em 2000 também não é a população que construiu o nomograma de PSV. [R10–R11]

### Conferência numérica adicional — fórmula versus Tabela 3

Recalculei as **48 células** com a fórmula impressa, em cm/s. Todas diferem mais que 0,05 cm/s do literal publicado: o simples arredondamento da célula a 0,1 não reconcilia os resultados. A maior diferença, considerando todas as colunas, é **1,4773 cm/s**. Isto é discrepância documental entre representações do mesmo artigo; não demonstra fórmula errada no app.

| IG | Mediana fórmula | Mediana tabela | 1,5 × fórmula | 1,5 tabela | Diferença do corte |
|---|---|---|---|---|---|
| 24+0 | 30,387 | 30,7 | 45,580 | 46,0 | -0,420 |
| 32+0 | 43,904 | 44,4 | 65,856 | 66,6 | -0,744 |
| 36+0 | 52,773 | 53,5 | 79,160 | 80,2 | -1,040 |
| 40+0 | 63,434 | 64,4 | 95,151 | 96,6 | -1,449 |

**Testemunho condicional:** 24+0; PSV 45,8 cm/s → exp(2,31 + 0,046 × 24) = 30,386548 cm/s → MoM 1,507246. O corte pela fórmula é 45,579822 cm/s; a Tabela 3 publica 46,0 cm/s. A diferença dos cortes é 0,420178 cm/s, ou 0,9134% do corte tabelado. O valor ficaria acima de um corte e abaixo do outro. Isso não diagnostica anemia.

**Teste da hipótese de coeficientes arredondados:** sob a hipótese explícita de arredondamento dos coeficientes a 2,31 e 0,046 e das células a 0,1 cm/s, as 12 medianas admitem uma exponencial compatível. Portanto, diferenças nas medianas podem ser compatíveis com a precisão dos coeficientes. Esse resultado não prova que essa foi a causa histórica. As 48 células, tratadas como multiplicação direta e sem arredondamento intermediário de uma única mediana, não têm solução conjunta nessas restrições. O processamento original completo continua desconhecido; não inferi novos coeficientes para uso clínico.

**Original:** fórmula e valores tabelados foram conferidos também visualmente. **Reprodução secundária:** nenhum calculador externo foi usado como oráculo. **Cálculo independente:** Decimal com 80 dígitos e análise de intervalos de arredondamento. **Inferência:** preservar a identificação da representação adotada e solicitar o nomograma de 1995 antes de qualquer mudança de fórmula.

### Evidência posterior e limitações contextuais

Maisonneuve E et al. Fetal Diagnosis and Therapy 2017;42:225–231. DOI **10.1159/000456661**. **Resumo original acessado; não acessei texto integral**, Methods/Results/Conclusions: estudo retrospectivo de 150 gestações aloimunizadas em 34–37 semanas; sensibilidade relatada de 69% para anemia grave pelo Doppler isolado, 94% com sinais de hidropisia; mais falsos positivos após transfusão. Não sustenta extrapolação a 40+6. [R12]

Khalil A et al., ISUOG. UOG 2020;56:128–151. DOI **10.1002/uog.21991**. Trecho relevante lido na **tradução oficial portuguesa**, seção Parvovírus, p.15 do PDF; não atribuo leitura direta desse trecho ao original inglês. [R13]

**Trecho literal curto — tradução oficial:**

> “a taxa de falsos positivos aumenta após 35 semanas de gestação”

Mari G et al., SMFM Clinical Guideline #8. AJOG 2015;212:697–710. DOI **10.1016/j.ajog.2015.01.059**. Original integral: recomendações pp.697–698; transfusões subsequentes p.704. Complemento para a lacuna clínica: a avaliação se destina a fetos sob risco; o contexto pós-transfusional não admite interpretação universal idêntica. A diretriz discute limiar maior para segunda transfusão, mas não proponho transferi-lo automaticamente ao app. [R14]

**Divergências:** desempenho de Mari 2000 não é reproduzido como garantia universal por uma coorte tardia/transfundida. ISUOG e SMFM diferenciam contexto clínico e técnica. O operador > ou ≥ de cada texto deve permanecer identificado; não alterei o operador aprovado. Não confirmei trecho FEBRASGO/CBR atual que resolva especificamente o domínio até 40+6.

**Certeza:** alta para conteúdo de 2000 e cálculos; média para a extrapolação contextual do resumo de 2017; não resolvida para o domínio completo de 1995 e desempenho até 40+6.

**Proposta para o app:** manter fórmula e limiar aprovados até decisão médica sobre a discrepância documental. Propor aviso contextual, sem bloqueio automático: “MoM calculado pela referência selecionada. A interpretação para anemia depende da indicação clínica e da técnica; o desempenho pode ser menor em gestação avançada, especialmente após 35–36 semanas, e após transfusão intrauterina.” Não exibir “anemia excluída” por MoM baixo nem declarar toda a faixa até 40+6 igualmente validada.

## 7. Lacunas complementares — uterinas

**Resposta direta:** os 42 valores informados nas sete idades conferem com as tabelas publicadas, à precisão de duas casas. As técnicas e os domínios precisam acompanhar a referência. A ISUOG cita Gómez e exige correspondência técnica; não encontrei escolha exclusiva entre Gómez e Cavoretto atribuível a FEBRASGO/CBR/ISUOG.

**Estado:** valores/técnicas CONFIRMADOS; preferência exclusiva NÃO RESOLVIDA.

**Fontes primárias:** Gómez O et al., UOG 2008;32:128–132, DOI **10.1002/uog.5315**, Métodos/Tabela 2. Cavoretto PI, Salmeri N, Candiani M, Farina A, UOG 2023;61:474–480, DOI **10.1002/uog.26092**, Métodos/Tabela 3 p.478. Bhide A et al., ISUOG, UOG 2021;58:331–339, DOI **10.1002/uog.23698**, seção da técnica do Doppler uterino, Figuras 1–2 e referências. [R15–R17]

**Trecho literal curto — Bhide, seção da técnica:**

> “The insonation technique used should be the same as that used for establishing the reference range.”

**Original:** Gómez utiliza TV no período 11–14 semanas e TA em 15–41; Cavoretto utiliza TA, domínio publicado 10+0–39+0. **Reprodução:** as linhas finais de Cavoretto também foram conferidas em trecho indexado do original depositado pelos autores; indexação não é acesso ao arquivo suplementar completo. **Cálculo:** a conferência aqui foi por leitura/transcrição das tabelas, não recálculo das equações nem execução do app. **Inferência:** discrepâncias entre curvas não demonstram invalidade de uma delas; incompatibilidade de técnica pode comprometer a comparação.

**Certeza:** alta para os valores/técnicas acessados; insuficiente para atribuir preferência nacional específica. A diretriz ISUOG de 2021 antecede Cavoretto 2023, e citá-la não constitui avaliação desse estudo futuro.

**Proposta:** manter a curva aprovada, identificar via/IG e mostrar a referência utilizada. Não fazer troca por mera data de publicação. Caso a via utilizada não corresponda à construção da curva, apresentar a questão ao médico responsável. Os 42 valores e seu tipo de conferência estão no CSV das uterinas.

## 8. Lacunas complementares — ventriculomegalia

**Resposta direta:** átrio <10 mm é normal no intervalo de referência das diretrizes acessadas. Não localizei respaldo primário para recomendar automaticamente retorno em 3–4 semanas por átrio isolado de 9–9,9 mm. A SMFM publica graduação 10–12, 13–15 e >15 mm; isso não explicita sozinho todos os intervalos decimais intermediários.

**Estado:** normalidade <10 e graduação nominal CONFIRMADAS; graduação decimal PARCIALMENTE CONFIRMADA; regra de retorno automático NÃO RESOLVIDA.

**Fontes:** Malinger G, Paladini D, Haratz KK, Monteagudo A, Pilu G, Timor-Tritsch IE. ISUOG, UOG 2020;56:476–484. DOI **10.1002/uog.22145**, Quantitative evaluation/Technical advice e Figura 5, original integral. Fox NS et al., SMFM Consult #45, AJOG 2018;219:B2–B9. DOI **10.1016/j.ajog.2018.04.039**, Summary of recommendations, recomendação 1, p.B7, original integral; complemento para graduação. [R18–R19]

**Trecho literal curto — ISUOG:**

> “The atrial width should be measured inner-to-inner and should be <10 mm throughout pregnancy”

**Trecho literal curto — SMFM:**

> “mild (10–12 mm), moderate (13–15 mm), or severe (>15 mm)”

**Original:** medida padronizada e rastreio satisfatório, com átrio <10, não levam por si só a exames adicionais do SNC. **Reprodução:** não há fonte secundária usada para justificar 9–9,9/3–4 semanas. **Cálculo:** nenhum novo corte foi derivado. **Inferência:** “10 a <13” deve ser identificado como convenção operacional para preencher o intervalo decimal, não citação literal de 2018. Não presumo que 12,9 mm deva mudar de categoria sem decisão documentada.

**Certeza:** alta para o limite de 10 mm; média/insuficiente para a regra operacional decimal e retorno automático. A ausência de uma fonte localizada não prova ausência de todas as referências possíveis.

**Proposta:** se essa for a regra vigente, apresentar 9–9,9 mm como valor ainda <10 mm, com avaliação de técnica, outros achados e evolução quando indicada pelo médico. Não atribuir o retorno automático de 3–4 semanas à ISUOG/SMFM sem documento específico. Preservar a graduação aprovada enquanto sua convenção decimal e o protocolo local são explicitados.

## 9. Lacunas complementares — colo uterino

**Resposta direta:** o corte de 25 mm é contextual, usualmente por TV no rastreio de 18–24 semanas. Há cortes menores para situações específicas e faixa 26–29 em vigilância de mulheres com história de prematuridade. Isso não sustenta categorias universais “≤15 muito curto” e “26–30 limítrofe” em qualquer IG e quadro clínico.

**Estado:** cortes contextuais CONFIRMADOS; universalidade das categorias NÃO RESOLVIDA/não demonstrada.

**Fonte primária:** Coutinho CM et al., ISUOG, UOG 2022;60:435–456. DOI **10.1002/uog.26020**. Original integral: p.440; pp.443–444/Figura 11; p.446/Figura 12; pp.448–449/Figura 13. [R20]

**Trecho literal curto — recomendação p.440:**

> “CL ≤ 25 mm can be used as a cut-off”

**Original:** recomendações diferenciam assintomáticas, história obstétrica, gestação múltipla e sintomas. Em história de prematuridade, a faixa é 26–29 mm, enquanto ≥30 está em outro ramo. Em sintomáticas 22+0–33+6, são discutidos <15 ou <20 e ≥30 mm; não um rótulo universal em todo período gestacional.

**Reprodução:** não usei resumo de IA para transformar os cortes contextuais em classes universais. **Cálculo:** não alterei limites nem operadores. **Inferência:** após 24 semanas, uma medida ≤25 pode ser relevante, mas não deve transportar automaticamente a interpretação do rastreio de 18–24. Ausência de indicação universal não significa normalidade nem segurança para dispensar avaliação.

**Certeza:** alta para a necessidade de contexto; insuficiente para validar as categorias locais como definições universais de diretriz. Não confirmei protocolo nacional específico que autorize exatamente 26–30 em todas as gestantes.

**Proposta:** informar “Comprimento cervical: X mm; interpretar conforme IG, via, sintomas e história obstétrica”. Se o médico mantiver “muito curto” ou “limítrofe”, identificá-los como categorias operacionais do app, com domínio explícito. Não ampliar a investigação para propor tratamento: a decisão e qualquer conduta pertencem ao responsável.

## 10. Pontos preservados

Não reabri a regra operacional de aproximadamente três semanas para interpretar crescimento seriado, nem a confundi com parte literal do Delphi ou frequência obrigatória de vigilância. Mantive o ponto documentado de que “Any Dilation” calicial antenatal na Figura 1 da atualização UTD 2022 leva a A2-3; a distinção pós-natal central/periférica não foi transportada para o pré-natal.

PIG, GIG, RCF, líquido e as demais decisões aprovadas fora das pendências delimitadas não foram revistos nesta rodada. Nenhum dado sobre quantidade de testes foi usado para declarar validade científica.

## 11. Prioridades para avaliação do médico responsável

### Erros demonstrados e questões com potencial impacto clínico

**Nenhum erro da implementação R14.32 foi demonstrado nesta investigação**, porque o arquivo não está disponível. Os itens abaixo distinguem defeito documental, diferença matemática e alerta externo:

| Prioridade | Achado demonstrado | Possível consequência / ação proposta |
|---|---|---|
| 1 | Hadlock: equação e tabela têm cortes inferiores diferentes; literal p97 30 semanas viola ordenação. | Identificar a representação usada. Não transcrever célula anômala sem resolução documental. Decisão sobre referência exige médico e análise local. |
| 2 | PSV: coorte de 2000 não abrange 40+6; há evidência de limitações tardias/pós-transfusão. | Corrigir qualquer alegação de validação uniforme; propor aviso contextual. Não bloquear nem mudar o limiar automaticamente. |
| 3 | PSV: fórmula e Tabela 3 diferem em IG idêntica. | Declarar representação e buscar nomograma original/precisão completa antes de propor mudança numérica. |
| 4 | Documento primário NHS/RCOG de 2025 alerta para curvas de PFE INTERGROWTH 2017/2020. | Se em uso, discutir seletivamente com o responsável, respeitando diretrizes brasileiras e viabilidade no SUS. |
| 5 | Universalidade de rótulos cervicais não demonstrada. | Contextualizar IG/via/sintomas; evitar que uma categoria operacional seja interpretada como diagnóstico universal. |

Ciobanu continua uma prioridade documental anterior à alteração de seus cortes. A falta de S1/correspondência impede classificar o modelo como correto ou defeituoso em relação às tabelas.

### Melhorias de redação e rastreabilidade

- Identificar separadamente fórmula do PFE, curva de percentil, versão e representação equação/tabela.
- Explicitar σlog; distinguir mediana, média aritmética e resíduos percentuais.
- Registrar a IG exata em dias nos testes Ciobanu, especialmente +0 versus +3.
- Distinguir MoM calculável de domínio de validação diagnóstica; documentar contexto tardio/transfusional.
- Informar técnica e domínio da curva uterina; não atribuir escolha exclusiva a diretriz sem texto.
- Distinguir normalidade <10 mm de faixa operacional 9–9,9 e de retorno por indicação clínica.
- Declarar a convenção decimal da graduação ventricular e o domínio das categorias cervicais.

### O que deve permanecer inalterado nesta investigação

Todos os códigos, coeficientes, tabelas, operadores, limiares, regras clínicas aprovadas, UI, schema e worker. Não se recomenda trocar referência por novidade bibliográfica, por comparação de IG diferente ou por impossibilidade de acesso. As propostas acima não foram aplicadas.

## 12. O que ainda impede o fechamento

| Documento/dado exato faltante | Conclusão que fica impedida |
|---|---|
| HTML R14.32 e dossiê vigente, com hashes/identificadores de versão | Auditoria da implementação, associação de modelos e confronto com decisões efetivamente aprovadas. |
| Ciobanu: uog20157-sup-0002-Tables.docx, Tabela S1 | Transcrição dos coeficientes; 45 resultados +0 e 198 comparações na mesma IG da Tabela 2. |
| DeVore pp.349–350 e uog23578-sup-0001-AppendixS1.xlsx | Dimensão/causa exata das discrepâncias analisadas na correspondência. |
| Wright, Wright e Nicolaides pp.350–351, DOI 10.1002/uog.23579 | Resposta dos autores, versão recomendada e eventual orientação de correção. |
| Mari 1995: Métodos, nomograma e coeficientes completos | Domínio original e causa/representação exata da diferença fórmula/Tabela 3 em 2000. |
| Evidência diagnóstica pertinente até 40+6, na população/indicação relevantes | Garantia de desempenho uniforme nesse extremo, que não foi demonstrada. |
| Hadlock 1985: equações originais; INTERGROWTH 2020: corpo, TableS1/TableS2, se essa versão estiver no app | Certificar a combinação biométrica/distribuição concreta. |
| Fonte nacional ou protocolo local explícito das categorias operacionais discutidas | Atribuir respaldo brasileiro específico a retorno 9–9,9/3–4 semanas, graus decimais e categorias cervicais. |

A origem histórica completa da discrepância Hadlock também permanece desconhecida: o acesso ao artigo de 1991 resolveu os parâmetros impressos, não recriou os dados/processamento originais. Não prometo resolver essa origem apenas obtendo mais uma referência.

## 13. Reprodutibilidade e arquivos

calculos_independentes.py usa apenas a biblioteca padrão de Python, sem importar funções do app. Emprega Decimal com 80 dígitos, integração da densidade normal por série e inversão por bisseção. Nove quantis foram conferidos contra statistics.NormalDist; o maior desvio em dupla precisão foi 1,11 × 10⁻¹⁵. Os mesmos nove quantis convergiram ao repetir em 65/80 dígitos. Os 155 pesos foram conferidos também com exp/inv_cdf em dupla precisão.

O teste de precisão decimal verifica o cálculo, não a validade clínica do modelo nem a fidelidade de todas as transcrições. As células originais foram lidas nas fontes; pontos críticos de Hadlock/Mari foram conferidos em imagem. Nenhuma expectativa de Ciobanu foi fabricada: as comparações bloqueadas permanecem em branco.

Para reproduzir: descompactar e executar **python3 calculos_independentes.py**; depois, **python3 gerar_relatorio.py**. O primeiro comando regenera comparações/JSON; o segundo regenera o relatório e o registro tabular de fontes. A criação do PDF usa ReportLab e as fontes DejaVu, como registrado em build_pdf.py; não é necessária para repetir os cálculos.

O pacote contém relatório PDF/Markdown, inventário, tabelas originais transcritas, comparações completas, testemunhos condicionais, registro de acesso, scripts e SHA-256. Não redistribui PDFs integrais de artigos protegidos; fornece os endereços públicos consultados.

## 14. Referências e nível real de acesso

As localizações e limitações abaixo fazem parte das conclusões. Metadados não foram tratados como texto integral; tradução oficial não foi tratada como leitura direta do trecho inglês.

### R01 — Ciobanu A; Wright A; Syngelaki A; Wright D; Akolekar R; Nicolaides KH (2019)

Fetal Medicine Foundation reference ranges for umbilical artery and middle cerebral artery pulsatility index and cerebroplacental ratio. Ultrasound in Obstetrics & Gynecology; 53:465–472. DOI 10.1002/uog.20157.

**Local:** Métodos pp.466–467; Tabela 2 p.468; menção à Tabela S1 p.467. **Acesso real:** Artigo original integral em cópia pública; Tabela 2 lida. Suplemento NÃO ACESSADO.

[Endereço consultado](https://ultrasonicahn.com/wp-content/uploads/2021/01/FMF-IP-AU-IP-ACM-RCP-ISUOG-2019-1.pdf).

### R02 — DeVore GR (2021)

Why does computation of centiles from equations for umbilical artery and middle cerebral artery pulsatility index and cerebroplacental ratio from Fetal Medicine Foundation study of 72 387 fetuses not agree with tabular results?. Ultrasound in Obstetrics & Gynecology; 57:349–350. DOI 10.1002/uog.23578.

**Local:** Página de metadados e Supporting Information. **Acesso real:** Somente metadados editoriais e identificação do suplemento; não acessei o corpo nem os dados da planilha.

[Endereço consultado](https://obgyn.onlinelibrary.wiley.com/doi/abs/10.1002/uog.23578).

### R03 — Wright A; Wright D; Nicolaides KH (2021)

Réplica à correspondência de DeVore (identificação descritiva por DOI; corpo não acessado). Ultrasound in Obstetrics & Gynecology; 57:350–351. DOI 10.1002/uog.23579.

**Local:** Metadados; corpo pp.350–351 não acessado. **Acesso real:** Somente metadados; não acessei o corpo.

[Endereço consultado](https://obgyn.onlinelibrary.wiley.com/doi/abs/10.1002/uog.23579).

### R04 — Hadlock FP; Harrist RB; Martinez-Poyer J (1991)

In Utero Analysis of Fetal Growth: A Sonographic Weight Standard. Radiology; 181:129–133. DOI 10.1148/radiology.181.1.1887021.

**Local:** Métodos pp.129–130; Figura 2 e Tabela 1 p.130; Resultados/equação/DP p.131. **Acesso real:** PDF original integral acessado pela ferramenta de pesquisa; Tabela 1 conferida também em imagem. Download local separado falhou e não foi usado.

[Endereço consultado](https://obgyn.utoronto.ca/sites/default/files/Hadlock%20Growth%20Chart-Radiology-1991.pdf).

### R05 — Adu-Bredu TK; Twumasi C; Mathewlynn S; Impey L; Ioannou C (2026)

Internal Consistency of the Hadlock Estimated Fetal Weight Reference: Methodological Analysis. BJOG: An International Journal of Obstetrics & Gynaecology; Early View; publicado em 30/06/2026. DOI 10.1111/1471-0528.70296.

**Local:** Seções 2.1–2.3, Tabelas 1–2, Resultados, Discussão 4.2–4.4. **Acesso real:** Texto original integral em HTML; não somente resumo.

[Endereço consultado](https://obgyn.onlinelibrary.wiley.com/doi/full/10.1111/1471-0528.70296).

### R06 — Hadlock FP; Harrist RB; Sharman RS; Deter RL; Park SK (1985)

Estimation of fetal weight with the use of head, body, and femur measurements—a prospective study. American Journal of Obstetrics and Gynecology; 151:333–337. DOI 10.1016/0002-9378(85)90298-4.

**Local:** Identificação bibliográfica; fórmulas de três/quatro parâmetros não conferidas integralmente. **Acesso real:** Metadados/resumo; não acessei tabelas de coeficientes do original.

[Endereço consultado](https://doi.org/10.1016/0002-9378(85)90298-4).

### R07 — Stirnemann J; Villar J; Salomon LJ; Ohuma E; Ruyan P; Altman DG; et al. (2017)

International estimated fetal weight standards of the INTERGROWTH-21st Project. Ultrasound in Obstetrics & Gynecology; 49:478–486. DOI 10.1002/uog.17347.

**Local:** Resultados/equação de PFE p.479; Tabela 2 de parâmetros de distribuição. **Acesso real:** Texto original integral.

[Endereço consultado](https://doi.org/10.1002/uog.17347).

### R08 — Stirnemann J; Salomon LJ; Papageorghiou AT (2020)

INTERGROWTH-21st standards for Hadlock's estimation of fetal weight. Ultrasound in Obstetrics & Gynecology; 56:946–948. DOI 10.1002/uog.22000.

**Local:** Metadados; gráfico oficial https://intergrowth21.com/sites/default/files/2024-09/ig_fet-hefwfga-centiles.pdf. **Acesso real:** Metadados e nomes dos suplementos; não acessei o corpo ou coeficientes de S1/S2. Gráfico oficial de Oxford acessado à parte.

[Endereço consultado](https://obgyn.onlinelibrary.wiley.com/doi/10.1002/uog.22000).

### R09 — Peebles D; NHS England; Royal College of Obstetricians and Gynaecologists (2025)

Intergrowth estimated fetal weight charts. Carta institucional oficial NHS England/RCOG, 10/12/2025, PRN02254; 3 páginas; pontos relevantes pp.1–2. Documento institucional; sem DOI identificado.

**Local:** pp.1–2: versões 2017/2020, alerta e medidas para os serviços ingleses. **Acesso real:** Documento primário institucional integral; não é artigo de revista e não possui DOI identificado.

[Endereço consultado](https://www.rcog.org.uk/media/b15mznah/intergrowth-estimated-fetal-weight-charts_10-december.pdf).

### R10 — Mari G; Deter RL; Carpenter RL; Rahman F; Zimmerman R; Moise KJ Jr; et al., Collaborative Group for Doppler Assessment of the Blood Velocity in Anemic Fetuses (2000)

Noninvasive Diagnosis by Doppler Ultrasonography of Fetal Anemia Due to Maternal Red-Cell Alloimmunization. New England Journal of Medicine; 342:9–14. DOI 10.1056/NEJM200001063420102.

**Local:** Study Subjects p.9; Reference Ranges p.10; Tabela 3 p.12; discussão p.13. **Acesso real:** Texto original integral; fórmula p.10 e Tabela 3 p.12 conferidas visualmente no PDF local.

[Endereço consultado](https://portaldeboaspraticas.iff.fiocruz.br/wp-content/uploads/2019/08/nejm200001063420102.pdf).

### R11 — Mari G; Adrignolo A; Abuhamad AZ; Pirhonen J; Jones DC; Ludomirsky A; Copel JA (1995)

Diagnosis of fetal anemia with Doppler ultrasound in the pregnancy complicated by maternal blood group immunization. Ultrasound in Obstetrics & Gynecology; 5:400–405. DOI 10.1046/j.1469-0705.1995.05060400.x.

**Local:** Resumo: 135 fetos normais; faixa de IG do nomograma não especificada no trecho acessado. **Acesso real:** Resumo original e metadados; não acessei o corpo.

[Endereço consultado](https://pubmed.ncbi.nlm.nih.gov/7552802/).

### R12 — Maisonneuve E; Jayot A; Friszer S; Castaigne V; Cynober E; Pernot F; Mailloux A; Jouannic JM; Cortey A; Carbonne B (2017)

Accuracy of Middle Cerebral Artery Doppler Assessment between 34 and 37 Weeks in Fetuses with Red Cell Alloimmunization. Fetal Diagnosis and Therapy; 42:225–231. DOI 10.1159/000456661.

**Local:** Resumo: Methods/Results/Conclusions. **Acesso real:** Resumo original diretamente acessado; não acessei texto integral.

[Endereço consultado](https://pubmed.ncbi.nlm.nih.gov/28278506/).

### R13 — Khalil A; Sotiriadis A; Chaoui R; da Silva Costa F; D'Antonio F; Heath PT; Jones CE; Malinger G; Odibo A; Prefumo F; Salomon LJ; Wood S; Ville Y (2020)

ISUOG Practice Guidelines: role of ultrasound in congenital infection. Ultrasound in Obstetrics & Gynecology; 56:128–151. DOI 10.1002/uog.21991.

**Local:** Seção Parvovírus, página 15 do PDF traduzido: limitações PSV/falsos positivos após 35 semanas. **Acesso real:** Tradução oficial portuguesa integral, autorizada e hospedada na ISUOG. Trecho relevante em inglês não acessado diretamente nesta investigação.

[Endereço consultado](https://www.isuog.org/static/98d75aa4-9f9e-4272-9be8651fc636e7ed/uog21991Congenital-infection-guideline-PORTUGUESE-TRANSLATION.pdf).

### R14 — Mari G; Norton ME; Stone J; Berghella V; Sciscione AC; Tate D; Schenone MH; Society for Maternal-Fetal Medicine (2015)

SMFM Clinical Guideline #8: the fetus at risk for anemia—diagnosis and management. American Journal of Obstetrics and Gynecology; 212:697–710. DOI 10.1016/j.ajog.2015.01.059.

**Local:** Recomendações pp.697–698; transfusões subsequentes p.704. **Acesso real:** Diretriz original integral. Fonte complementar em lacuna específica após a ISUOG.

[Endereço consultado](https://assets.noviams.com/novi-file-uploads/smfm/Publications_and_Guidelines/Clinical_Guidelines/CG_8_fetal_anemia.pdf).

### R15 — Gómez O; Figueras F; Fernández S; Bennasar M; Martínez JM; Puerto B; Gratacós E (2008)

Reference ranges for uterine artery mean pulsatility index at 11–41 weeks of gestation. Ultrasound in Obstetrics & Gynecology; 32:128–132. DOI 10.1002/uog.5315.

**Local:** Métodos e Tabela 2. **Acesso real:** Texto e Tabela 2 acessados durante a pesquisa; tentativa posterior de reabertura retornou 403.

[Endereço consultado](https://doi.org/10.1002/uog.5315).

### R16 — Cavoretto PI; Salmeri N; Candiani M; Farina A (2023)

Reference ranges of uterine artery pulsatility index from first to third trimester based on serial Doppler measurements: longitudinal cohort study. Ultrasound in Obstetrics & Gynecology; 61:474–480. DOI 10.1002/uog.26092.

**Local:** Métodos; Tabela 3 p.478. **Acesso real:** Texto original acessado; linhas finais da Tabela 3 também recuperadas em trecho indexado da versão dos autores no repositório institucional de Bologna. Reabertura posterior retornou 403.

[Endereço consultado](https://obgyn.onlinelibrary.wiley.com/doi/full/10.1002/uog.26092).

### R17 — Bhide A; Acharya G; Baschat A; Bilardo CM; Brezinka C; Cafici D; et al. (2021)

ISUOG Practice Guidelines (updated): use of Doppler velocimetry in obstetrics. Ultrasound in Obstetrics & Gynecology; 58:331–339. DOI 10.1002/uog.23698.

**Local:** Seção What is the appropriate technique for obtaining uterine artery Doppler waveforms?; técnicas TA/TV, Figuras 1–2; referências. **Acesso real:** Diretriz original integral em HTML.

[Endereço consultado](https://obgyn.onlinelibrary.wiley.com/doi/full/10.1002%2Fuog.23698).

### R18 — Malinger G; Paladini D; Haratz KK; Monteagudo A; Pilu G; Timor-Tritsch IE (2020)

ISUOG Practice Guidelines (updated): sonographic examination of the fetal central nervous system. Part 1: performance of screening examination and indications for targeted neurosonography. Ultrasound in Obstetrics & Gynecology; 56:476–484. DOI 10.1002/uog.22145.

**Local:** Quantitative evaluation/Technical advice; Figura 5; parágrafo sobre rastreio normal com átrio <10 mm. **Acesso real:** Diretriz original integral em HTML.

[Endereço consultado](https://obgyn.onlinelibrary.wiley.com/doi/10.1002/uog.22145).

### R19 — Fox NS; Monteagudo A; Kuller JA; Craigo S; Norton ME; Society for Maternal-Fetal Medicine (2018)

SMFM Consult Series #45: Mild fetal ventriculomegaly: diagnosis, evaluation, and management. American Journal of Obstetrics and Gynecology; 219:B2–B9. DOI 10.1016/j.ajog.2018.04.039.

**Local:** Summary of recommendations, recomendação 1, p.B7. **Acesso real:** Diretriz original integral; usada para preencher a lacuna da graduação detalhada.

[Endereço consultado](https://www.mfmnyc.com/wp-content/uploads/2018/07/2018-ventriculomegaly-smfm-AJOG.pdf).

### R20 — Coutinho CM; Sotiriadis A; Odibo A; Khalil A; D'Antonio F; Feltovich H; Salomon LJ; Sheehan P; Napolitano R; Berghella V; da Silva Costa F; ISUOG (2022)

ISUOG Practice Guidelines: role of ultrasound in the prediction of spontaneous preterm birth. Ultrasound in Obstetrics & Gynecology; 60:435–456. DOI 10.1002/uog.26020.

**Local:** p.440: cut-off; pp.443–444/Figura 11: 18–24 semanas; p.446/Figura 12: 26–29 mm em história de prematuridade; pp.448–449/Figura 13: sintomáticas 22+0–33+6. **Acesso real:** Diretriz original integral.

[Endereço consultado](https://www.isuog.org/static/d88e5dff-ced3-43ee-aa2229c2679b9484/ISUOG-Practice-Guidelines-ultrasound-in-preterm-birth.pdf).
