# Auditoria da fila herdada — R14.33 (com o que entrou na R14.34)

Data: 06/10/2026. Baseline: `index.html` R14.33, SHA-256 `bef7664b14e26820268055a8c730959b9c92856522f6b2e39759e0867c112a24`. Auditor: Claude. Nada foi alterado no código.

**Escopo:** todos os itens das seções 5.1 e 5.4 do `CONTEXTO.md` e a tabela original de pendências do CONTEXTO de 17/09/2026, recuperada do histórico da conversa (inclui itens que a seção 5.4 tinha resumido).

**Método:**
1. Localizar a regra no código da R14.33.
2. Reproduzir o comportamento no navegador (Playwright, Chromium) quando o item tem efeito na tela ou no laudo.
3. Conferir a fonte na hierarquia FEBRASGO → CBR → ISUOG.
4. Classificar como conforme, erro demonstrado, diferença de referência ou ajuste de redação.

## 1. Resultado em uma linha

A maior parte da fila já estava resolvida em versões anteriores ou não era defeito (20 linhas da seção 4). Ficaram dois erros demonstrados, do mesmo tipo: marcador classificado fora da janela de IG da sua fonte. Um terceiro suspeito (prega nucal) foi descartado na conferência. Dois deles vêm de itens herdados resolvidos só em parte ("domínio de 11–14 semanas dos marcadores" e "Doppler antes de 11 semanas": o ducto venoso ganhou janela, o osso nasal e a tricúspide não) e do item "osso nasal de 4,5 mm". Há ainda três ajustes de documentação ou acessibilidade.

## 2. Erros demonstrados e prováveis

### E1 — Osso nasal e regurgitação tricúspide do 1º trimestre sem janela de IG (ERRO DEMONSTRADO)

- **O que acontece:** com IG de 8, 9 ou 10 semanas, modo embrião, osso nasal "ausente" e tricúspide com 70 cm/s em ≥ metade da sístole saem como alterados no cartão. O laudo conclui "marcadores ultrassonográficos alterados — osso nasal ausente/hipoplásico e regurgitação tricúspide" (reproduzido em Chromium).
- **Por que é erro:** o próprio app já aplica ao ducto venoso a janela do rastreio de 11+0 a 13+6 semanas (C0-C1D.1), e a TN depende do CCN de 45–84 mm. Osso nasal e tricúspide ficaram de fora. Antes de 11 semanas o osso nasal ainda não ossificou, então "ausente" é esperado, e não marcador.
- **Fonte:** FEBRASGO, ultrassonografia de 1º trimestre (protocolo citado no app); FMF.
- **Proposta:** dar ao osso nasal e à tricúspide a mesma janela do ducto venoso (IG 11+0 a 13+6, e CCN 45–84 mm quando informado). Fora dela, registrar o achado sem classificar e sem levar à conclusão do laudo.

### E2 — Osso nasal do 2º trimestre: corte fixo de 4,5 mm em qualquer IG (ERRO DEMONSTRADO)

- **O que acontece:** com 17 semanas, osso nasal de 3,8 mm sai como "Osso nasal hipoplásico", com razão de verossimilhança de 6,6 para T21, e o laudo diz "fora dos valores de referência para o segundo trimestre". O mesmo valor com 22 semanas sai igual.
- **Por que é erro:** a FEBRASGO (Protocolo de Obstetrícia nº 43, 2025, Ultrassonografia morfológica do segundo trimestre, PDF anexado) dá "normal ≥ 4,5 mm" dentro de um exame que, segundo o mesmo documento, deve ser feito entre 20 e 24 semanas. O osso nasal cresce com a IG. O p5 fica entre cerca de 2,4 e 3,7 mm entre 16 e 18 semanas em várias populações, e 4,5 mm só se aproxima do p5 por volta de 20 a 23 semanas (Narayani 2013, Índia; série turca de 1.467 fetos; nomograma do norte da Índia, 2025; RESUMOS). Fora da janela, o corte fixo produz falso alarme de aneuploidia antes de 20 semanas e passa a ser permissivo depois de 24.
- **Proposta:** aplicar o corte de 4,5 mm só entre 20+0 e 24+6 semanas. Fora disso, mostrar a medida com a nota "o corte da FEBRASGO vale no morfológico de 20–24 semanas; o osso nasal cresce com a IG", sem rótulo de hipoplasia e sem entrar no laudo como alterado. A razão prega frontonasal/osso nasal (< 0,8) segue a mesma janela.

### E3 — Prega nucal ≥ 6 mm sem janela de IG (CORRIGIDO: NÃO ERA ERRO)

Na primeira leitura, Claude olhou só o ramo de classificação e concluiu que faltava janela. Na verdade, o campo da prega nucal fica oculto e é zerado fora de 16 a 24 semanas (`prgWrap`, `valeP`), então a classificação nunca roda fora da janela. A definição de prega espessada da literatura (≥ 6 mm no meio do 2º trimestre, entre 15 e 24 semanas conforme a série; FEBRASGO: normal < 6,0 mm no morfológico) é compatível. **Conforme.** Observação menor: `g<=24` aceita 24+0 e exclui 24+1 a 24+6, diferente da janela do osso nasal adotada na R14.34 (até 24+6). Sem impacto relevante; mantido.

## 3. Ajustes de documentação e acessibilidade

- **D1 — Intervalos de seguimento na tela de referências.** As linhas "Intervalo de reavaliação (FEBRASGO, Protocolo de RCF 2018)" e "Vigilância com diástole ausente/reversa — a cada 2–3 dias antes de 34 sem" sugerem que o app define intervalos. Ele não define desde a remoção dos intervalos fixos. Proposta: reescrever como "referência para o médico; o app não sugere intervalos".
- **D2 — Número de protocolo FEBRASGO ambíguo.** Cartões de líquido e textos da síntese citam só "Protocolo nº 43 (2025)", e o PDF do morfológico de 2025 também se identifica como nº 43. O checklist cita "Protocolo 78 (Femina, 2025)", mas o 78 é o morfológico de 2018. Proposta: citar pelo título nos textos visíveis.
- **D3 — Zoom bloqueado.** A meta `viewport` tem `maximum-scale=1, user-scalable=no`. O iPhone ignora isso desde o iOS 10, mas o Android respeita, o que prejudica leitura e acessibilidade. Proposta: liberar o zoom e conferir o layout no celular.
- **D4 — Comentário interno desatualizado na FCF.** O comentário do código ainda diz "faixa única usada nos dois trimestres", o que contradiz a implementação atual. Não aparece na tela. Proposta: corrigir junto com qualquer outra mudança.

## 4. Itens conferidos sem defeito

| Item herdado | Situação na R14.33 | Evidência |
|---|---|---|
| Uterina direita/esquerda percentilada isoladamente | Lado isolado só registrado (`utLadoNeutro`); classifica só o IP médio | Código |
| Gómez: tabela híbrida 32–41 sem | Table 2 impressa célula a célula de 11 a 41 sem (C0-B2) | Código |
| PSV 1,29–1,49 MoM | Faixa de atenção do app, explícita (R14.33) | Código e teste |
| Incisura sozinha virando "Doppler alterado" | Achado descritivo; não dispara a conclusão (C0-B2) | Código |
| "Sequência de deterioração" | Virou "Territórios hemodinâmicos avaliados"; texto distingue RCF precoce de tardia | Código |
| Ducto venoso antes de 11 semanas | Janela de 11+0–13+6; fora dela é registrado, sem classificar | Código |
| Atribuição das faixas de FCF | Separadas por segmento: Doubilet e Benson 1995 e Doubilet 2000 (6–7 sem), Silva e Bailão 2000 (6–9+6), Pettersen e Faria 2001 (10–13+6), sem referência de 14 a 19+6, FIGO 2015 a partir de 20 | Código e referências |
| Léxico SRU 2024 | "Ovo cego" aposentado e "gestação anembrionada" mantida; "atividade cardíaca", evitar "viável", "perda gestacional precoce" — conferidos no resumo de Rodgers et al., Radiology 2024;312:e240122 | Código; RESUMO |
| Colo com conduta sem contexto | Conduta removida (C0-C1E-05); rótulo por janela (R14.33) | Código e teste |
| Bordas da ventriculomegalia | R14.33 | Código e teste |
| Gemelar com ambos < p10 | Estado `both-sga-overlap` sinaliza a sobreposição antes de fechar sFGR (GEM-P0-02, ISUOG 2025) | Código |
| Restos ovulares por espessura | Só painel teórico; espessura isolada nunca gera diagnóstico nem conduta | Código |
| Persistência de `CURVA`/`CURVA_TN` | No payload desde o schema v3 | Código |
| Modo Embrião/Só saco dependendo de CSS | Estado semântico `VIAB_MODE` (STATE-P1-02) | Código |
| `eColo`/`ePla` como campos por feto | Compartilhados desde o B5 | Código |
| Persistência sem validade | Exame salvo leva versão do motor e do schema, mostra a idade e só é recuperado se o médico aceitar. Sem prazo de expiração, por escolha de desenho | Código |
| Reentrância `run()` → `ctxAuto()` → `setCtx()` | `setCtx` só é chamado quando o contexto muda; o ciclo termina | Código (leitura estática) |
| Cadência de seguimento da RCF | Intervalos fixos removidos; o app não automatiza vigilância (ver D1) | Código |
| Órbitas: biocular alto no laudo | Entra no laudo ("acima do p90… Sukonpan 2008") | Código |
| Cinco "falsos negativos" da suíte de 17/09 | Reproduzidos; todos seguem o Delphi (tabela abaixo) | Navegador |

### Os cinco "falsos negativos", reproduzidos na R14.33

| Cenário | Resultado | Leitura |
|---|---|---|
| 28 sem, PFE p8, uterinas > p95 | RCF (PFE < p10 + uterinas > p95) | Correto: critério da RCF precoce |
| 28 sem, PFE p8, diástole zero | RCF (diástole ausente) | Correto |
| 28 sem, PFE p50, diástole zero | RCF (diástole ausente) | Correto: critério isolado antes de 32 sem |
| 34 sem, PFE p8, uterinas > p95 | Peso < p10 com Doppler incompleto; pede o IP da umbilical | Correto: uterina não é critério da RCF tardia |
| 34 sem, PFE p50, diástole reversa | Tamanho incompleto (sem CA) + achado de alta gravidade, encaminhamento especializado | Correto: depois de 32 sem a diástole não é critério isolado, e o achado não foi silenciado |

A suíte de 17/09 esperava outra coisa porque foi escrita antes de o app exigir PFE + CA e de adotar o Delphi literal. Não é regressão.

## 5. Prioridade proposta

## 6. Aplicado na R14.34 (06/10/2026)

O médico delegou a escolha a Claude. Aplicado: **E1**, **E2**, **D1**, **D2** e **D4**. Não aplicado: **D3** (zoom), porque no iPhone, o aparelho de uso, a meta já é ignorada pelo Safari, e liberar o zoom pode desarrumar as barras fixas sem teste no aparelho; e E3, que não era erro.

- **E1:** osso nasal e tricúspide do 1º trimestre só classificados entre 11+0 e 13+6 semanas; fora disso, ou sem IG, o cartão registra o achado sem classificar e o laudo não o inclui.
- **E2:** osso nasal do 2º trimestre com o corte de 0,45 cm só entre 20+0 e 24+6 semanas (a razão prega frontonasal/osso nasal segue a mesma janela); fora dela, medida registrada com nota, sem rótulo de hipoplasia.
- **D1:** linhas de intervalo e vigilância da tela de referências deixam claro que o app não sugere intervalos.
- **D2:** cartões de líquido citam "FEBRASGO, Ultrassonografia obstétrica do 3º trimestre (2025), Tabela 1"; checklist e osso nasal citam o morfológico do 2º trimestre pelo título (nº 43, 2025; antes nº 78, 2018). A frase sobre o desempenho do ILA no polidrâmnio continua como "Protocolo nº 43, 2025", porque não foi possível confirmar de qual dos dois documentos ela vem.
- **D4:** comentário interno da FCF corrigido.

**Colo (R14.33):** mantidas as duas escolhas: um só rótulo "colo curto" na janela, com a checagem do sinal do lama em ≤ 15 mm, e vermelho em "comprimento cervical reduzido". Motivo: a medida exata continua no laudo, e o vermelho evita suavizar um colo muito curto no 3º trimestre.

Testes da R14.34: mudanças (`t34.py`) 112/112 em Chromium e WebKit, com 66 falhas na R14.33; teste da R14.33 (`t33.py`) 278/278; suíte completa 48.184 checagens, 0 falhas, em Chromium e WebKit.
